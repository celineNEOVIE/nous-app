import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.59e3cbaf30634da9a3bd0de79a7448f5',
  appName: 'nous-zen',
  webDir: 'dist',
  // ⚠️ Production : aucun bloc `server.url` — l'app exécute le bundle
  // embarqué (dossier `dist/`) et appelle directement l'API de prod
  // (Supabase + domaine app-nous.fr configurés dans le code).
  android: {
    allowMixedContent: false,
  },
  ios: {
    contentInset: 'always',
  },
};

export default config;