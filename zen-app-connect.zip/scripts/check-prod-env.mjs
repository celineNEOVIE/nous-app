#!/usr/bin/env node
/**
 * Vérifie que les variables d'environnement de production attendues sont
 * bien chargées avant un build (typiquement avant `vite build` pour un
 * .aab Android release). Affiche un résumé masqué — aucune valeur
 * sensible n'est imprimée en clair.
 *
 * Usage : node scripts/check-prod-env.mjs
 */
import { loadEnv } from "vite";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, "..");
const mode = process.env.NODE_ENV === "development" ? "development" : "production";

// Charge .env + .env.{mode} exactement comme Vite le fera au build
const env = loadEnv(mode, root, "VITE_");

const REQUIRED = [
  { key: "VITE_SUPABASE_URL", expect: /^https:\/\/[a-z0-9]+\.supabase\.co$/ },
  { key: "VITE_SUPABASE_PUBLISHABLE_KEY", expect: /^eyJ[A-Za-z0-9_-]+\./ },
  { key: "VITE_PAYMENTS_CLIENT_TOKEN", expect: mode === "production" ? /^pk_live_/ : /^pk_(test|live)_/ },
  { key: "VITE_APP_ENV", expect: mode === "production" ? /^production$/ : /.*/ },
  { key: "VITE_APP_URL", expect: /^https:\/\// },
];

/** Affiche une valeur masquée : garde 4 premiers + 4 derniers caractères. */
function mask(value) {
  if (!value) return "<absent>";
  if (value.length <= 12) return "*".repeat(value.length);
  return `${value.slice(0, 4)}…${value.slice(-4)} (${value.length} chars)`;
}

console.log(`\n🔍 Vérification des variables .env.${mode}\n`);

let hasError = false;
for (const { key, expect } of REQUIRED) {
  const value = env[key];
  const present = Boolean(value);
  const valid = present && expect.test(value);
  const status = !present ? "❌ MANQUANT" : !valid ? "⚠️  FORMAT INATTENDU" : "✅";
  console.log(`  ${status}  ${key.padEnd(32)} ${mask(value)}`);
  if (!present || !valid) hasError = true;
}

console.log("");

if (hasError) {
  console.error("❌ Build interrompu : variables d'environnement invalides ou manquantes.\n");
  process.exit(1);
}

console.log(`✅ Toutes les variables ${mode} sont chargées correctement.\n`);