# App Icons (Capacitor)

Ces fichiers servent de source pour générer toutes les icônes natives iOS + Android.

- `icon.png` — 1024×1024, **fond opaque** (#F5F0E6), conforme App Store.
- `icon-foreground.png` — 1024×1024 transparent, logo centré dans la safe zone (~70 %), pour l'icône adaptive Android.
- `splash.png` — 2732×2732, fond #F5F0E6.

## Générer les icônes natives en local

Après `git pull` :

```bash
npm install
npm install -D @capacitor/assets
npx capacitor-assets generate --iconBackgroundColor "#F5F0E6" --iconBackgroundColorDark "#F5F0E6" --splashBackgroundColor "#F5F0E6" --splashBackgroundColorDark "#F5F0E6"
npx cap sync
```

`@capacitor/assets` écrit automatiquement :
- iOS : toutes les tailles dans `ios/App/App/Assets.xcassets/AppIcon.appiconset` (20pt → 1024pt, @1x/@2x/@3x).
- Android : `res/mipmap-mdpi`, `mipmap-hdpi`, `mipmap-xhdpi`, `mipmap-xxhdpi`, `mipmap-xxxhdpi` + icône adaptive (`ic_launcher_foreground` / `ic_launcher_background`).