import { createRoot } from 'react-dom/client'
import { HelmetProvider } from 'react-helmet-async'
import App from './App.tsx'
import './index.css'
import { registerServiceWorker } from './pwa/register-sw'
import { ErrorBoundary } from './components/error-boundary'

const rootEl = document.getElementById("root")!;
// Clear the static fallback markup (used to avoid a blank white flash on iPad Safari).
rootEl.innerHTML = "";
createRoot(rootEl).render(
  <ErrorBoundary>
    <HelmetProvider>
      <App />
    </HelmetProvider>
  </ErrorBoundary>
);

registerServiceWorker();
