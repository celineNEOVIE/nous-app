/**
 * Resolve a Lovable CDN asset URL (typically "/__l5e/assets-v1/...") to an
 * absolute HTTPS URL when the app runs from a non-HTTP origin such as the
 * Capacitor iOS WebView (`capacitor://localhost`), or from Android Capacitor
 * (`https://localhost`). In those contexts a leading "/" resolves against the
 * local app bundle where these assets do not exist, causing silent 404s
 * (black rectangles for <img>, no audio, no video playback).
 *
 * On a normal web browser (http/https), the URL is returned unchanged so
 * relative paths keep working and the same-origin CDN cache is used.
 */
const PROD_ASSET_ORIGIN = "https://app-nous.fr";

export const resolveAssetUrl = (u: string | undefined | null): string => {
  if (!u) return "";
  if (/^https?:\/\//i.test(u) || u.startsWith("data:") || u.startsWith("blob:")) {
    return u;
  }
  if (typeof window !== "undefined" && u.startsWith("/")) {
    const proto = window.location.protocol;
    const isHttp = proto === "http:" || proto === "https:";
    if (!isHttp || window.location.hostname === "localhost") return `${PROD_ASSET_ORIGIN}${u}`;
    return `${window.location.origin}${u}`;
  }
  return u;
};