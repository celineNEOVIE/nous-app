export type NatureSound = "none" | "waves" | "rain" | "birds";

import vaguesAsset from "@/assets/vagues.mp3.asset.json";
import pluieAsset from "@/assets/pluie-orage.mp3.asset.json";
import oiseauxAsset from "@/assets/oiseaux.mp3.asset.json";

export type NatureSoundHandle = {
  ctx: AudioContext;
  stop: () => void;
  setVolume: (v: number) => void;
};

// Build a long buffer of low-passed white noise — reused as the base
// "texture" for waves / rain / forest wind.
function createNoiseBuffer(ctx: AudioContext, seconds = 4) {
  const buf = ctx.createBuffer(1, ctx.sampleRate * seconds, ctx.sampleRate);
  const data = buf.getChannelData(0);
  let last = 0;
  for (let i = 0; i < data.length; i++) {
    const white = Math.random() * 2 - 1;
    // mild low-pass to soften
    last = (last + 0.04 * white) / 1.04;
    data[i] = last * 3;
  }
  return buf;
}

export function startNatureSound(kind: NatureSound, volume = 0.35): NatureSoundHandle | null {
  if (kind === "none") return null;
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AC) return null;
  const ctx: AudioContext = new AC();
  if (ctx.state === "suspended") ctx.resume().catch(() => {});

  const master = ctx.createGain();
  master.gain.value = volume;
  master.connect(ctx.destination);

  const noiseBuf = createNoiseBuffer(ctx, 4);
  const stopFns: Array<() => void> = [];

  const makeNoiseSource = () => {
    const src = ctx.createBufferSource();
    src.buffer = noiseBuf;
    src.loop = true;
    src.start();
    stopFns.push(() => { try { src.stop(); } catch { /* noop */ } });
    return src;
  };

  if (kind === "waves") {
    // Enregistrement réel de vagues, joué en boucle.
    const audio = new Audio(vaguesAsset.url);
    audio.loop = true;
    audio.crossOrigin = "anonymous";
    audio.preload = "auto";
    try {
      const srcNode = ctx.createMediaElementSource(audio);
      srcNode.connect(master);
    } catch {
      // Fallback : volume géré directement sur l'élément audio
      audio.volume = volume;
    }
    audio.play().catch(() => {});
    stopFns.push(() => {
      try { audio.pause(); } catch { /* noop */ }
      audio.src = "";
    });
  } else if (kind === "rain") {
    // Enregistrement réel de pluie d'orage, joué en boucle.
    const audio = new Audio(pluieAsset.url);
    audio.loop = true;
    audio.crossOrigin = "anonymous";
    audio.preload = "auto";
    try {
      const srcNode = ctx.createMediaElementSource(audio);
      srcNode.connect(master);
    } catch {
      audio.volume = volume;
    }
    audio.play().catch(() => {});
    stopFns.push(() => {
      try { audio.pause(); } catch { /* noop */ }
      audio.src = "";
    });
  } else if (kind === "birds") {
    // Enregistrement réel de chants d'oiseaux, joué en boucle.
    const audio = new Audio(oiseauxAsset.url);
    audio.loop = true;
    audio.crossOrigin = "anonymous";
    audio.preload = "auto";
    try {
      const srcNode = ctx.createMediaElementSource(audio);
      srcNode.connect(master);
    } catch {
      audio.volume = volume;
    }
    audio.play().catch(() => {});
    stopFns.push(() => {
      try { audio.pause(); } catch { /* noop */ }
      audio.src = "";
    });
  }

  return {
    ctx,
    setVolume: (v: number) => { master.gain.value = v; },
    stop: () => {
      stopFns.forEach((fn) => fn());
      ctx.close().catch(() => {});
    },
  };
}