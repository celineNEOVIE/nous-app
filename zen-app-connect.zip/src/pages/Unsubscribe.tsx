import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

type State = "loading" | "valid" | "already" | "invalid" | "success" | "error";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;

export default function Unsubscribe() {
  const [params] = useSearchParams();
  const token = params.get("token") ?? "";
  const [state, setState] = useState<State>("loading");
  const [email, setEmail] = useState<string>("");

  useEffect(() => {
    if (!token) { setState("invalid"); return; }
    (async () => {
      try {
        const res = await fetch(`${SUPABASE_URL}/functions/v1/handle-email-unsubscribe?token=${encodeURIComponent(token)}`, {
          headers: { apikey: SUPABASE_ANON_KEY },
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) { setState("invalid"); return; }
        if (data?.alreadyUnsubscribed) { setState("already"); setEmail(data.email ?? ""); return; }
        setEmail(data?.email ?? "");
        setState("valid");
      } catch { setState("invalid"); }
    })();
  }, [token]);

  const confirm = async () => {
    try {
      const { error } = await supabase.functions.invoke("handle-email-unsubscribe", { body: { token } });
      setState(error ? "error" : "success");
    } catch { setState("error"); }
  };

  return (
    <main className="min-h-screen bg-[#F5F0E6] flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white/80 border border-sage-200 rounded-2xl p-8 text-center shadow-sm">
        <h1 className="text-2xl font-semibold text-[#8B4513] mb-4" style={{ fontFamily: "Alice, serif" }}>
          Désabonnement
        </h1>
        {state === "loading" && <p className="text-[#5C3A1E]">Vérification…</p>}
        {state === "invalid" && <p className="text-[#5C3A1E]">Ce lien est invalide ou a expiré.</p>}
        {state === "already" && <p className="text-[#5C3A1E]">{email || "Cette adresse"} est déjà désabonnée.</p>}
        {state === "valid" && (
          <>
            <p className="text-[#5C3A1E] mb-6">Confirmez-vous le désabonnement de <strong>{email}</strong> ?</p>
            <button onClick={confirm} className="px-5 py-2 rounded-lg bg-sage-200 text-sage-800 hover:bg-sage-300 transition-colors">
              Confirmer le désabonnement
            </button>
          </>
        )}
        {state === "success" && <p className="text-[#5C3A1E]">Vous êtes désabonné·e. Vous ne recevrez plus nos emails.</p>}
        {state === "error" && <p className="text-[#5C3A1E]">Une erreur est survenue. Merci de réessayer plus tard.</p>}
      </div>
    </main>
  );
}