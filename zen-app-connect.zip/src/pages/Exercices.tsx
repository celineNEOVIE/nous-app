import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { StressAssessment } from "@/components/stress-assessment";

const Exercices = () => {
  const navigate = useNavigate();
  const [open, setOpen] = useState(true);

  useEffect(() => {
    if (!open) navigate("/");
  }, [open, navigate]);

  return (
    <div className="min-h-[60vh] touch-pan-y bg-[#F5F0E6]" style={{ touchAction: "pan-y" }}>
      <StressAssessment open={open} onOpenChange={setOpen} targetView="tools" />
    </div>
  );
};

export default Exercices;