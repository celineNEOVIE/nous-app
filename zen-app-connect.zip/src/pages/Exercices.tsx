import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { StressAssessment } from "@/components/stress-assessment";

const Exercices = () => {
  const navigate = useNavigate();
  const [open, setOpen] = useState(true);

  useEffect(() => {
    if (!open) navigate("/");
  }, [open, navigate]);

  return (
    <div className="min-h-[60vh] touch-pan-y bg-[#F5F0E6]" style={{ touchAction: "pan-y" }}>
      <Helmet>
        <title>Exercices de relaxation — cohérence cardiaque & méditation | Noûs</title>
        <meta name="description" content="Exercices guidés de relaxation Noûs : cohérence cardiaque, méditations, jardin zen et sons de la nature pour apaiser stress et anxiété en quelques minutes." />
        <link rel="canonical" href="https://app-nous.fr/exercices" />
        <meta property="og:title" content="Exercices de relaxation — Noûs" />
        <meta property="og:description" content="Cohérence cardiaque, méditations guidées et exercices anti-stress à pratiquer en quelques minutes." />
        <meta property="og:url" content="https://app-nous.fr/exercices" />
        <meta property="og:type" content="website" />
      </Helmet>
      <h1 className="sr-only">Exercices de relaxation Noûs</h1>
      <StressAssessment open={open} onOpenChange={setOpen} targetView="tools" />
    </div>
  );
};

export default Exercices;