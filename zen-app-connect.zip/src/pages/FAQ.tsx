import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ChatWidget } from "@/components/chat-widget";

type FAQItem = {
  question: string;
  answer: string;
};

type FAQSection = {
  title: string;
  items: FAQItem[];
};

const sections: FAQSection[] = [
  {
    title: "Le service",
    items: [
      {
        question: "Comment se déroule une consultation avec un praticien ?",
        answer:
          "Après votre demande, un membre de notre équipe vous recontacte pour convenir d'un rendez-vous par téléphone ou en visio, selon vos disponibilités et celles du praticien choisi.",
      },
      {
        question: "Combien de temps pour être recontacté après une demande de RDV ?",
        answer:
          "Nous nous efforçons de vous recontacter dans les meilleurs délais, généralement sous quelques jours ouvrés.",
      },
      {
        question:
          "Les consultations sont-elles remboursées par la sécurité sociale ou les mutuelles ?",
        answer:
          "Cela dépend de votre mutuelle et du type de praticien consulté. Nous vous conseillons de vérifier directement auprès de votre organisme.",
      },
      {
        question:
          "Cet outil remplace-t-il un avis médical ou psychologique ?",
        answer:
          "Non. Cet outil ne constitue ni un diagnostic ni un suivi médical. Il vise à vous accompagner et à vous orienter vers des ressources ou des professionnels adaptés. En cas de besoin, consultez un médecin ou un professionnel de santé.",
      },
    ],
  },
  {
    title: "Crédit d'impôt",
    items: [
      {
        question: "Puis-je bénéficier d'un crédit d'impôt pour les consultations ?",
        answer:
          'Notre service est agréé « services à la personne » (SAP 904239720), ce qui donne droit à un crédit d\'impôt selon l\'article 199 sexdecies du CGI. Vérifiez votre éligibilité et renseignements au 07.75.76.76.37.',
      },
    ],
  },
  {
    title: "Données et confidentialité",
    items: [
      {
        question: "Mes réponses au questionnaire sont-elles enregistrées ?",
        answer:
          "Non, vos réponses aux questionnaires restent uniquement sur votre appareil et ne sont pas transmises à un serveur.",
      },
      {
        question:
          "Mes données personnelles (nom, téléphone) sont-elles partagées avec des tiers ?",
        answer:
          "Non. Les informations transmises via le formulaire « Être rappelé(e) » sont utilisées uniquement pour vous mettre en relation avec le praticien concerné.",
      },
      {
        question: "Puis-je demander la suppression de mes données ?",
        answer:
          "Oui, vous pouvez nous contacter à tout moment pour demander la suppression de vos données personnelles, conformément à la réglementation en vigueur (RGPD).",
      },
    ],
  },
  {
    title: "Nos praticiens",
    items: [
      {
        question: "Comment les praticiens sont-ils sélectionnés ?",
        answer:
          "Notre service est agréé « services à la personne », et nos praticiens sont sélectionnés pour leur expérience et leurs qualifications dans leur domaine.",
      },
      {
        question: "Puis-je choisir mon praticien ?",
        answer:
          "Oui, vous pouvez choisir librement le praticien qui vous correspond parmi notre équipe.",
      },
    ],
  },
];

export default function FAQ() {
  return (
    <div className="min-h-screen bg-[#F5F0E6]">
      <main className="container px-4 py-12 mx-auto sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <h1 className="mb-8 text-3xl font-bold text-center text-[#8B4513] font-alice">
            Foire aux questions
          </h1>

          <div className="space-y-8">
            {sections.map((section) => (
              <section key={section.title}>
                <h2 className="mb-4 text-xl font-semibold text-[#8B4513]">
                  {section.title}
                </h2>
                {section.items.length > 0 ? (
                  <Accordion type="single" collapsible className="w-full">
                    {section.items.map((item, idx) => (
                      <AccordionItem
                        key={idx}
                        value={`${section.title}-${idx}`}
                        className="border border-[#E3E9E3] rounded-lg mb-3 bg-white/60 px-4"
                      >
                        <AccordionTrigger className="text-left text-[#A0522D] font-medium hover:no-underline py-4">
                          {item.question}
                        </AccordionTrigger>
                        <AccordionContent className="text-[#6b4f3a] leading-relaxed pb-4">
                          {item.answer}
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                ) : (
                  <p className="text-[#A0522D]/70 italic">
                    Contenu à venir.
                  </p>
                )}
              </section>
            ))}
          </div>
        </div>
      </main>
      <ChatWidget />
    </div>
  );
}
