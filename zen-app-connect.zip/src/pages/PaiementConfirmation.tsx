import { Link, useSearchParams } from "react-router-dom";
import { ImageWithFallback } from "@/components/image-with-fallback";

export default function PaiementConfirmation() {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get("session_id");

  return (
    <main className="min-h-screen bg-gradient-to-b from-[#F5F0E6] via-[#F5F0E6] to-[#EFE6D6] flex items-center justify-center px-4 py-12">
      <div className="max-w-xl w-full text-center">
        {/* Nuage logo animé */}
        <div className="mb-8">
          <ImageWithFallback
            src="/lovable-uploads/1919c5e1-b704-4470-9256-3863b6b72f49.png"
            alt="Noûs"
            className="h-44 w-auto mx-auto animate-breathe-coherence"
            loading="eager"
          />
        </div>

        {sessionId ? (
          <>
            <h1
              className="text-3xl md:text-4xl font-semibold text-[#8B4513] mb-4"
              style={{ fontFamily: "Alice, serif" }}
            >
              Merci pour votre confiance 🌿
            </h1>
            <p className="text-[#5C3A1E] leading-relaxed mb-3 text-base md:text-lg">
              Votre réservation est confirmée. Vous allez recevoir un email de
              confirmation dans quelques instants.
            </p>
            <p
              className="text-[#A0522D] italic mb-10 text-base md:text-lg"
              style={{ fontFamily: "Alice, serif" }}
            >
              Prenez un instant pour vous… respirez.
            </p>

            {/* Texte de respiration synchronisé avec le nuage */}
            <div className="relative h-8 mb-12">
              <span className="absolute inset-0 text-sm md:text-base tracking-[0.3em] uppercase text-sage-600 animate-inhale-text">
                Inspirez…
              </span>
              <span className="absolute inset-0 text-sm md:text-base tracking-[0.3em] uppercase text-sage-600 animate-exhale-text">
                Expirez…
              </span>
            </div>

            <p className="text-[10px] text-[#A0522D]/50 mb-8 break-all">
              Réf. {sessionId}
            </p>
          </>
        ) : (
          <>
            <h1
              className="text-3xl font-semibold text-[#8B4513] mb-4"
              style={{ fontFamily: "Alice, serif" }}
            >
              Aucune information de paiement
            </h1>
            <p className="text-[#5C3A1E] leading-relaxed mb-10">
              Nous n'avons pas trouvé d'identifiant de session.
            </p>
          </>
        )}

        <Link
          to="/"
          className="inline-block px-6 py-3 text-sm font-medium rounded-lg bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300 transition-colors"
        >
          Retourner à l'accueil
        </Link>
      </div>
    </main>
  );
}