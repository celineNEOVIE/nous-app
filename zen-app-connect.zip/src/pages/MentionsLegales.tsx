import { Link } from "react-router-dom";

export default function MentionsLegales() {
  return (
    <div className="min-h-screen bg-[#F5F0E6]">
      <main className="container px-4 py-12 mx-auto sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <h1 className="mb-8 text-3xl font-bold text-[#8B4513] font-alice">
            Mentions légales
          </h1>

          <div className="space-y-8">
            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                Éditeur du site
              </h2>
              <p className="text-[#6b4f3a] leading-relaxed">
                Le site Noûs est édité par la société <strong>NEOVIE</strong>, SASU au capital de 1 000 €, immatriculée au RCS sous le numéro SIRET 904 239 720, dont le siège social est situé 35 avenue Font de Veyre, Le Santa Barbara, 06150 Cannes.
              </p>
              <ul className="mt-2 space-y-1 text-[#6b4f3a] leading-relaxed list-disc list-inside">
                <li>Numéro d'agrément Services à la Personne : SAP 904239720</li>
                <li>Contact : contactneovie@gmail.com</li>
              </ul>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                Hébergement
              </h2>
              <p className="text-[#6b4f3a] leading-relaxed">
                Le site est hébergé par Lovable Labs Incorporated.
              </p>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                Directeur de la publication
              </h2>
              <p className="text-[#6b4f3a] leading-relaxed">
                <strong>Céline Chauchet</strong>, en qualité de Présidente de la SASU NEOVIE.
              </p>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                Propriété intellectuelle
              </h2>
              <p className="text-[#6b4f3a] leading-relaxed">
                L'ensemble des contenus présents sur ce site (textes, logo, illustrations, structure, sons, animations) est la propriété exclusive de NEOVIE, sauf mention contraire. La marque « Noûs » ainsi que le logo associé ont fait l'objet d'un dépôt de marque semi-figurative auprès de l'Institut National de la Propriété Industrielle (INPI). Toute reproduction, représentation, modification ou exploitation, totale ou partielle, de ces éléments sans autorisation écrite préalable de NEOVIE est strictement interdite et constituerait une contrefaçon sanctionnée par les articles L.335-2 et suivants du Code de la propriété intellectuelle.
              </p>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                Protection des données personnelles (RGPD)
              </h2>
              <h3 className="mt-4 mb-2 text-lg font-semibold text-[#8B4513]">Responsable du traitement</h3>
              <p className="text-[#6b4f3a] leading-relaxed">
                NEOVIE, SASU — 35 avenue Font de Veyre, Le Santa Barbara, 06150 Cannes
              </p>
              <p className="text-[#6b4f3a] leading-relaxed">SIRET : 904 239 720</p>
              <p className="text-[#6b4f3a] leading-relaxed">Contact : contactneovie@gmail.com</p>

              <h3 className="mt-4 mb-2 text-lg font-semibold text-[#8B4513]">Données collectées et finalités</h3>
              <p className="text-[#6b4f3a] leading-relaxed">
                Noûs collecte uniquement les données strictement nécessaires à la fourniture de ses services, conformément au principe de minimisation des données (article 5 du RGPD).
              </p>

              <h4 className="mt-3 mb-1 font-semibold text-[#6b4f3a]">Création de compte et authentification</h4>
              <ul className="space-y-1 text-[#6b4f3a] leading-relaxed list-disc list-inside">
                <li>Données : adresse e-mail, mot de passe (chiffré), prénom.</li>
                <li>Finalité : gestion de votre compte utilisateur et sécurisation de l'accès au service.</li>
                <li>Base légale : exécution du contrat (article 6.1.b du RGPD).</li>
              </ul>

              <h4 className="mt-3 mb-1 font-semibold text-[#6b4f3a]">Réservation et paiement d'une séance</h4>
              <ul className="space-y-1 text-[#6b4f3a] leading-relaxed list-disc list-inside">
                <li>Données : prénom, nom, adresse e-mail, informations de paiement traitées exclusivement par Stripe — NEOVIE ne conserve aucune donnée bancaire.</li>
                <li>Finalité : traitement de la réservation, confirmation, gestion comptable.</li>
                <li>Base légale : exécution du contrat (article 6.1.b) et obligation légale pour les documents comptables (article 6.1.c).</li>
              </ul>

              <h4 className="mt-3 mb-1 font-semibold text-[#6b4f3a]">Demande de rappel par un praticien</h4>
              <ul className="space-y-1 text-[#6b4f3a] leading-relaxed list-disc list-inside">
                <li>Données : prénom, numéro de téléphone, créneaux de disponibilité.</li>
                <li>Finalité : mise en relation avec un praticien partenaire.</li>
                <li>Base légale : consentement de l'utilisateur (article 6.1.a du RGPD).</li>
                <li>Durée de conservation : suppression dès que la mise en relation est effectuée.</li>
              </ul>

              <h4 className="mt-3 mb-1 font-semibold text-[#6b4f3a]">Questionnaires de bien-être</h4>
              <p className="text-[#6b4f3a] leading-relaxed">
                Les réponses aux questionnaires de bien-être ne sont pas transmises ni enregistrées sur nos serveurs. Elles restent uniquement sur votre appareil et ne font l'objet d'aucun traitement par NEOVIE.
              </p>

              <h4 className="mt-3 mb-1 font-semibold text-[#6b4f3a]">Communications transactionnelles</h4>
              <ul className="space-y-1 text-[#6b4f3a] leading-relaxed list-disc list-inside">
                <li>Données : adresse e-mail.</li>
                <li>Finalité : envoi des confirmations de réservation et rappels de séance.</li>
                <li>Base légale : exécution du contrat (article 6.1.b).</li>
                <li>Prestataire d'envoi : Resend (conforme RGPD).</li>
              </ul>

              <h3 className="mt-4 mb-2 text-lg font-semibold text-[#8B4513]">Données de santé</h3>
              <p className="text-[#6b4f3a] leading-relaxed">
                L'application Noûs accompagne des démarches de bien-être. Dans la mesure où certaines informations partagées lors des séances avec un praticien peuvent relever de données de santé au sens de l'article 9 du RGPD, NEOVIE ne collecte, ne stocke ni ne traite ces données. Elles restent dans le cadre strictement confidentiel de la relation entre l'utilisateur et le praticien.
              </p>

              <h3 className="mt-4 mb-2 text-lg font-semibold text-[#8B4513]">Destinataires des données</h3>
              <p className="text-[#6b4f3a] leading-relaxed">
                Vos données ne sont jamais vendues ni cédées à des tiers à des fins commerciales. Elles peuvent être transmises uniquement aux sous-traitants strictement nécessaires au fonctionnement du service :
              </p>
              <ul className="mt-2 space-y-1 text-[#6b4f3a] leading-relaxed list-disc list-inside">
                <li>Stripe : traitement sécurisé des paiements</li>
                <li>Resend : envoi des e-mails transactionnels</li>
                <li>Lovable / Supabase : hébergement de l'application et de la base de données</li>
              </ul>
              <p className="mt-2 text-[#6b4f3a] leading-relaxed">
                Ces prestataires sont contractuellement tenus de respecter la confidentialité et la sécurité de vos données conformément au RGPD.
              </p>

              <h3 className="mt-4 mb-2 text-lg font-semibold text-[#8B4513]">Durée de conservation</h3>
              <ul className="space-y-1 text-[#6b4f3a] leading-relaxed list-disc list-inside">
                <li>Données de compte : jusqu'à suppression du compte, puis 3 ans</li>
                <li>Données de réservation : 5 ans (obligation comptable légale)</li>
                <li>Demande de rappel : durée de traitement de la demande uniquement</li>
                <li>E-mails transactionnels : 1 an</li>
              </ul>

              <h3 className="mt-4 mb-2 text-lg font-semibold text-[#8B4513]">Vos droits</h3>
              <p className="text-[#6b4f3a] leading-relaxed">
                Conformément aux articles 15 à 22 du RGPD, vous disposez des droits suivants :
              </p>
              <ul className="mt-2 space-y-1 text-[#6b4f3a] leading-relaxed list-disc list-inside">
                <li>Droit d'accès : obtenir une copie de vos données</li>
                <li>Droit de rectification : corriger des données inexactes</li>
                <li>Droit à l'effacement : demander la suppression de vos données</li>
                <li>Droit à la portabilité : recevoir vos données dans un format structuré</li>
                <li>Droit d'opposition : vous opposer à un traitement basé sur l'intérêt légitime</li>
                <li>Droit de retrait du consentement : à tout moment, sans effet rétroactif</li>
              </ul>
              <p className="mt-2 text-[#6b4f3a] leading-relaxed">
                Pour exercer ces droits : contactneovie@gmail.com. Réponse sous 30 jours maximum.
              </p>
              <p className="mt-2 text-[#6b4f3a] leading-relaxed">
                En cas de réclamation non résolue, vous pouvez saisir la CNIL : www.cnil.fr — 3 place de Fontenoy, 75007 Paris.
              </p>

              <h3 className="mt-4 mb-2 text-lg font-semibold text-[#8B4513]">Sécurité des données</h3>
              <p className="text-[#6b4f3a] leading-relaxed">
                NEOVIE met en œuvre les mesures techniques et organisationnelles appropriées pour protéger vos données : chiffrement des mots de passe, connexions sécurisées (HTTPS), accès restreint aux données personnelles.
              </p>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                Cookies et traceurs
              </h2>
              <h3 className="mt-2 mb-2 text-lg font-semibold text-[#8B4513]">Qu'est-ce qu'un cookie ?</h3>
              <p className="text-[#6b4f3a] leading-relaxed">
                Un cookie est un petit fichier texte déposé sur votre terminal lors de votre navigation sur l'application Noûs. Il permet d'assurer le bon fonctionnement des services proposés.
              </p>

              <h3 className="mt-4 mb-2 text-lg font-semibold text-[#8B4513]">Les cookies utilisés par Noûs</h3>
              <p className="text-[#6b4f3a] leading-relaxed">
                Noûs n'utilise que des cookies strictement nécessaires à la fourniture du service. Aucun cookie publicitaire, de profilage ou de suivi comportemental n'est utilisé.
              </p>

              <h4 className="mt-3 mb-1 font-semibold text-[#6b4f3a]">Cookies de session et d'authentification</h4>
              <p className="text-[#6b4f3a] leading-relaxed">
                Ces cookies maintiennent votre connexion active, sécurisent votre compte et mémorisent vos préférences de session. Ils sont supprimés à la fermeture de l'application ou à l'expiration de la session.
              </p>

              <h4 className="mt-3 mb-1 font-semibold text-[#6b4f3a]">Cookies liés au paiement sécurisé (Stripe)</h4>
              <p className="text-[#6b4f3a] leading-relaxed">
                Lors du règlement d'une séance, Stripe dépose des cookies techniques strictement nécessaires à la sécurisation de la transaction et à la prévention de la fraude. NEOVIE ne conserve à aucun moment vos coordonnées bancaires. Stripe est certifié PCI-DSS. Politique de confidentialité Stripe :{" "}
                <a href="https://stripe.com/fr/privacy" target="_blank" rel="noopener noreferrer" className="underline">https://stripe.com/fr/privacy</a>
              </p>

              <h3 className="mt-4 mb-2 text-lg font-semibold text-[#8B4513]">Base légale</h3>
              <p className="text-[#6b4f3a] leading-relaxed">
                Conformément à l'article 82 de la loi Informatique et Libertés et aux lignes directrices de la CNIL, ces cookies sont exemptés de consentement préalable car strictement nécessaires au service. Noûs vous en informe par souci de transparence.
              </p>

              <h3 className="mt-4 mb-2 text-lg font-semibold text-[#8B4513]">Gestion des cookies</h3>
              <p className="text-[#6b4f3a] leading-relaxed">
                Vous pouvez configurer votre appareil pour refuser ou supprimer les cookies, toutefois cela pourrait altérer le fonctionnement de l'application (connexion, paiement). Paramètres selon votre navigateur :
              </p>
              <ul className="mt-2 space-y-1 text-[#6b4f3a] leading-relaxed list-disc list-inside">
                <li>Safari (iOS) : Réglages &gt; Safari &gt; Confidentialité</li>
                <li>Chrome : Paramètres &gt; Confidentialité et sécurité &gt; Cookies</li>
                <li>Firefox : Options &gt; Vie privée et sécurité</li>
              </ul>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                Limitation de responsabilité
              </h2>
              <p className="text-[#6b4f3a] leading-relaxed">
                Les informations et exercices proposés sur ce site (méditations, cohérence cardiaque, questionnaires, exercices de détente) sont fournis à titre informatif et de bien-être personnel. Ils ne remplacent en aucun cas un avis médical, un diagnostic ou un traitement par un professionnel de santé. En cas de doute, de difficulté psychologique ou de symptômes persistants, consultez un médecin ou un professionnel de santé qualifié.
              </p>
              <p className="mt-2 text-[#6b4f3a] leading-relaxed">
                NEOVIE ne saurait être tenue responsable des décisions prises par l'utilisateur sur la base des contenus de l'application, ni des éventuels dommages directs ou indirects qui en résulteraient. Les praticiens référencés sur la plateforme Noûs exercent en toute indépendance et sont seuls responsables des séances qu'ils dispensent.
              </p>
            </section>

            <div className="pt-6">
              <Link
                to="/"
                className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium rounded-lg bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300 transition-colors"
              >
                Retour à l'accueil
              </Link>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
