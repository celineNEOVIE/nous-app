import { Link } from "react-router-dom";

export default function PolitiqueConfidentialite() {
  return (
    <div className="min-h-screen bg-[#F5F0E6]">
      <main className="container px-4 py-12 mx-auto sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <h1 className="mb-2 text-3xl font-bold text-[#8B4513] font-alice">
            Politique de confidentialité
          </h1>
          <p className="mb-8 text-sm text-[#6b4f3a]">
            Dernière mise à jour : 23 juin 2026
          </p>

          <div className="space-y-8">
            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                1. Qui sommes-nous ?
              </h2>
              <div className="space-y-3 text-[#6b4f3a] leading-relaxed">
                <p>
                  <strong>NEOVIE</strong>, SASU au capital de 1 000 €, immatriculée au RCS de Cannes sous le numéro SIRET 904 239 720, agréée Services à la Personne sous le numéro SAP 904239720, édite l'application de bien-être Noûs (app-nous.fr).
                </p>
                <p>
                  Céline Chauchet, Présidente, est responsable du traitement des données personnelles collectées via l'application.
                </p>
                <p>
                  Pour toute question relative à vos données personnelles :{" "}
                  <a href="mailto:contactneovie@gmail.com" className="underline hover:text-[#8B4513]">
                    contactneovie@gmail.com
                  </a>
                </p>
              </div>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                2. Quelles données collectons-nous ?
              </h2>
              <div className="space-y-4 text-[#6b4f3a] leading-relaxed">
                <div>
                  <h3 className="font-semibold text-[#8B4513]">Données de compte et d'authentification</h3>
                  <p>Lors de la création de votre compte Noûs, nous collectons votre adresse e-mail, votre prénom et un mot de passe chiffré. Ces données sont nécessaires à l'accès sécurisé à votre espace personnel.</p>
                </div>
                <div>
                  <h3 className="font-semibold text-[#8B4513]">Questionnaires de bien-être</h3>
                  <p>Vos réponses aux questionnaires (évaluation du stress, burn-out, deuil, etc.) ne sont jamais transmises à nos serveurs ni enregistrées. Elles restent uniquement sur votre appareil et sont effacées dès que vous fermez ou rechargez l'application. NEOVIE n'a à aucun moment accès à ces réponses.</p>
                </div>
                <div>
                  <h3 className="font-semibold text-[#8B4513]">Formulaire "Être rappelé(e)"</h3>
                  <p>Si vous demandez à être recontacté(e) par un praticien, nous collectons votre prénom, votre numéro de téléphone et vos créneaux de disponibilité préférés.</p>
                </div>
                <div>
                  <h3 className="font-semibold text-[#8B4513]">Réservation et paiement d'une séance</h3>
                  <p>Lors de la réservation d'une séance, nous collectons votre prénom, nom et adresse e-mail. Le paiement est traité exclusivement par notre prestataire Stripe. NEOVIE ne collecte ni ne conserve aucune donnée bancaire. Stripe est certifié PCI-DSS niveau 1, garantissant le plus haut niveau de sécurité pour vos transactions.</p>
                </div>
                <div>
                  <h3 className="font-semibold text-[#8B4513]">Communications transactionnelles</h3>
                  <p>Votre adresse e-mail est utilisée pour vous envoyer les confirmations de réservation et les rappels de séance, via notre prestataire Resend.</p>
                </div>
                <div>
                  <h3 className="font-semibold text-[#8B4513]">Données de navigation technique</h3>
                  <p>Des données techniques anonymes (type d'appareil, système d'exploitation, langue) peuvent être collectées automatiquement par l'infrastructure d'hébergement Lovable/Supabase pour assurer le bon fonctionnement de l'application. Ces données ne permettent pas de vous identifier personnellement.</p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                3. Pourquoi collectons-nous ces données ?
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-[#6b4f3a] border border-[#d9c9b3]">
                  <thead className="bg-[#ece2d0]">
                    <tr>
                      <th className="px-3 py-2 text-left font-semibold text-[#8B4513] border border-[#d9c9b3]">Donnée</th>
                      <th className="px-3 py-2 text-left font-semibold text-[#8B4513] border border-[#d9c9b3]">Finalité</th>
                      <th className="px-3 py-2 text-left font-semibold text-[#8B4513] border border-[#d9c9b3]">Base légale (RGPD)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr><td className="px-3 py-2 border border-[#d9c9b3]">Compte utilisateur</td><td className="px-3 py-2 border border-[#d9c9b3]">Accès sécurisé à l'application</td><td className="px-3 py-2 border border-[#d9c9b3]">Exécution du contrat — art. 6.1.b</td></tr>
                    <tr><td className="px-3 py-2 border border-[#d9c9b3]">Demande de rappel</td><td className="px-3 py-2 border border-[#d9c9b3]">Mise en relation avec un praticien</td><td className="px-3 py-2 border border-[#d9c9b3]">Consentement — art. 6.1.a</td></tr>
                    <tr><td className="px-3 py-2 border border-[#d9c9b3]">Réservation / paiement</td><td className="px-3 py-2 border border-[#d9c9b3]">Traitement de la séance et facturation</td><td className="px-3 py-2 border border-[#d9c9b3]">Exécution du contrat — art. 6.1.b</td></tr>
                    <tr><td className="px-3 py-2 border border-[#d9c9b3]">Documents comptables</td><td className="px-3 py-2 border border-[#d9c9b3]">Obligation légale de conservation</td><td className="px-3 py-2 border border-[#d9c9b3]">Obligation légale — art. 6.1.c</td></tr>
                    <tr><td className="px-3 py-2 border border-[#d9c9b3]">E-mails transactionnels</td><td className="px-3 py-2 border border-[#d9c9b3]">Confirmation et suivi de séance</td><td className="px-3 py-2 border border-[#d9c9b3]">Exécution du contrat — art. 6.1.b</td></tr>
                  </tbody>
                </table>
              </div>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                4. Qui a accès à vos données ?
              </h2>
              <div className="space-y-3 text-[#6b4f3a] leading-relaxed">
                <p>Vos données ne sont jamais vendues, louées ni cédées à des tiers à des fins commerciales.</p>
                <p>Elles sont accessibles uniquement aux personnes et prestataires suivants, dans la stricte limite de leurs missions :</p>
                <ul className="list-disc list-inside space-y-1">
                  <li><strong>L'équipe NEOVIE</strong> : accès limité à la gestion des demandes et des réservations</li>
                  <li><strong>Le praticien concerné</strong> : accès uniquement aux informations nécessaires à la prise de contact (prénom, téléphone, créneaux) dans le cadre de votre demande</li>
                  <li><strong>Stripe</strong> : traitement sécurisé des paiements — politique disponible sur stripe.com/fr/privacy</li>
                  <li><strong>Resend</strong> : envoi des e-mails transactionnels — conforme RGPD</li>
                  <li><strong>Lovable / Supabase</strong> : hébergement de l'application et de la base de données</li>
                </ul>
                <p>Les praticiens référencés sur Noûs exercent en toute indépendance. Ils sont soumis à leurs propres obligations de confidentialité dans le cadre des séances qu'ils dispensent.</p>
              </div>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                5. Combien de temps conservons-nous vos données ?
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-[#6b4f3a] border border-[#d9c9b3]">
                  <thead className="bg-[#ece2d0]">
                    <tr>
                      <th className="px-3 py-2 text-left font-semibold text-[#8B4513] border border-[#d9c9b3]">Donnée</th>
                      <th className="px-3 py-2 text-left font-semibold text-[#8B4513] border border-[#d9c9b3]">Durée de conservation</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr><td className="px-3 py-2 border border-[#d9c9b3]">Données de compte</td><td className="px-3 py-2 border border-[#d9c9b3]">Jusqu'à suppression du compte, puis 3 ans</td></tr>
                    <tr><td className="px-3 py-2 border border-[#d9c9b3]">Demande de rappel</td><td className="px-3 py-2 border border-[#d9c9b3]">Durée de traitement de la demande, puis suppression immédiate</td></tr>
                    <tr><td className="px-3 py-2 border border-[#d9c9b3]">Données de réservation</td><td className="px-3 py-2 border border-[#d9c9b3]">5 ans (obligation comptable légale)</td></tr>
                    <tr><td className="px-3 py-2 border border-[#d9c9b3]">E-mails transactionnels</td><td className="px-3 py-2 border border-[#d9c9b3]">1 an</td></tr>
                    <tr><td className="px-3 py-2 border border-[#d9c9b3]">Données de paiement (Stripe)</td><td className="px-3 py-2 border border-[#d9c9b3]">Selon politique Stripe, max. 13 mois</td></tr>
                  </tbody>
                </table>
              </div>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                6. Vos droits
              </h2>
              <p className="text-[#6b4f3a] leading-relaxed">
                Conformément aux articles 15 à 22 du RGPD, vous disposez des droits suivants sur vos données personnelles :
              </p>
              <ul className="mt-2 space-y-1 text-[#6b4f3a] leading-relaxed list-disc list-inside">
                <li><strong>Droit d'accès</strong> : obtenir une copie des données vous concernant</li>
                <li><strong>Droit de rectification</strong> : faire corriger des données inexactes ou incomplètes</li>
                <li><strong>Droit à l'effacement</strong> : demander la suppression de vos données, dans les limites des obligations légales de conservation</li>
                <li><strong>Droit à la portabilité</strong> : recevoir vos données dans un format structuré et lisible</li>
                <li><strong>Droit d'opposition</strong> : vous opposer à un traitement fondé sur l'intérêt légitime</li>
                <li><strong>Droit de retrait du consentement</strong> : retirer votre consentement à tout moment, sans que cela remette en cause les traitements antérieurs</li>
                <li><strong>Droit à la limitation du traitement</strong> : demander la suspension temporaire d'un traitement</li>
              </ul>
              <p className="mt-2 text-[#6b4f3a] leading-relaxed">
                Pour exercer ces droits, contactez-nous à{" "}
                <a
                  href="mailto:contactneovie@gmail.com"
                  className="underline hover:text-[#8B4513]"
                >
                  contactneovie@gmail.com
                </a>
                . Nous nous engageons à répondre dans un délai d'un mois. En cas de demande complexe, ce délai peut être prolongé de deux mois supplémentaires, avec information préalable.
              </p>
              <p className="mt-2 text-[#6b4f3a] leading-relaxed">
                Si vous estimez que vos droits ne sont pas respectés, vous avez le droit d'introduire une réclamation auprès de la CNIL : www.cnil.fr — 3 place de Fontenoy, 75007 Paris — Tél. 01 53 73 22 22.
              </p>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                7. Sécurité des données
              </h2>
              <p className="text-[#6b4f3a] leading-relaxed">
                NEOVIE met en œuvre les mesures techniques et organisationnelles appropriées pour protéger vos données personnelles contre tout accès non autorisé, perte, altération ou divulgation :
              </p>
              <ul className="mt-2 space-y-1 text-[#6b4f3a] leading-relaxed list-disc list-inside">
                <li>Chiffrement des mots de passe</li>
                <li>Connexions sécurisées via HTTPS</li>
                <li>Accès aux données restreint aux seules personnes habilitées</li>
                <li>Hébergement sur infrastructure sécurisée (Supabase/Lovable)</li>
                <li>Paiements traités par Stripe, certifié PCI-DSS niveau 1</li>
              </ul>
              <p className="mt-2 text-[#6b4f3a] leading-relaxed">
                En cas de violation de données susceptible d'engendrer un risque pour vos droits et libertés, NEOVIE s'engage à notifier la CNIL dans les 72 heures conformément à l'article 33 du RGPD, et à vous en informer si nécessaire.
              </p>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                8. Cookies et traceurs
              </h2>
              <div className="space-y-3 text-[#6b4f3a] leading-relaxed">
                <p>
                  L'application Noûs utilise uniquement des cookies techniques strictement nécessaires à son fonctionnement. Aucun cookie publicitaire, de profilage ou de suivi comportemental n'est utilisé.
                </p>
                <div>
                  <h3 className="font-semibold text-[#8B4513]">Cookies de session et d'authentification</h3>
                  <p>Ces cookies maintiennent votre connexion active et sécurisent l'accès à votre compte. Ils sont supprimés à la fermeture de l'application ou à l'expiration de la session.</p>
                </div>
                <div>
                  <h3 className="font-semibold text-[#8B4513]">Cookies liés au paiement sécurisé (Stripe)</h3>
                  <p>Lors du règlement d'une séance, Stripe dépose des cookies techniques nécessaires à la sécurisation de la transaction et à la prévention de la fraude. NEOVIE ne conserve aucune donnée bancaire. Politique de confidentialité Stripe : stripe.com/fr/privacy</p>
                </div>
                <div>
                  <h3 className="font-semibold text-[#8B4513]">Mesure d'audience anonyme (Google Analytics)</h3>
                  <p>
                    Noûs utilise Google Analytics (GA4) uniquement à des fins de mesure d'audience anonyme, afin de comprendre l'usage global de l'application et de l'améliorer. Cette mesure est configurée en mode strictement respectueux de la vie privée :
                  </p>
                  <ul className="mt-2 space-y-1 list-disc list-inside">
                    <li>Les adresses IP sont anonymisées avant tout traitement (<em>anonymize_ip</em>).</li>
                    <li>La personnalisation publicitaire est désactivée (<em>allow_ad_personalization_signals: false</em>).</li>
                    <li>Les signaux Google (Google Signals) sont désactivés (<em>allow_google_signals: false</em>), aucun croisement avec les données publicitaires Google n'est effectué.</li>
                    <li>Aucun stockage publicitaire ni identifiant publicitaire n'est utilisé.</li>
                    <li>Aucune donnée n'est partagée avec des tiers à des fins publicitaires ou commerciales.</li>
                  </ul>
                  <p className="mt-2">
                    En l'absence d'identifiants publicitaires et de croisement avec d'autres services, cette mesure d'audience anonyme est assimilée à un cookie strictement nécessaire au bon fonctionnement du service et est exemptée de consentement conformément aux lignes directrices de la CNIL.
                  </p>
                </div>
                <p>
                  Ces cookies étant strictement nécessaires au service, ils sont exemptés de consentement préalable conformément à l'article 82 de la loi Informatique et Libertés et aux lignes directrices de la CNIL.
                </p>
                <p>
                  Vous pouvez à tout moment gérer les cookies via les paramètres de votre appareil, sachant que leur désactivation pourrait altérer le fonctionnement de l'application.
                </p>
              </div>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                9. Données de santé
              </h2>
              <p className="text-[#6b4f3a] leading-relaxed">
                Certaines informations échangées lors de séances avec un praticien peuvent relever de données de santé, catégorie sensible au sens de l'article 9 du RGPD. NEOVIE ne collecte, ne stocke ni ne traite ces données. Elles restent dans le cadre strictement confidentiel de la relation entre vous et le praticien, qui est soumis à ses propres obligations déontologiques et légales.
              </p>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-semibold text-[#8B4513]">
                10. Modifications de la présente politique
              </h2>
              <p className="text-[#6b4f3a] leading-relaxed">
                Cette politique de confidentialité peut être mise à jour pour refléter les évolutions légales ou les changements apportés à l'application. La date de dernière mise à jour est indiquée en haut du document. En cas de modification substantielle, vous serez informé(e) par e-mail ou via une notification dans l'application.
              </p>
            </section>

            <div className="pt-6">
              <Link
                to="/"
                className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium rounded-lg bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300 transition-colors"
              >
                Retour à l'accueil
              </Link>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
