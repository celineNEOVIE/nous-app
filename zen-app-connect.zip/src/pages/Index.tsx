
import { useState } from "react";
import { useLocation } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { HeroSection } from "@/components/hero-section";
import { PractitionerCard } from "@/components/practitioner-card";
import { ChatWidget } from "@/components/chat-widget";
import { SplashScreen } from "@/components/splash-screen";
import { PlaneBanner } from "@/components/plane-banner";
import nathalieImg from "@/assets/nathalie-garnier.jpg.asset.json";
import claraImg from "@/assets/clara-regnier.jpg.asset.json";
import camilleImg from "@/assets/camille-chopinot.jpg.asset.json";
import laurenceImg from "@/assets/laurence-giudicelli.jpg.asset.json";
import sophieImg from "@/assets/sophie-clouet.jpg.asset.json";
import oceaneImg from "@/assets/oceane-danjon.jpg.asset.json";

const practitioners = [
  {
    name: "Camille Chopinot",
    image: camilleImg.url,
    specialties: [
      "Naturopathe certifié Fena",
      "Magnétiseur",
      "Thérapie psycho-corporelle",
      "Gestion des émotions",
      "Accompagnement mieux-être",
    ],
    experience: "",
    availableFor: ["phone", "video"] as Array<"video" | "phone">,
    tags: [],
    bioTitle: "Camille Chopinot",
    bio: (
      <>
        <p className="font-medium text-[#8B4513]">Quelques mots sur mon approche</p>
        <p>
          Je suis convaincu que notre santé est en lien direct avec nos
          émotions. Des émotions négatives, en circulant dans notre corps,
          vont être à l'origine de nombreuses maladies.
        </p>
        <p>
          Je ne traite donc pas uniquement le symptôme, mais je t'accompagne
          dans le processus de réparation de la cause profonde de la maladie
          (« le mal a dit »).
        </p>
        <p>
          Soins énergétiques (magnétiseur, Maître Reiki, coupeur de feu),
          thérapie psycho-corporelle (réparation des mémoires cellulaires),
          Naturopathie : différentes techniques qui vont me permettre
          d'adapter mes soins à ta situation en fonction de tes besoins.
        </p>
        <p>
          De te replacer dans une circulation énergétique, émotionnelle,
          psychologique et physiologique plus fluide, réveiller et dynamiser
          « la force vitale auto-guérisseuse » qui est en toi.
        </p>
        <p>
          Pour te permettre de mieux gérer ton stress, tes émotions, avoir
          plus de confiance en toi et viser une guérison durable.
        </p>
        <p className="font-medium text-[#8B4513]">Prêt(e) à transformer ta vie ?</p>
        <p>
          Première séance de 30 minutes gratuite par téléphone ou en visio
          pour voir si je suis la bonne personne pour vous accompagner.
        </p>
        <p className="font-medium text-[#8B4513]">Tarifs et prestations</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Soins énergétiques : 140 € pour 3 séances.</li>
          <li>
            Soin holistique : 90 € pour 1h30 dédiée à ton mieux-être
            (émotionnel, physique et énergétique).
          </li>
          <li>
            Thérapie brève holistique « Libère ton Potentiel et Retrouve un
            Équilibre Émotionnel » : 850 € avec 50 % de crédit d'impôts, soit
            seulement 425 € pour 10 séances.
          </li>
        </ul>
        <p className="font-medium text-[#8B4513]">Liens utiles</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>
            Site internet :{" "}
            <a href="https://camille-chopinot.fr/" target="_blank" rel="noopener noreferrer" className="text-sage-700 underline hover:text-sage-800">camille-chopinot.fr</a>
          </li>
          <li>
            YouTube :{" "}
            <a href="https://www.youtube.com/watch?v=Sf1oKm-T-5w&t=3s" target="_blank" rel="noopener noreferrer" className="text-sage-700 underline hover:text-sage-800">Voir la vidéo</a>
          </li>
        </ul>
      </>
    ),
    pricing: [
      { title: "Accompagnement mieux-être", subtitle: "1h30", price: "90 €", priceId: "camille_mieux_etre_90" },
      { title: "Thérapie brève équilibre durable", subtitle: "10 séances (425 € après 50% crédit d'impôts)", price: "850 €", priceId: "camille_therapie_breve_850" },
      { title: "Soins énergétiques", subtitle: "1 heure", price: "60 €", priceId: "camille_soin_energetique_60" },
      { title: "Soins énergétiques", subtitle: "3 séances", price: "140 €", priceId: "camille_soins_energetiques_140" },
    ],
  },
  {
    name: "Sophie Clouet",
    image: sophieImg.url,
    imagePosition: "object-top",
    specialties: ["Coach santé certifiée RNCP"],
    experience: "",
    availableFor: ["phone", "video"] as Array<"video" | "phone">,
    tags: ["Gestion du stress", "Burn-out", "Coaching santé"],
    bioTitle: "Sophie Clouet",
    bio: (
      <>
        <p className="font-medium text-[#8B4513]">Pourquoi je vous propose mon coaching</p>
        <p>
          J'ai eu un parcours riche et varié, avec plusieurs changements de
          carrière. J'ai d'abord été ingénieur en informatique pendant 10 ans
          avant d'effectuer une reconversion dans le monde médical.
        </p>
        <p>
          C'est en 2015 que j'ai donné une nouvelle direction à ma vie en
          choisissant d'accompagner l'humain à travers la maladie.
        </p>
        <p>
          En travaillant auprès de patients mais aussi en observant mes
          collègues à l'hôpital, j'ai vu comment les tensions émotionnelles et
          psychologiques pouvaient se transformer en maux physiques : insomnie,
          douleur, migraine, fatigue chronique…
        </p>
        <p>
          Je suis passée moi-même par ces difficultés, car à force de contenir,
          retenir, ne pas oser dire les choses et m'oublier, je suis arrivée à
          l'épuisement.
        </p>
        <p>
          C'est en comprenant ce lien intime entre stress, santé et affirmation
          de soi que j'ai choisi d'accompagner les personnes, et notamment les
          femmes, à retrouver leur énergie et leur équilibre.
        </p>
        <p>
          <a href="https://www.philo-sophie.fr" target="_blank" rel="noopener noreferrer" className="text-sage-700 underline hover:text-sage-800">www.philo-sophie.fr</a>
        </p>
      </>
    ),
    pricing: [
      { title: "Séance à l'unité", subtitle: "1 heure de coaching", price: "99 €", priceId: "sophie_seance_unite_99" },
      { title: "Séance découverte", subtitle: "1h30 pour découvrir le coaching", price: "115 €", priceId: "sophie_seance_decouverte_115" },
      { title: "Forfait mensuel", subtitle: "2 séances + programme en ligne", price: "250 €/mois", priceId: "sophie_forfait_mensuel_250" },
    ],
  },
  {
    name: "Nathalie Garnier",
    image: nathalieImg.url,
    specialties: ["Accompagnante bien-être", "Méditation"],
    experience: "",
    availableFor: ["video", "phone"] as Array<"video" | "phone">,
    tags: ["Gestion du stress", "Sommeil", "Anxiété"],
    bioTitle: "Nathalie Garnier",
    bio: (
      <>
        <p className="font-medium text-[#8B4513]">Trouvez l'Harmonie et l'Équilibre Intérieur</p>
        <p>
          Parce que vous traversez un moment particulier de votre vie, vous
          ressentez le besoin d'un accompagnement bienveillant et revitalisant.
          Nos séances holistiques sont conçues pour vous aider à avancer avec
          conscience et sérénité, et à recevoir l'énergie nécessaire pour
          surmonter les passages difficiles ou importants.
        </p>
        <p className="font-medium text-[#8B4513]">Détails du service</p>
        <p>
          Durée : 5 séances hebdomadaires, chacune d'environ 1h (parfois plus
          selon les besoins).
        </p>
        <p>Contenu de chaque séance :</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>
            Soin holistique à distance pour apaiser et harmoniser vos corps
            énergétiques, physiques et émotionnels.
          </li>
          <li>Guidance holistique avec informations et directions concrètes.</li>
          <li>Moment de relaxation et/ou méditation guidée.</li>
          <li>Outils concrets à intégrer dans votre vie quotidienne.</li>
          <li>
            Accès gratuit au groupe de méditation du dimanche matin en direct
            pendant toute la durée de l'accompagnement.
          </li>
          <li>Support téléphonique entre les séances, en cas de besoin.</li>
        </ul>
        <p className="font-medium text-[#8B4513]">Avantages</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Bien-être et sérénité : apaisement profond et harmonie intérieure.</li>
          <li>Guidance personnalisée adaptée à votre situation.</li>
          <li>Support continu tout au long de l'accompagnement.</li>
        </ul>
        <p className="font-medium text-[#8B4513]">Tarification</p>
        <p>5 séances : 250 € (50 € par séance).</p>
        <p>
          <a
            href="https://www.champasak-spa.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sage-700 underline hover:text-sage-800"
          >
            ESPACE BIEN-ÊTRE - CHAMPASAK SPA
          </a>
        </p>
        <p className="font-medium text-[#8B4513]">Réservez votre séance</p>
        <p>
          Je vous propose une première rencontre gratuite, afin d'évaluer
          ensemble si ces séances peuvent vous être bénéfiques.
        </p>
      </>
    ),
    pricing: [
      { title: "Forfait 5 séances", subtitle: "Accompagnement holistique complet", price: "250 €", priceId: "nathalie_forfait_5_250" },
    ],
  },
  {
    name: "Laurence Giudicelli",
    image: laurenceImg.url,
    imagePosition: "object-top",
    specialties: ["Psychothérapeute (n° RPPS)", "formatrice"],
    experience: "",
    availableFor: ["phone", "video"] as Array<"video" | "phone">,
    tags: ["Art-thérapeute", "Relations/Couple", "Energéticienne"],
    bioTitle: "Laurence Giudicelli",
    bio: (
      <>
        <p className="font-medium text-[#8B4513]">Co-fondatrice de Terre de Lune</p>
        <p className="italic">Psychothérapeute – Art-Thérapeute – Formatrice, Membre RPPS (Répertoire Partagé des Professionnels de Santé)</p>
        <p>
          Laurence Giudicelli s'engage pleinement à créer des ponts entre le
          professionnalisme et l'humanité, en veillant à ce que chaque démarche
          soit marquée par une authenticité profonde.
        </p>
        <p>
          Son approche repose sur la conviction que chaque personne mérite une
          attention personnalisée, et elle s'efforce d'apporter un soutien
          continu, empreint de bienveillance et de respect.
        </p>
        <p>
          Elle propose des rendez-vous individuels de psychothérapie analytique et humaniste.
        </p>
        <p>
          Ainsi que des soins énergétiques, afin de débloquer les nœuds émotionnels et d'aider à faire circuler l'énergie vitale à l'intérieur du corps et des organes.
        </p>
        <p>
          Psychothérapeute psychocorporelle, analytique et énergéticienne pour enfants, adultes, couples et familles.
        </p>
        <p className="font-medium text-[#8B4513]">Tarifs</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Séance adulte : 77 €</li>
          <li>Séance couple / famille : 94 €</li>
          <li>Séance soin Qi cleansing : 121 €</li>
        </ul>
        <p className="font-medium text-[#8B4513]">Sites web</p>
        <p>
          <a href="http://cabinetlg-psy.fr" target="_blank" rel="noopener noreferrer" className="text-sage-700 underline hover:text-sage-800">cabinetlg-psy.fr</a>
          {" — "}
          <a href="https://terredelune.fr" target="_blank" rel="noopener noreferrer" className="text-sage-700 underline hover:text-sage-800">terredelune.fr</a>
        </p>
      </>
    ),
    pricing: [
      { title: "Séance adulte", subtitle: "Psychothérapie individuelle", price: "77 €", priceId: "laurence_seance_adulte_77" },
      { title: "Séance couple / famille", subtitle: "Accompagnement relationnel", price: "94 €", priceId: "laurence_seance_couple_94" },
      { title: "Séance soin Qi cleansing", subtitle: "Soin énergétique", price: "121 €", priceId: "laurence_seance_qi_121" },
    ],
  },
  {
    name: "Clara Regnier",
    image: claraImg.url,
    imagePosition: "object-top",
    specialties: ["Therapeute holistique", "Formatrice"],
    experience: "",
    availableFor: ["phone", "video"] as Array<"video" | "phone">,
    tags: ["Gestion du stress", "Méditation", "Soins énergétiques"],
    bioTitle: "Clara Regnier",
    bio: (
      <>
        <p className="font-medium text-[#8B4513]">Juste un Instant pour Soi — Clara Regnier</p>
        <p>Envie de Paix, de Joie ? Je vous souhaite la Bienvenue !</p>
        <p>
          On dit que la Vie est faite de rencontres et qu'il n'y a pas de hasard, nous y sommes ! Ce petit clin d'œil de la Vie pour ouvrir le champ des possibles de cette transformation profonde, de se redécouvrir autrement.
        </p>
        <p className="italic">« Et, si j'osais être Heureux ?! »</p>
        <p>
          Comment m'y prendre, étape par étape : En Réharmonisant mes Energies et en Reprogrammant mon système.
        </p>
        <p>
          Les séances, qui vous sont proposées, vont permettre d'effectuer ce rééquilibrage, cette reprogrammation nécessaire afin que l'Energie de Vie puisse circuler de nouveau, là où les lots de souffrances personnelles, transgenerationnelles, les émotions et traumatismes ont été cristallisés.
        </p>
        <p>Ces thérapies sont dites courtes.</p>
        <p>
          Le but étant que vous retrouviez rapidement vos ressources et votre Joie, qui vous attend !
        </p>
        <p>
          Je vous accompagne — Juste un instantbpour Soi, Clara Regnier, Thérapeute Holistique et Enseignante de Méditation.
        </p>
        <p className="italic text-sm">
          Cet accompagnement ne remplace en aucun cas un suivi médical.
        </p>
        <p className="font-medium text-[#8B4513]">Tarifs</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>30 minutes Boost Relaxation séance énergétique : 45 €</li>
          <li>Réharmonisation énergétique avec reprogrammation cellulaire, coaching : 110 €</li>
          <li>Séance de suivi, coaching : 90 €</li>
        </ul>
        <p className="font-medium text-[#8B4513]">Formation</p>
        <p>Sur devis</p>
      </>
    ),
    pricing: [
      { title: "Boost Relaxation 30 min", subtitle: "Séance énergétique", price: "45 €", priceId: "clara_boost_relaxation_45" },
      { title: "Réharmonisation énergétique", subtitle: "Avec reprogrammation cellulaire et coaching", price: "110 €", priceId: "clara_reharmonisation_110" },
      { title: "Séance de suivi", subtitle: "Coaching", price: "90 €", priceId: "clara_suivi_90" },
    ],
  },
  {
    name: "Océane Danjon",
    image: oceaneImg.url,
    imagePosition: "object-top",
    specialties: ["Accompagnement psycho-corporel, systémique et créatif"],
    experience: "",
    availableFor: ["phone", "video"] as Array<"video" | "phone">,
    tags: ["Régulation corporelle", "Dynamique relationnelle"],
    bioTitle: "Océane Danjon – Odyssée",
    bio: (
      <>
        <p className="font-medium text-[#8B4513]">Co-fondatrice de Terre de Lune – Odyssée</p>
        <p className="italic">
          Accompagnement psycho-corporel, systémique et créatif
        </p>
        <p>
          Depuis plus de 10 ans, j'accompagne les personnes en quête de transformation personnelle à travers une approche globale qui relie le corps, les émotions, les relations et l'histoire de vie.
        </p>
        <p>
          Je propose des séances individuelles, des parcours d'accompagnement approfondis, des ateliers de groupe et des retraites immersives, destinés aux adultes souhaitant retrouver du sens, dépasser des schémas limitants et développer un meilleur alignement avec eux-mêmes.
        </p>
        <p>
          Mon approche est systémique, incarnée et expérientielle : elle prend en compte la personne dans sa globalité afin de favoriser des changements concrets, durables et profondément intégrés.
        </p>
        <p className="font-medium text-[#8B4513]">Contact</p>
        <p>Villa Serena – Le Cannet</p>
        <p>06 09 28 90 95</p>
      </>
    ),
    pricing: [
      { title: "Accompagnement psycho-corporel", subtitle: "Séance individuelle 1 heure", price: "77 €", priceId: "oceane_psycho_corporel_77" },
    ],
  },
];

const Index = () => {
  const location = useLocation();
  const [showSplash, setShowSplash] = useState(() => {
    if (typeof window === "undefined") return true;
    return sessionStorage.getItem("nous_splash_seen") !== "1";
  });
  return (
    <div className="min-h-screen bg-[#F5F0E6]">
      <Helmet>
        <title>Noûs — Praticiens bien-être certifiés en ligne</title>
        <meta name="description" content="Noûs, le zen en ligne. Sophrologues, naturopathes et thérapeutes certifiés pour un accompagnement holistique en visio ou par téléphone." />
        <link rel="canonical" href="https://app-nous.fr/" />
        <meta property="og:title" content="Noûs — Praticiens bien-être certifiés en ligne" />
        <meta property="og:description" content="Sophrologues, naturopathes et thérapeutes certifiés pour un accompagnement holistique en visio ou par téléphone." />
        <meta property="og:url" content="https://app-nous.fr/" />
      </Helmet>
      {showSplash && (
        <SplashScreen
          onFinish={() => {
            try {
              sessionStorage.setItem("nous_splash_seen", "1");
            } catch {
              /* ignore */
            }
            setShowSplash(false);
          }}
        />
      )}
      <HeroSection />
      <PlaneBanner key={location.key ?? "default"} />
      
      <div id="praticiens" className="max-w-3xl mx-auto mb-12 text-center scroll-mt-20">
        <h2 className="mb-4 text-3xl font-bold text-[#8B4513]">
          Nos Praticiens Bien-être
        </h2>
        <p className="text-lg text-[#A0522D]">
          Une équipe expérimentée à votre écoute
        </p>
      </div>
      
      <section className="py-12">
        <div className="container px-4 mx-auto sm:px-6 lg:px-8">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {practitioners.map((practitioner) => (
              <PractitionerCard key={practitioner.name} {...practitioner} />
            ))}
          </div>
        </div>
      </section>
      
      <ChatWidget />
    </div>
  );
};

export default Index;
