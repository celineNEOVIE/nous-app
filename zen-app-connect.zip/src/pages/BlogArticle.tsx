import { Link, useParams, Navigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { ArrowLeft } from "lucide-react";
import { articles } from "./Blog";

const articleContents: Record<string, JSX.Element> = {
  "stress-anxiete-difference": (
    <>
      <p className="lead">
        Nous utilisons souvent les mots «&nbsp;stress&nbsp;» et
        «&nbsp;anxiété&nbsp;» de manière interchangeable. Pourtant, ces deux
        états sont bien distincts et les comprendre, c'est déjà la première
        étape pour mieux les gérer.
      </p>

      <h2>Stress et anxiété : quelle différence&nbsp;?</h2>
      <p>
        Le <strong>stress</strong> est une réaction naturelle et temporaire à
        une situation identifiable&nbsp;: un délai serré au travail, un conflit,
        un examen. Une fois la situation passée, le stress disparaît. C'est un
        mécanisme de survie utile, il nous pousse à agir.
      </p>
      <p>
        L'<strong>anxiété</strong>, elle, persiste au-delà de la situation
        déclenchante. Elle s'installe, anticipe, imagine le pire même quand tout
        va bien en apparence. L'anxiété chronique épuise le système nerveux et
        peut finir par affecter la santé physique&nbsp;: tensions musculaires,
        troubles digestifs, fatigue persistante, palpitations.
      </p>
      <p>
        Dans les deux cas, le corps réagit de la même façon&nbsp;: il libère du
        cortisol et de l'adrénaline, met les muscles en tension et accélère le
        rythme cardiaque. La différence, c'est la durée et l'intensité.
      </p>

      <h2>Les signaux à ne pas ignorer</h2>
      <p>
        Le stress devient problématique quand il s'installe dans la durée.
        Quelques signaux d'alerte&nbsp;:
      </p>
      <ul>
        <li>Difficulté à déconnecter, même le week-end</li>
        <li>Irritabilité inhabituelle ou sautes d'humeur</li>
        <li>Troubles du sommeil récurrents</li>
        <li>Sensation d'être «&nbsp;à bout&nbsp;» sans raison apparente</li>
        <li>Douleurs physiques inexpliquées (nuque, dos, maux de tête)</li>
      </ul>
      <p>
        Si vous vous reconnaissez dans plusieurs de ces signes, il est temps de
        prendre soin de vous&nbsp;: pas demain, maintenant.
      </p>

      <h2>Ce que la science recommande</h2>
      <p>
        Les recherches en neurosciences et en psychologie convergent vers les
        mêmes conclusions&nbsp;: les techniques corps-esprit sont parmi les plus
        efficaces pour réguler le stress et l'anxiété.
      </p>
      <ul>
        <li>
          <strong>La respiration consciente</strong> agit directement sur le
          système nerveux autonome en quelques minutes.
        </li>
        <li>
          <strong>La méditation de pleine conscience</strong> réduit
          significativement les niveaux de cortisol après 8 semaines de pratique
          régulière.
        </li>
        <li>
          <strong>Les activités créatives douces</strong> — coloriage,
          jardinage, musique — activent un état de flow qui coupe le circuit de
          l'anxiété.
        </li>
        <li>
          <strong>L'accompagnement par un professionnel</strong> reste la
          solution la plus adaptée pour les formes chroniques.
        </li>
      </ul>

      <h2>Agir dès aujourd'hui</h2>
      <p>
        Pas besoin d'attendre que ça aille mieux tout seul. De petits gestes
        quotidiens, pratiqués régulièrement, font une vraie différence.
      </p>
      <p>
        Chez Noûs, nous avons pensé chaque fonctionnalité pour vous accompagner
        dans ces moments&nbsp;: une séance de cohérence cardiaque pour calmer
        une montée de stress en 5 minutes, des méditations guidées pour relâcher
        les tensions, ou encore nos exercices de détente pour déposer le mental
        et revenir au moment présent.
      </p>
      <p>
        Prendre soin de son équilibre émotionnel, c'est un acte de bienveillance
        envers soi-même. Commencez par une minute.
      </p>

      <p className="cta">
        <Link
          to="/exercices"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Essayer la cohérence cardiaque sur Noûs
        </Link>
      </p>

      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être Agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
  "sommeil-bien-etre": (
    <>
      <p className="lead">
        On le sait tous intuitivement&nbsp;: une mauvaise nuit et tout devient
        plus difficile. L'humeur, la concentration, la patience... Le sommeil
        n'est pas un luxe. C'est le pilier silencieux de notre équilibre.
      </p>

      <h2>Ce qui se passe vraiment pendant que vous dormez</h2>
      <p>
        Le sommeil est loin d'être un simple temps de pause. C'est une période
        d'activité intense pour l'organisme&nbsp;:
      </p>
      <ul>
        <li>
          <strong>Le cerveau consolide</strong> les apprentissages et trie les
          informations de la journée.
        </li>
        <li>
          <strong>Le système immunitaire se renforce</strong>&nbsp;: les
          personnes dormant moins de 6 heures par nuit sont significativement
          plus vulnérables aux infections.
        </li>
        <li>
          <strong>Les hormones se régulent</strong>, dont le cortisol (stress),
          la leptine (satiété) et la mélatonine (cycle veille/sommeil).
        </li>
        <li>
          <strong>Les cellules se réparent</strong>&nbsp;: la récupération
          physique et musculaire se fait principalement la nuit.
        </li>
      </ul>
      <p>En résumé&nbsp;: dormir, c'est se soigner.</p>

      <h2>Pourquoi nous dormons si mal&nbsp;?</h2>
      <p>
        Les troubles du sommeil touchent près d'un Français sur trois. Les
        causes sont multiples, mais le stress est le premier coupable. Quand le
        système nerveux reste en état d'alerte le soir, l'endormissement
        devient difficile et le sommeil reste superficiel.
      </p>
      <p>
        Les écrans, les horaires irréguliers, la sédentarité et une
        alimentation déséquilibrée viennent aggraver le tableau. Le
        résultat&nbsp;: une dette de sommeil qui s'accumule et finit par
        affecter tous les aspects de la vie.
      </p>

      <h2>Les clés d'un sommeil réparateur</h2>
      <p>
        Quelques habitudes simples peuvent transformer la qualité de vos
        nuits&nbsp;:
      </p>
      <ul>
        <li>
          <strong>Respecter des horaires réguliers</strong>&nbsp;: se coucher
          et se lever à la même heure, même le week-end.
        </li>
        <li>
          <strong>Créer un rituel du soir</strong> pour signaler au cerveau que
          la journée se termine (lecture, bain chaud, étirements doux).
        </li>
        <li>
          <strong>Limiter les écrans après 21h</strong>&nbsp;: la lumière bleue
          bloque la production de mélatonine.
        </li>
        <li>
          <strong>Pratiquer la relaxation</strong>&nbsp;: cohérence cardiaque,
          méditation guidée ou exercices de respiration pour apaiser le système
          nerveux avant de dormir.
        </li>
      </ul>

      <h2>Et si vous commenciez ce soir&nbsp;?</h2>
      <p>
        Chez Noûs, nous avons conçu des outils pensés pour accompagner ce
        moment précieux de transition entre le jour et la nuit.
      </p>
      <p>
        Nos méditations guidées vous accompagnent vers un état de détente
        profonde, idéal pour préparer un endormissement serein. Nos exercices
        de détente — cohérence cardiaque, jardin zen, mandala — sont parfaits
        pour déposer les tensions de la journée en quelques minutes.
      </p>
      <p>
        Pas besoin d'une heure. Cinq minutes suffisent pour changer la qualité
        de votre nuit.
      </p>

      <p className="cta">
        <Link
          to="/exercices"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Explorer les exercices de détente
        </Link>
      </p>

      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être Agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
  "sophrologie-methode-douce": (
    <>
      <p className="lead">
        Stress chronique, troubles du sommeil, manque de confiance en soi...
        Face aux tensions du quotidien, de plus en plus de personnes se tournent
        vers la sophrologie. Et pour cause&nbsp;: cette discipline alliant corps
        et esprit offre des résultats concrets, validés par des décennies de
        pratique.
      </p>

      <h2>Qu'est-ce que la sophrologie&nbsp;?</h2>
      <p>
        Créée dans les années 1960 par le neuropsychiatre Alfonso Caycedo, la
        sophrologie est une méthode psychocorporelle qui combine des techniques
        de relaxation, de respiration, de visualisation positive et de
        mouvements doux.
      </p>
      <p>
        Son objectif&nbsp;: atteindre un état de conscience apaisé, ni endormi,
        ni en plein éveil, dans lequel le corps se détend et l'esprit retrouve
        clarté et sérénité. Cet état, appelé «&nbsp;niveau sophro-liminal&nbsp;»,
        est particulièrement propice au travail sur soi.
      </p>

      <h2>À quoi ça sert concrètement&nbsp;?</h2>
      <p>La sophrologie est utilisée dans de nombreux contextes&nbsp;:</p>
      <ul>
        <li>
          <strong>Gestion du stress et de l'anxiété</strong>&nbsp;: apprendre à
          désamorcer les tensions avant qu'elles ne s'installent.
        </li>
        <li>
          <strong>Amélioration du sommeil</strong>&nbsp;: retrouver un
          endormissement naturel grâce à des exercices de relaxation profonde.
        </li>
        <li>
          <strong>Préparation mentale</strong>&nbsp;: examens, accouchement,
          compétition sportive, entretien professionnel.
        </li>
        <li>
          <strong>Confiance en soi</strong>&nbsp;: travailler sur les croyances
          limitantes par la visualisation positive.
        </li>
        <li>
          <strong>Accompagnement de la maladie</strong>&nbsp;: réduire l'impact
          émotionnel des traitements médicaux.
        </li>
      </ul>

      <h2>Comment se déroule une séance&nbsp;?</h2>
      <p>
        Une séance de sophrologie dure généralement entre 45 minutes et 1 heure.
        Le sophrologue guide verbalement le patient à travers des exercices de
        respiration, des relaxations dynamiques (mouvements lents et conscients)
        et des visualisations.
      </p>
      <p>
        Pas besoin de croire en quoi que ce soit ni d'avoir une quelconque
        souplesse physique. La sophrologie s'adapte à chaque personne, à tout
        âge et dans tout état de santé.
      </p>
      <p>
        Les effets se font souvent sentir dès la première séance&nbsp;: une
        sensation de légèreté, de tête plus claire, et s'approfondissent au fil
        des séances.
      </p>

      <h2>Une pratique reconnue et accessible</h2>
      <p>
        En France, la sophrologie est de plus en plus intégrée dans les milieux
        hospitaliers, scolaires et sportifs. Elle peut également être prise en
        charge dans le cadre des Services à la Personne, ce qui la rend
        accessible à un plus grand nombre.
      </p>
      <p>
        Découvrez nos praticiens et réservez une première séance en quelques
        clics.
      </p>

      <p className="cta">
        <Link
          to="/#praticiens"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Trouver un praticien sur Noûs
        </Link>
      </p>

      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être Agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
  "coherence-cardiaque": (
    <>
      <p className="lead">
        Vous avez déjà remarqué comme une simple respiration profonde peut suffire
        à calmer une montée de stress&nbsp;? Ce n'est pas le fruit du hasard.
        C'est la cohérence cardiaque — et la science l'explique très bien.
      </p>

      <h2>Qu'est-ce que la cohérence cardiaque&nbsp;?</h2>
      <p>
        Le cœur et le cerveau communiquent en permanence via le système nerveux
        autonome. Quand nous sommes stressés, ce dialogue se dérègle&nbsp;: le
        rythme cardiaque devient irrégulier, le cortisol (l'hormone du stress)
        augmente, et notre capacité à penser clairement diminue.
      </p>
      <p>
        La cohérence cardiaque, c'est l'art de rétablir ce dialogue. En régulant
        consciemment notre respiration, on synchronise le rythme cardiaque avec
        le souffle — créant un état de cohérence physiologique qui apaise le
        système nerveux en quelques minutes seulement.
      </p>

      <h2>Comment ça fonctionne concrètement&nbsp;?</h2>
      <p>La méthode la plus utilisée est le <strong>3/6/5</strong>&nbsp;:</p>
      <ul>
        <li>3 fois par jour</li>
        <li>6 respirations par minute (5 secondes inspiration, 5 secondes expiration)</li>
        <li>5 minutes par session</li>
      </ul>
      <p>
        En pratiquant régulièrement, les effets s'accumulent&nbsp;: réduction du
        cortisol, amélioration de la concentration, meilleure qualité de
        sommeil, et une sensation durable de calme intérieur.
      </p>
      <p>
        Des études en neurosciences ont démontré qu'après seulement 3 semaines
        de pratique quotidienne, les bénéfices se maintiennent même en dehors
        des séances.
      </p>

      <h2>Pourquoi l'intégrer dans votre quotidien&nbsp;?</h2>
      <p>
        La cohérence cardiaque ne demande ni équipement, ni lieu particulier.
        Elle peut se pratiquer le matin au réveil, avant une réunion stressante,
        ou le soir pour faciliter l'endormissement.
      </p>
      <p>
        C'est une des rares techniques de bien-être validées scientifiquement,
        accessible à tous, dès la première séance.
      </p>

      <h2>Essayez maintenant avec Noûs</h2>
      <p>
        Sur l'application Noûs, nous avons conçu un exercice de cohérence
        cardiaque guidé visuellement avec notre nuage animé qui respire à votre
        rythme, pour vous accompagner pas à pas vers cet état de calme retrouvé.
      </p>
      <p>
        Pas besoin de connaissances préalables. Juste votre souffle, et quelques
        minutes pour vous.
      </p>

      <p className="cta">
        <Link
          to="/exercices"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Essayer l'exercice de cohérence cardiaque sur Noûs
        </Link>
      </p>

      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
  "bien-etre-global-approches-complementaires": (
    <>
      <p className="lead">
        Le stress, les troubles du sommeil, la fatigue mentale ne se logent
        jamais dans une seule case. Le corps, la respiration, les pensées et le
        sommeil sont profondément liés, et agir sur un seul de ces leviers donne
        souvent des résultats limités. C'est ce qu'on appelle parfois une approche
        holistique : considérer la personne dans sa globalité plutôt que de
        traiter un symptôme isolé. Chez Noûs, on préfère parler simplement de
        bien-être global, et surtout de complémentarité entre les pratiques.
      </p>

      <h2>Pourquoi combiner plusieurs approches</h2>
      <p>
        Prenons un exemple concret : une personne confrontée à un stress chronique
        au travail. Travailler uniquement sur la respiration peut soulager sur le
        moment, mais si le sommeil reste perturbé et que les pensées anxieuses
        persistent la nuit, l'effet ne dure pas. À l'inverse, combiner un exercice
        de régulation du système nerveux (comme la cohérence cardiaque) avec un
        travail plus profond sur les mécanismes de la pensée (comme la sophrologie
        ou d'autres accompagnements) permet d'agir à la fois sur le symptôme
        immédiat et sur la cause plus durable.
      </p>
      <p>
        Ce n'est pas une question de faire « plus », mais de faire les choses dans
        le bon ordre et avec la bonne combinaison, adaptée à chaque situation.
      </p>

      <h2>Trois approches qui se complètent</h2>
      <p>
        <strong>La régulation du système nerveux.</strong> Des exercices courts et
        réguliers, comme la cohérence cardiaque, permettent de calmer rapidement
        les réactions de stress du corps. C'est souvent le point de départ : apaiser
        le système nerveux avant de pouvoir travailler plus en profondeur sur autre
        chose.
      </p>
      <p>
        <strong>Le travail sur les pensées et les représentations.</strong> Une
        fois le corps apaisé, des techniques comme la sophrologie ou d'autres
        accompagnements thérapeutiques aident à modifier durablement la façon dont
        on perçoit une situation stressante, à mieux dormir, et à préparer
        mentalement des moments difficiles (une prise de parole, un examen, une
        période de changement).
      </p>
      <p>
        <strong>L'accompagnement du sommeil.</strong> Le sommeil est à la fois une
        conséquence du stress et un amplificateur s'il est perturbé. Des rituels
        adaptés et une bonne hygiène de sommeil viennent consolider les effets des
        deux approches précédentes.
      </p>
      <p>
        Ces trois dimensions ne s'excluent pas, elles se renforcent. C'est en les
        combinant, dans un ordre pensé pour chaque personne, qu'on obtient des
        résultats qui tiennent dans la durée.
      </p>

      <h2>Comment construire son propre parcours</h2>
      <p>
        Il n'existe pas de combinaison universelle : ce qui fonctionne pour une
        personne stressée par son travail ne sera pas forcément adapté à quelqu'un
        qui traverse une période de deuil ou de grand changement de vie. Chaque
        situation mérite d'être comprise avant d'être orientée vers la ou les
        approches les plus pertinentes.
      </p>
      <p>
        C'est pour cela que chez Noûs, nous préférons prendre le temps d'échanger
        avec vous plutôt que de vous laisser choisir seul dans une liste.
        Contactez-nous pour nous parler de votre situation : nous vous aiderons à
        identifier l'approche, ou la combinaison d'approches, la plus adaptée à
        votre besoin.
      </p>

      <h2>En résumé</h2>
      <p>
        Le bien-être ne se résume pas à une seule pratique isolée. C'est la
        complémentarité entre régulation du corps, travail sur les pensées et
        qualité du sommeil qui fait la différence sur la durée. Chez Noûs, nous
        vous accompagnons pour construire le parcours qui vous correspond, pas un
        parcours standard, mais le vôtre.
      </p>

      <p className="cta">
        <Link
          to="/?open=plan-perso"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Construire mon plan bien-être personnalisé
        </Link>
      </p>

      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être Agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
};

const BlogArticle = () => {
  const { slug } = useParams<{ slug: string }>();
  const article = articles.find((a) => a.slug === slug);
  const content = slug ? articleContents[slug] : null;

  if (!article || !content) {
    return <Navigate to="/blog" replace />;
  }

  return (
    <div className="min-h-screen bg-[#F5F0E6] py-12 px-4">
      <Helmet>
        <title>{`${article.title} | Blog Noûs`}</title>
        <meta name="description" content={article.excerpt} />
        <link rel="canonical" href={`https://app-nous.fr/blog/${article.slug}`} />
        <meta property="og:title" content={article.title} />
        <meta property="og:description" content={article.excerpt} />
        <meta property="og:url" content={`https://app-nous.fr/blog/${article.slug}`} />
        <meta property="og:type" content="article" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Article",
            headline: article.title,
            description: article.excerpt,
            datePublished: article.date,
            author: { "@type": "Organization", name: article.author },
            publisher: {
              "@type": "Organization",
              name: "Noûs",
              logo: { "@type": "ImageObject", url: "https://app-nous.fr/icon-512.png" },
            },
            mainEntityOfPage: `https://app-nous.fr/blog/${article.slug}`,
          })}
        </script>
      </Helmet>
      <article className="container max-w-3xl mx-auto">
        <Link
          to="/blog"
          className="inline-flex items-center gap-2 text-sage-700 hover:text-sage-900 text-sm mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Retour au blog
        </Link>

        <header className="mb-10">
          <p className="text-sm text-sage-700 mb-3">
            {article.date} · {article.author}
          </p>
          <h1 className="text-3xl md:text-4xl font-alice text-[#8B4513] leading-tight">
            {article.title}
          </h1>
        </header>

        <div className="blog-content text-warm-800 leading-relaxed space-y-5">
          {content}
        </div>
      </article>
    </div>
  );
};

export default BlogArticle;