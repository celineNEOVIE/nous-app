import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Card } from "@/components/ui/card";

type Article = {
  slug: string;
  title: string;
  excerpt: string;
  date: string;
  author: string;
};

export const articles: Article[] = [
  {
    slug: "stress-anxiete-difference",
    title: "Stress et anxiété : comprendre la différence pour mieux agir",
    excerpt:
      "Stress et anxiété sont souvent confondus. Comprendre leurs différences, c'est la première étape pour mieux les apaiser.",
    date: "27 juin 2026",
    author: "L'équipe Noûs",
  },
  {
    slug: "sommeil-bien-etre",
    title: "Sommeil et bien-être : pourquoi bien dormir change tout",
    excerpt:
      "Le sommeil est le pilier silencieux de notre équilibre. Découvrez ce qui se passe la nuit et comment retrouver des nuits réparatrices.",
    date: "27 juin 2026",
    author: "L'équipe Noûs",
  },
  {
    slug: "sophrologie-methode-douce",
    title: "La sophrologie : une méthode douce pour retrouver l'équilibre",
    excerpt:
      "Stress, sommeil, confiance en soi... Découvrez comment la sophrologie agit en douceur sur le corps et l'esprit.",
    date: "27 juin 2026",
    author: "L'équipe Noûs",
  },
  {
    slug: "coherence-cardiaque",
    title: "La cohérence cardiaque : respirez, votre cœur vous remerciera",
    excerpt:
      "Découvrez comment quelques minutes de respiration consciente par jour peuvent transformer votre équilibre intérieur.",
    date: "27 juin 2026",
    author: "L'équipe Noûs",
  },
  {
    slug: "bien-etre-global-approches-complementaires",
    title: "Bien-être global : quand plusieurs approches se complètent",
    excerpt:
      "Stress, sommeil, fatigue mentale : découvrez pourquoi une approche combinée donne des résultats plus durables.",
    date: "3 juillet 2026",
    author: "L'équipe Noûs",
  },
];

const Blog = () => {
  return (
    <div className="min-h-screen bg-[#F5F0E6] py-12 px-4">
      <Helmet>
        <title>Blog Noûs — stress, sommeil et bien-être holistique</title>
        <meta name="description" content="Articles et conseils Noûs sur le stress, le sommeil, la sophrologie et la cohérence cardiaque pour cultiver un bien-être durable au quotidien." />
        <link rel="canonical" href="https://app-nous.fr/blog" />
        <meta property="og:title" content="Blog Noûs — stress, sommeil et bien-être" />
        <meta property="og:description" content="Conseils et inspirations pour cultiver votre bien-être : stress, sommeil, sophrologie, cohérence cardiaque." />
        <meta property="og:url" content="https://app-nous.fr/blog" />
        <meta property="og:type" content="website" />
      </Helmet>
      <div className="container max-w-4xl mx-auto">
        <header className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-alice text-[#8B4513] mb-4">
            Blog Noûs
          </h1>
          <p className="text-[#A0522D] text-lg">
            Articles, conseils et inspirations pour cultiver votre bien-être.
          </p>
        </header>

        <div className="grid gap-6 md:grid-cols-2">
          {articles.map((article) => (
            <Link key={article.slug} to={`/blog/${article.slug}`} className="group">
              <Card className="h-full p-6 bg-white/60 border-sage-200 hover:border-sage-400 hover:shadow-md transition-all">
                <p className="text-xs text-sage-700 mb-2">{article.date}</p>
                <h2 className="text-xl font-alice text-[#8B4513] mb-3 group-hover:text-[#A0522D] transition-colors">
                  {article.title}
                </h2>
                <p className="text-warm-700 text-sm leading-relaxed mb-4">
                  {article.excerpt}
                </p>
                <span className="text-sage-700 text-sm font-medium">
                  Lire l'article →
                </span>
              </Card>
            </Link>
          ))}
        </div>

        <p className="text-center text-warm-500 text-sm mt-12 italic">
          D'autres articles arrivent bientôt…
        </p>
      </div>
    </div>
  );
};

export default Blog;