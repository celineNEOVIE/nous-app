import { EmbeddedCheckoutProvider, EmbeddedCheckout } from "@stripe/react-stripe-js";
import { getStripe, getStripeEnvironment } from "@/lib/stripe";
import { supabase } from "@/integrations/supabase/client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface Props {
  priceId: string;
  customerEmail?: string;
  returnUrl?: string;
}

export function StripeEmbeddedCheckout({ priceId, customerEmail, returnUrl }: Props) {
  const [email, setEmail] = useState(customerEmail ?? "");
  const [confirmedEmail, setConfirmedEmail] = useState<string | null>(
    customerEmail ? customerEmail : null,
  );
  const [error, setError] = useState<string | null>(null);

  const fetchClientSecret = async (): Promise<string> => {
    const { data, error } = await supabase.functions.invoke("create-checkout", {
      body: {
        priceId,
        customerEmail: confirmedEmail ?? undefined,
        returnUrl: returnUrl ?? `${window.location.origin}/paiement-confirmation?session_id={CHECKOUT_SESSION_ID}`,
        environment: getStripeEnvironment(),
      },
    });
    if (error || !data?.clientSecret) {
      throw new Error(error?.message || "Échec de la création de la session de paiement");
    }
    return data.clientSecret;
  };

  if (!confirmedEmail) {
    return (
      <form
        onSubmit={(e) => {
          e.preventDefault();
          const trimmed = email.trim();
          if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
            setError("Veuillez saisir une adresse email valide.");
            return;
          }
          setError(null);
          setConfirmedEmail(trimmed);
        }}
        className="space-y-4"
      >
        <div className="space-y-2">
          <Label htmlFor="checkout-email">Adresse email</Label>
          <Input
            id="checkout-email"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="vous@exemple.fr"
            autoComplete="email"
          />
          <p className="text-xs text-muted-foreground">
            Votre reçu et la confirmation de paiement seront envoyés à cette adresse.
          </p>
          {error && <p className="text-xs text-destructive">{error}</p>}
        </div>
        <Button type="submit" className="w-full">
          Continuer vers le paiement
        </Button>
      </form>
    );
  }

  return (
    <div id="checkout">
      <EmbeddedCheckoutProvider stripe={getStripe()} options={{ fetchClientSecret }}>
        <EmbeddedCheckout />
      </EmbeddedCheckoutProvider>
    </div>
  );
}