import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";
import { PhoneCall, PhoneCallIcon, Video, Euro, CreditCard, Eye } from "lucide-react";
import { StripeEmbeddedCheckout } from "@/components/stripe-embedded-checkout";
import { supabase } from "@/integrations/supabase/client";

interface PricingItem {
  title: string;
  subtitle: string;
  price: string;
  priceId?: string;
}

interface PractitionerCardProps {
  name: string;
  image: string;
  specialties: string[];
  experience: string;
  availableFor: Array<"video" | "phone">;
  tags?: string[];
  bio?: React.ReactNode;
  bioTitle?: string;
  pricing?: PricingItem[];
  imagePosition?: string;
}

const MOMENTS = [
  { id: "morning", label: "Matin" },
  { id: "afternoon", label: "Après-midi" },
  { id: "evening", label: "Soir" },
] as const;

const DAYS = [
  { id: "mon", label: "Lundi" },
  { id: "tue", label: "Mardi" },
  { id: "wed", label: "Mercredi" },
  { id: "thu", label: "Jeudi" },
  { id: "fri", label: "Vendredi" },
  { id: "sat", label: "Samedi" },
  { id: "sun", label: "Dimanche" },
] as const;

export const PractitionerCard = ({
  name,
  image,
  specialties,
  experience,
  availableFor,
  tags = [],
  bio,
  bioTitle,
  pricing,
  imagePosition = "object-top",
}: PractitionerCardProps) => {
  const [open, setOpen] = useState(false);
  const [bioOpen, setBioOpen] = useState(false);
  const [pricingOpen, setPricingOpen] = useState(false);
  const [checkoutPriceId, setCheckoutPriceId] = useState<string | null>(null);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [moments, setMoments] = useState<string[]>([]);
  const [days, setDays] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const toggle = (
    value: string,
    list: string[],
    setList: (v: string[]) => void,
  ) => {
    setList(list.includes(value) ? list.filter((v) => v !== value) : [...list, value]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const { error } = await supabase.functions.invoke("request-callback", {
        body: {
          praticienName: name,
          firstName,
          lastName,
          phone,
          email,
          moments,
          days,
        },
      });
      if (error) throw error;
      toast({
        title: "Demande envoyée",
        description: `Merci ${firstName}, nous vous recontacterons rapidement.`,
      });
      setOpen(false);
      setFirstName("");
      setLastName("");
      setPhone("");
      setEmail("");
      setMoments([]);
      setDays([]);
    } catch (err) {
      console.error(err);
      toast({
        title: "Erreur",
        description: "Impossible d'envoyer la demande. Réessayez plus tard.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="border-b border-[#E3E9E3] p-0">
        <button
          type="button"
          onClick={() => bio && setBioOpen(true)}
          className={`relative w-full aspect-[4/3] overflow-hidden block group ${bio ? "cursor-pointer" : "cursor-default"}`}
          aria-label={bio ? `Voir la fiche de ${name}` : name}
        >
          <img
            alt={name}
            className={`absolute inset-0 object-cover w-full h-full ${imagePosition} transition-transform duration-500 group-hover:scale-105`}
            src={image}
          />
          {bio && (
            <>
              <div className="absolute bottom-2 right-2 bg-[#5C4033]/80 text-[#F5F0E6] text-xs font-medium px-2.5 py-1 rounded-full flex items-center gap-1.5 backdrop-blur-sm pointer-events-none z-10 transition-opacity duration-300 group-hover:opacity-0">
                <Eye className="w-3.5 h-3.5" />
                Voir le profil
              </div>
              <div className="absolute inset-0 bg-[#5C4033]/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center pointer-events-none">
                <span className="text-[#F5F0E6] font-medium flex items-center gap-2 drop-shadow-md">
                  <Eye className="w-5 h-5" />
                  Voir le profil
                </span>
              </div>
            </>
          )}
        </button>
      </CardHeader>
      <CardContent className="p-6">
        <h3
          className={`mb-2 text-xl font-semibold text-[#8B4513] ${bio ? "cursor-pointer hover:underline" : ""}`}
          onClick={() => bio && setBioOpen(true)}
        >
          {name}
        </h3>
        {experience && <p className="mb-4 text-sm text-[#A0522D]">{experience}</p>}
        <div className="flex flex-wrap gap-2 mb-4">
          {specialties.map((specialty) => (
            <Badge
              key={specialty}
              variant="outline"
              className="bg-sage-200 text-sage-700 border-sage-300 hover:bg-sage-300"
            >
              {specialty}
            </Badge>
          ))}
        </div>
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {tags.map((tag) => (
              <Badge
                key={tag}
                variant="outline"
                className="bg-sage-200 text-sage-700 border-sage-300 hover:bg-sage-300"
              >
                {tag}
              </Badge>
            ))}
          </div>
        )}
        <div className="flex gap-2">
          {availableFor.includes("video") && (
            <Badge variant="outline" className="bg-sage-50 text-sage-700 border-sage-200">
              <Video className="w-3 h-3 mr-1" />
              Visio
            </Badge>
          )}
          {availableFor.includes("phone") && (
            <Badge variant="outline" className="bg-sage-50 text-sage-700 border-sage-200">
              <PhoneCall className="w-3 h-3 mr-1" />
              Téléphone
            </Badge>
          )}
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="w-full mt-4 bg-sage-600 hover:bg-sage-700 text-white">
              <PhoneCallIcon className="w-4 h-4 mr-2" />
              Être rappelé(e)
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Être rappelé(e) par {name}</DialogTitle>
              <DialogDescription>
                Indiquez vos coordonnées et vos préférences de créneaux.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor={`firstName-${name}`}>Prénom</Label>
                  <Input
                    id={`firstName-${name}`}
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    maxLength={60}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor={`lastName-${name}`}>Nom</Label>
                  <Input
                    id={`lastName-${name}`}
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    maxLength={60}
                    required
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor={`phone-${name}`}>Numéro de téléphone</Label>
                <Input
                  id={`phone-${name}`}
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  pattern="[0-9 +().-]{6,20}"
                  maxLength={20}
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor={`email-${name}`}>Adresse email</Label>
                <Input
                  id={`email-${name}`}
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  maxLength={255}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Moments préférés</Label>
                <div className="flex flex-wrap gap-3">
                  {MOMENTS.map((m) => (
                    <label key={m.id} className="flex items-center gap-2 text-sm">
                      <Checkbox
                        checked={moments.includes(m.id)}
                        onCheckedChange={() => toggle(m.id, moments, setMoments)}
                      />
                      {m.label}
                    </label>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Jours préférés</Label>
                <div className="flex flex-wrap gap-3">
                  {DAYS.map((d) => (
                    <label key={d.id} className="flex items-center gap-2 text-sm">
                      <Checkbox
                        checked={days.includes(d.id)}
                        onCheckedChange={() => toggle(d.id, days, setDays)}
                      />
                      {d.label}
                    </label>
                  ))}
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                Nous vous recontacterons dans les meilleurs délais pour convenir
                d'un rendez-vous avec ce praticien.
              </p>
              <DialogFooter>
                <Button type="submit" disabled={submitting} className="bg-sage-600 hover:bg-sage-700 text-white">
                  {submitting ? "Envoi…" : "Envoyer ma demande"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        <Button
          type="button"
          variant="outline"
          onClick={() => setPricingOpen(true)}
          className="w-full mt-2 border-sage-300 text-sage-700 hover:bg-sage-50"
        >
          <Euro className="w-4 h-4 mr-2" />
          Tarifs
        </Button>
        <Dialog open={pricingOpen} onOpenChange={setPricingOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Tarifs — {name}</DialogTitle>
              <DialogDescription>
                Séances d'accompagnements en visio ou par téléphone.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              {pricing ? (
                pricing.map((item) => (
                  <button
                    key={item.title}
                    type="button"
                    onClick={() => {
                      if (item.priceId) {
                        setCheckoutPriceId(item.priceId);
                        setPricingOpen(false);
                      } else {
                        toast({
                          title: "Paiement bientôt disponible",
                          description: "Le paiement Stripe sera activé prochainement.",
                        });
                      }
                    }}
                    className="w-full flex items-center justify-between rounded-lg border border-sage-200 bg-sage-50/50 p-4 text-left hover:bg-sage-50 transition-colors"
                  >
                    <div className="min-w-0 pr-3">
                      <p className="font-medium text-[#5C4033]">{item.title}</p>
                      <p className="text-xs text-[#A0522D]">{item.subtitle}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-lg font-semibold text-sage-700 whitespace-nowrap">{item.price}</span>
                      <CreditCard className="w-4 h-4 text-sage-600 shrink-0" />
                    </div>
                  </button>
                ))
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      toast({
                        title: "Paiement bientôt disponible",
                        description: "Le paiement Stripe sera activé prochainement.",
                      });
                    }}
                    className="w-full flex items-center justify-between rounded-lg border border-sage-200 bg-sage-50/50 p-4 text-left hover:bg-sage-50 transition-colors"
                  >
                    <div className="min-w-0 pr-3">
                      <p className="font-medium text-[#5C4033]">Séance 30 minutes</p>
                      <p className="text-xs text-[#A0522D]">Idéale pour une pause ressourçante</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-lg font-semibold text-sage-700 whitespace-nowrap">45 €</span>
                      <CreditCard className="w-4 h-4 text-sage-600 shrink-0" />
                    </div>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      toast({
                        title: "Paiement bientôt disponible",
                        description: "Le paiement Stripe sera activé prochainement.",
                      });
                    }}
                    className="w-full flex items-center justify-between rounded-lg border border-sage-200 bg-sage-50/50 p-4 text-left hover:bg-sage-50 transition-colors"
                  >
                    <div className="min-w-0 pr-3">
                      <p className="font-medium text-[#5C4033]">Séance 60 minutes</p>
                      <p className="text-xs text-[#A0522D]">Accompagnement complet</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-lg font-semibold text-sage-700 whitespace-nowrap">75 €</span>
                      <CreditCard className="w-4 h-4 text-sage-600 shrink-0" />
                    </div>
                  </button>
                </>
              )}
              <p className="text-xs text-muted-foreground pt-2">
                Paiement sécurisé par Stripe. 50% de crédit d'impôt selon l'article 199 sexdecies du CGI. Vérifiez votre éligibilité.
              </p>
            </div>
          </DialogContent>
        </Dialog>
        {bio && (
          <Dialog open={bioOpen} onOpenChange={setBioOpen}>
            <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{bioTitle ?? name}</DialogTitle>
              </DialogHeader>
              <div className="text-sm text-[#5C4033] space-y-3 leading-relaxed">
                {bio}
              </div>
            </DialogContent>
          </Dialog>
        )}
        <Dialog open={!!checkoutPriceId} onOpenChange={(o) => !o && setCheckoutPriceId(null)}>
          <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Paiement sécurisé</DialogTitle>
              <DialogDescription>
                Paiement traité par Stripe. Aucune donnée bancaire ne transite par notre site.
              </DialogDescription>
            </DialogHeader>
            {checkoutPriceId && <StripeEmbeddedCheckout priceId={checkoutPriceId} />}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};
