import { useState, ImgHTMLAttributes } from "react";

const PLACEHOLDER =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 300'><rect width='400' height='300' fill='%23E8DFCE'/><text x='50%' y='50%' font-family='sans-serif' font-size='18' fill='%238B4513' text-anchor='middle' dominant-baseline='middle'>Image indisponible</text></svg>`,
  );

interface Props extends ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  fallbackSrc?: string;
}

/**
 * Robust <img> for iPad / Safari review: forces absolute HTTPS URL when possible
 * and swaps in a graceful placeholder if the network load fails.
 */
export const ImageWithFallback = ({
  src,
  alt,
  fallbackSrc = PLACEHOLDER,
  loading = "lazy",
  decoding = "async",
  ...rest
}: Props) => {
  const toAbsolute = (u: string) => {
    if (!u) return u;
    if (/^https?:\/\//i.test(u) || u.startsWith("data:")) return u;
    if (typeof window !== "undefined" && u.startsWith("/")) {
      return `${window.location.origin}${u}`;
    }
    return u;
  };

  const [current, setCurrent] = useState<string>(toAbsolute(src));
  const [failed, setFailed] = useState(false);

  return (
    <img
      {...rest}
      src={current}
      alt={alt}
      loading={loading}
      decoding={decoding}
      onError={() => {
        if (!failed) {
          setFailed(true);
          setCurrent(fallbackSrc);
        }
      }}
    />
  );
};

export default ImageWithFallback;