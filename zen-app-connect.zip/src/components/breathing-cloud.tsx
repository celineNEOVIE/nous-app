import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import inspirezAudio from "@/assets/neovie-inspirez.mp3.asset.json";
import expirezAudio from "@/assets/neovie-expirez.mp3.asset.json";

interface BreathingCloudProps {
  onFinish: () => void;
  durationSec?: number;
}

const IN_DURATION = 4;
const OUT_DURATION = 6;
const CYCLE = IN_DURATION + OUT_DURATION;
const NOUS_LOGO = "/lovable-uploads/1919c5e1-b704-4470-9256-3863b6b72f49.png";

export const BreathingCloud = ({ onFinish, durationSec = 120 }: BreathingCloudProps) => {
  const [remaining, setRemaining] = useState(durationSec);
  const [phase, setPhase] = useState<"in" | "out">("in");
  const [done, setDone] = useState(false);
  const [showIntro, setShowIntro] = useState(true);
  const [cyclePos, setCyclePos] = useState(0);
  const startRef = useRef<number>(Date.now());
  const inAudioRef = useRef<HTMLAudioElement | null>(null);
  const outAudioRef = useRef<HTMLAudioElement | null>(null);
  const lastPhaseRef = useRef<"in" | "out" | null>(null);

  useEffect(() => {
    inAudioRef.current = new Audio(inspirezAudio.url);
    outAudioRef.current = new Audio(expirezAudio.url);
    inAudioRef.current.preload = "auto";
    outAudioRef.current.preload = "auto";
    return () => {
      inAudioRef.current?.pause();
      outAudioRef.current?.pause();
    };
  }, []);

  useEffect(() => {
    if (showIntro || done) return;
    if (lastPhaseRef.current === phase) return;
    lastPhaseRef.current = phase;
    const a = phase === "in" ? inAudioRef.current : outAudioRef.current;
    const other = phase === "in" ? outAudioRef.current : inAudioRef.current;
    if (other) { other.pause(); other.currentTime = 0; }
    if (a) { a.currentTime = 0; a.play().catch(() => {}); }
  }, [phase, showIntro, done]);

  useEffect(() => {
    startRef.current = Date.now();
    const id = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startRef.current) / 1000);
      const left = durationSec - elapsed;
      if (left <= 0) {
        setRemaining(0);
        setDone(true);
        clearInterval(id);
        return;
      }
      setRemaining(left);
      const pos = elapsed % CYCLE;
      setCyclePos(pos);
      setPhase(pos < IN_DURATION ? "in" : "out");
    }, 100);
    return () => clearInterval(id);
  }, [durationSec]);

  useEffect(() => {
    const t = setTimeout(() => setShowIntro(false), 3000);
    return () => clearTimeout(t);
  }, []);

  const mm = String(Math.floor(remaining / 60)).padStart(1, "0");
  const ss = String(remaining % 60).padStart(2, "0");

  const inCount = phase === "in" ? Math.min(Math.floor(cyclePos) + 1, IN_DURATION) : 0;
  const outCount = phase === "out" ? Math.min(Math.floor(cyclePos - IN_DURATION) + 1, OUT_DURATION) : 0;

  if (done) {
    return (
      <div className="relative w-full min-h-[60vh] flex flex-col items-center justify-center gap-6 rounded-2xl overflow-hidden bg-gradient-to-b from-[#F5F0E6] via-[#E8EDE0] to-[#C9DCD0] p-8 text-center">
        <WaterBackground />
        <div className="relative z-10 max-w-md space-y-6 animate-fade-in">
          <p className="font-['Alice'] text-2xl text-[#8B4513] leading-relaxed">
            Votre cœur est apaisé.<br />Prenez un moment pour ressentir ce calme.
          </p>
          <Button
            onClick={onFinish}
            className="bg-sage-300 text-sage-800 hover:bg-sage-400 border border-sage-400 px-6"
          >
            Retour à l'accueil
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full min-h-[60vh] flex flex-col items-center justify-between gap-4 rounded-2xl overflow-hidden bg-gradient-to-b from-[#EAF3EE] via-[#D6E6DD] to-[#B8D2C8] p-6">
      <WaterBackground />

      {showIntro && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-[#EAF3EE]/90 animate-fade-in">
          <p className="font-['Alice'] text-2xl md:text-3xl text-[#8B4513] text-center leading-relaxed px-6">
            Respirez avec Noûs…<br />laissez votre cœur trouver son rythme
          </p>
        </div>
      )}

      <div className="relative z-10 self-end text-sm font-medium text-[#5C3A1E]/80 tabular-nums bg-white/40 backdrop-blur px-3 py-1 rounded-full">
        {mm}:{ss}
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center flex-1 gap-6 py-6">
        <div
          className="relative flex items-center justify-center transition-transform ease-[cubic-bezier(0.45,0,0.55,1)]"
          style={{
            transitionDuration: phase === "in" ? `${IN_DURATION * 1000}ms` : `${OUT_DURATION * 1000}ms`,
            transform: phase === "in" ? "scale(1.35)" : "scale(0.75)",
          }}
        >
          <img
            src={NOUS_LOGO}
            alt="Noûs"
            className="h-40 w-auto drop-shadow-[0_10px_30px_rgba(120,150,130,0.35)] select-none pointer-events-none"
            draggable={false}
          />
        </div>

        <div className="flex flex-col items-center gap-2 min-h-[80px]">
          <p className="font-['Alice'] text-2xl md:text-3xl tracking-wide text-[#C68B6B]">
            {phase === "in" ? "Inspirez…" : "Expirez…"}
          </p>
          <div className="flex items-center gap-3 font-['Alice'] text-2xl md:text-3xl text-[#C68B6B]">
            {phase === "in" &&
              Array.from({ length: IN_DURATION }, (_, i) => (
                <span
                  key={`in-${i}`}
                  className={`inline-block transition-opacity duration-500 ${
                    i < inCount ? "opacity-100" : "opacity-20"
                  }`}
                >
                  ·
                </span>
              ))}
            {phase === "out" &&
              Array.from({ length: OUT_DURATION }, (_, i) => (
                <span
                  key={`out-${i}`}
                  className={`inline-block transition-opacity duration-500 ${
                    i < outCount ? "opacity-100" : "opacity-20"
                  }`}
                >
                  ·
                </span>
              ))}
          </div>
        </div>
      </div>

      <div className="relative z-10 flex justify-center">
        <Button
          variant="outline"
          onClick={onFinish}
          className="border-sage-300 bg-white/60 text-[#8B4513] hover:bg-white"
        >
          Terminer
        </Button>
      </div>
    </div>
  );
};

const WaterBackground = () => (
  <div className="pointer-events-none absolute inset-0 overflow-hidden">
    {/* Soft layered water gradients */}
    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_20%,rgba(255,255,255,0.55),transparent_60%)]" />
    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_75%_80%,rgba(168,196,154,0.35),transparent_65%)]" />
    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_100%,rgba(110,139,94,0.25),transparent_70%)]" />
    {/* Gentle drifting ripples */}
    <div
      className="absolute inset-x-0 top-1/3 h-px bg-white/30"
      style={{ animation: "rippleDrift 11s ease-in-out infinite" }}
    />
    <div
      className="absolute inset-x-0 top-2/3 h-px bg-white/20"
      style={{ animation: "rippleDrift 14s ease-in-out 2s infinite reverse" }}
    />
    <style>{`
      @keyframes rippleDrift {
        0%, 100% { transform: translateX(-4%) scaleX(0.95); opacity: 0.25; }
        50% { transform: translateX(4%) scaleX(1.05); opacity: 0.55; }
      }
    `}</style>
  </div>
);
