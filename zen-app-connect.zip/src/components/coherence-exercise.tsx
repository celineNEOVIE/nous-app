import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import inspirezAudio from "@/assets/neovie-inspirez.mp3.asset.json";
import expirezAudio from "@/assets/neovie-expirez.mp3.asset.json";

export type PhaseKind = "in" | "hold-in" | "out" | "hold-out";

export interface Phase {
  kind: PhaseKind;
  label: string;
  duration: number; // seconds
}

export type CoherencePalette = "day" | "night";

export interface CoherenceExerciseProps {
  onFinish: () => void;
  pattern: Phase[];
  durationSec: number;
  introText?: string;
  palette?: CoherencePalette;
  title?: string;
  muted?: boolean;
}

const NOUS_LOGO = "/lovable-uploads/1919c5e1-b704-4470-9256-3863b6b72f49.png";

const targetScaleFor = (kind: PhaseKind): number => {
  switch (kind) {
    case "in":
    case "hold-in":
      return 1.35;
    case "out":
    case "hold-out":
      return 0.75;
  }
};

export const CoherenceExercise = ({
  onFinish,
  pattern,
  durationSec,
  introText,
  palette = "day",
  title,
  muted = false,
}: CoherenceExerciseProps) => {
  const [remaining, setRemaining] = useState(durationSec);
  const [phaseIndex, setPhaseIndex] = useState(0);
  const [done, setDone] = useState(false);
  const [showIntro, setShowIntro] = useState(true);
  const startRef = useRef<number>(Date.now());
  const inAudioRef = useRef<HTMLAudioElement | null>(null);
  const outAudioRef = useRef<HTMLAudioElement | null>(null);
  const lastFiredRef = useRef<number>(-1);

  const cycleDuration = pattern.reduce((a, p) => a + p.duration, 0);

  useEffect(() => {
    if (muted) return;
    inAudioRef.current = new Audio(inspirezAudio.url);
    outAudioRef.current = new Audio(expirezAudio.url);
    inAudioRef.current.preload = "auto";
    outAudioRef.current.preload = "auto";
    return () => {
      inAudioRef.current?.pause();
      outAudioRef.current?.pause();
    };
  }, [muted]);

  useEffect(() => {
    if (showIntro || done) return;
    if (muted) return;
    if (lastFiredRef.current === phaseIndex) return;
    lastFiredRef.current = phaseIndex;
    const phase = pattern[phaseIndex];
    if (!phase) return;
    const a =
      phase.kind === "in" ? inAudioRef.current : phase.kind === "out" ? outAudioRef.current : null;
    const other =
      phase.kind === "in" ? outAudioRef.current : phase.kind === "out" ? inAudioRef.current : null;
    if (other) {
      other.pause();
      other.currentTime = 0;
    }
    if (a) {
      a.currentTime = 0;
      a.play().catch(() => {});
    }
  }, [phaseIndex, showIntro, done, pattern, muted]);

  useEffect(() => {
    if (showIntro) return;
    startRef.current = Date.now();
    const id = setInterval(() => {
      const elapsed = (Date.now() - startRef.current) / 1000;
      const left = Math.max(0, Math.ceil(durationSec - elapsed));
      if (elapsed >= durationSec) {
        setRemaining(0);
        setDone(true);
        clearInterval(id);
        return;
      }
      setRemaining(left);
      const pos = elapsed % cycleDuration;
      let acc = 0;
      let idx = 0;
      for (let i = 0; i < pattern.length; i++) {
        if (pos < acc + pattern[i].duration) {
          idx = i;
          break;
        }
        acc += pattern[i].duration;
      }
      setPhaseIndex(idx);
    }, 100);
    return () => clearInterval(id);
  }, [durationSec, cycleDuration, pattern, showIntro]);

  useEffect(() => {
    const t = setTimeout(() => setShowIntro(false), 3000);
    return () => clearTimeout(t);
  }, []);

  const mm = String(Math.floor(remaining / 60));
  const ss = String(remaining % 60).padStart(2, "0");

  const currentPhase = pattern[phaseIndex] ?? pattern[0];
  const scale = targetScaleFor(currentPhase.kind);

  const isNight = palette === "night";
  const bgGradient = isNight
    ? "bg-gradient-to-b from-[#1B1F3A] via-[#2A2350] to-[#3A2E5C]"
    : "bg-gradient-to-b from-[#EAF3EE] via-[#D6E6DD] to-[#B8D2C8]";
  const introBg = isNight ? "bg-[#1B1F3A]/90" : "bg-[#EAF3EE]/90";
  const introTextColor = isNight ? "text-[#E8DCFB]" : "text-[#8B4513]";
  const timerColor = isNight ? "text-[#E8DCFB]/90 bg-white/10" : "text-[#5C3A1E]/80 bg-white/40";
  const phaseTextColor = isNight ? "text-[#E8DCFB]" : "text-[#C68B6B]";
  const doneBg = isNight
    ? "bg-gradient-to-b from-[#1B1F3A] via-[#2A2350] to-[#3A2E5C]"
    : "bg-gradient-to-b from-[#F5F0E6] via-[#E8EDE0] to-[#C9DCD0]";
  const doneTextColor = isNight ? "text-[#E8DCFB]" : "text-[#8B4513]";

  if (done) {
    return (
      <div className={`relative w-full min-h-[60vh] flex flex-col items-center justify-center gap-6 rounded-2xl overflow-hidden ${doneBg} p-8 text-center`}>
        <WaterBackground night={isNight} />
        <div className="relative z-10 max-w-md space-y-6 animate-fade-in">
          <p className={`font-['Alice'] text-2xl ${doneTextColor} leading-relaxed`}>
            Votre cœur est apaisé.<br />Prenez un moment pour ressentir ce calme.
          </p>
          <Button
            onClick={onFinish}
            className="bg-sage-300 text-sage-800 hover:bg-sage-400 border border-sage-400 px-6"
          >
            Retour
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative w-full min-h-[60vh] flex flex-col items-center justify-between gap-4 rounded-2xl overflow-hidden ${bgGradient} p-6`}>
      <WaterBackground night={isNight} />

      {showIntro && (
        <div className={`absolute inset-0 z-20 flex flex-col items-center justify-center ${introBg} animate-fade-in`}>
          <p className={`font-['Alice'] text-2xl md:text-3xl ${introTextColor} text-center leading-relaxed px-6`}>
            {introText ?? "Respirez avec Noûs…"}
          </p>
          {title && (
            <p className={`mt-3 text-sm ${introTextColor} opacity-70`}>{title}</p>
          )}
        </div>
      )}

      <div className={`relative z-10 self-end text-sm font-medium tabular-nums backdrop-blur px-3 py-1 rounded-full ${timerColor}`}>
        {mm}:{ss}
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center flex-1 gap-6 py-6">
        <div
          className="relative flex items-center justify-center transition-transform ease-[cubic-bezier(0.45,0,0.55,1)]"
          style={{
            transitionDuration: `${currentPhase.duration * 1000}ms`,
            transform: `scale(${scale})`,
          }}
        >
          <img
            src={NOUS_LOGO}
            alt="Noûs"
            className={`h-40 w-auto select-none pointer-events-none ${
              isNight
                ? "drop-shadow-[0_10px_30px_rgba(180,160,230,0.45)]"
                : "drop-shadow-[0_10px_30px_rgba(120,150,130,0.35)]"
            }`}
            draggable={false}
          />
        </div>

        <div className="flex flex-col items-center gap-2 min-h-[80px]">
          <p className={`font-['Alice'] text-2xl md:text-3xl tracking-wide ${phaseTextColor}`}>
            {currentPhase.label}
          </p>
        </div>
      </div>

      <div className="relative z-10 flex justify-center">
        <Button
          variant="outline"
          onClick={onFinish}
          className={
            isNight
              ? "border-white/30 bg-white/10 text-[#E8DCFB] hover:bg-white/20"
              : "border-sage-300 bg-white/60 text-[#8B4513] hover:bg-white"
          }
        >
          ← Retour
        </Button>
      </div>
    </div>
  );
};

const WaterBackground = ({ night = false }: { night?: boolean }) => (
  <div className="pointer-events-none absolute inset-0 overflow-hidden">
    {night ? (
      <>
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_20%,rgba(180,160,230,0.30),transparent_60%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_75%_80%,rgba(90,80,150,0.45),transparent_65%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_100%,rgba(40,30,80,0.55),transparent_70%)]" />
      </>
    ) : (
      <>
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_20%,rgba(255,255,255,0.55),transparent_60%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_75%_80%,rgba(168,196,154,0.35),transparent_65%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_100%,rgba(110,139,94,0.25),transparent_70%)]" />
      </>
    )}
    <div
      className={`absolute inset-x-0 top-1/3 h-px ${night ? "bg-white/15" : "bg-white/30"}`}
      style={{ animation: "rippleDrift 11s ease-in-out infinite" }}
    />
    <div
      className={`absolute inset-x-0 top-2/3 h-px ${night ? "bg-white/10" : "bg-white/20"}`}
      style={{ animation: "rippleDrift 14s ease-in-out 2s infinite reverse" }}
    />
    <style>{`
      @keyframes rippleDrift {
        0%, 100% { transform: translateX(-4%) scaleX(0.95); opacity: 0.25; }
        50% { transform: translateX(4%) scaleX(1.05); opacity: 0.55; }
      }
    `}</style>
  </div>
);