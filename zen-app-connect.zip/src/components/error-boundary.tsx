import { Component, type ReactNode } from "react";

interface Props {
  children: ReactNode;
}
interface State {
  hasError: boolean;
  message?: string;
}

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error?.message };
  }

  componentDidCatch(error: Error, info: unknown) {
    // eslint-disable-next-line no-console
    console.error("[Noûs] Uncaught error:", error, info);
  }

  handleReload = () => {
    try {
      window.location.reload();
    } catch {
      /* noop */
    }
  };

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            minHeight: "100vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "#F5F0E6",
            color: "#8B4513",
            fontFamily: "system-ui, -apple-system, sans-serif",
            padding: "2rem",
            textAlign: "center",
          }}
        >
          <div style={{ maxWidth: 420 }}>
            <h1 style={{ fontSize: "1.4rem", marginBottom: "0.75rem" }}>
              Une erreur est survenue
            </h1>
            <p style={{ opacity: 0.8, marginBottom: "1.25rem", lineHeight: 1.5 }}>
              L'application n'a pas pu s'afficher correctement. Vous pouvez recharger la page pour
              réessayer.
            </p>
            <button
              type="button"
              onClick={this.handleReload}
              style={{
                background: "#7C8B6F",
                color: "#fff",
                border: 0,
                padding: "0.6rem 1.2rem",
                borderRadius: 999,
                fontSize: "0.95rem",
                cursor: "pointer",
              }}
            >
              Recharger
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}