import { useMemo, useState } from "react";
import { RefreshCw, Layers } from "lucide-react";

// ---------------------------------------------------------------------------
// MandalaColoriage — coloriage zen procédural pour Noûs.
// Aucune image externe : tous les segments sont des <path> SVG générés
// en trigonométrie (secteurs d'anneau). Pas de score, pas de timer.
// ---------------------------------------------------------------------------

type Level = "simple" | "detailed";

const LEVELS: Record<Level, { rings: number; segments: number; label: string }> = {
  simple: { rings: 3, segments: 8, label: "Simple" },
  detailed: { rings: 5, segments: 12, label: "Détaillé" },
};

// Palette Noûs : crème, marron clair, vert sauge, terracotta doux + pastels
const PALETTE = [
  { name: "Crème", color: "#F5E9D2" },
  { name: "Marron clair", color: "#C9A27B" },
  { name: "Vert sauge", color: "#A7B9A7" },
  { name: "Terracotta", color: "#D4886A" },
  { name: "Lavande", color: "#C9B8D9" },
  { name: "Bleu doux", color: "#B5CBD3" },
  { name: "Rose poudré", color: "#E8C9C2" },
  { name: "Beige clair", color: "#EFE3D0" },
];

const SIZE = 480; // viewBox
const CENTER = SIZE / 2;
const OUTER_RADIUS = 220;
const INNER_RADIUS = 48; // zone centrale (nuage)

const polar = (cx: number, cy: number, r: number, angleRad: number) => ({
  x: cx + r * Math.cos(angleRad),
  y: cy + r * Math.sin(angleRad),
});

// Construit un path SVG pour un secteur d'anneau (annular sector).
const annularSector = (
  cx: number,
  cy: number,
  rInner: number,
  rOuter: number,
  startAngle: number,
  endAngle: number,
) => {
  const p1 = polar(cx, cy, rOuter, startAngle);
  const p2 = polar(cx, cy, rOuter, endAngle);
  const p3 = polar(cx, cy, rInner, endAngle);
  const p4 = polar(cx, cy, rInner, startAngle);
  const largeArc = endAngle - startAngle > Math.PI ? 1 : 0;
  return [
    `M ${p1.x.toFixed(2)} ${p1.y.toFixed(2)}`,
    `A ${rOuter} ${rOuter} 0 ${largeArc} 1 ${p2.x.toFixed(2)} ${p2.y.toFixed(2)}`,
    `L ${p3.x.toFixed(2)} ${p3.y.toFixed(2)}`,
    `A ${rInner} ${rInner} 0 ${largeArc} 0 ${p4.x.toFixed(2)} ${p4.y.toFixed(2)}`,
    "Z",
  ].join(" ");
};

type Segment = { id: string; d: string; ring: number; index: number };

function buildSegments(level: Level): Segment[] {
  const { rings, segments } = LEVELS[level];
  const ringThickness = (OUTER_RADIUS - INNER_RADIUS) / rings;
  const list: Segment[] = [];
  for (let r = 0; r < rings; r++) {
    const rInner = INNER_RADIUS + r * ringThickness;
    const rOuter = rInner + ringThickness;
    // Décalage alterné des anneaux pour un motif "fleur" plus organique
    const offset = r % 2 === 0 ? 0 : Math.PI / segments;
    for (let i = 0; i < segments; i++) {
      const startAngle = offset + (i * 2 * Math.PI) / segments;
      const endAngle = offset + ((i + 1) * 2 * Math.PI) / segments;
      list.push({
        id: `r${r}-s${i}`,
        ring: r,
        index: i,
        d: annularSector(CENTER, CENTER, rInner, rOuter, startAngle, endAngle),
      });
    }
  }
  return list;
}

// Petites "pétales" entre les anneaux pour enrichir visuellement (non coloriables).
function buildPetalGuides(level: Level): string[] {
  const { rings, segments } = LEVELS[level];
  const ringThickness = (OUTER_RADIUS - INNER_RADIUS) / rings;
  const guides: string[] = [];
  for (let r = 1; r < rings; r++) {
    const rr = INNER_RADIUS + r * ringThickness;
    for (let i = 0; i < segments; i++) {
      const a = (i * 2 * Math.PI) / segments;
      const p = polar(CENTER, CENTER, rr, a);
      guides.push(`M ${CENTER} ${CENTER} L ${p.x.toFixed(2)} ${p.y.toFixed(2)}`);
    }
  }
  return guides;
}

export const MandalaColoriage = () => {
  const [level, setLevel] = useState<Level>("simple");
  const [selected, setSelected] = useState<string>(PALETTE[2].color);
  const [fills, setFills] = useState<Record<string, string>>({});

  const segments = useMemo(() => buildSegments(level), [level]);
  const guides = useMemo(() => buildPetalGuides(level), [level]);

  const reset = () => setFills({});

  const toggleLevel = () => {
    setLevel((l) => (l === "simple" ? "detailed" : "simple"));
    setFills({});
  };

  const handleSegmentClick = (id: string) => {
    setFills((prev) => ({ ...prev, [id]: selected }));
  };

  return (
    <div className="w-full">
      <div className="text-center mb-4">
        <h3 className="font-['Alice'] text-2xl text-[#8B4513]">Mandala à colorier</h3>
        <p className="text-sm text-[#5C3A1E] mt-1">
          Choisis une couleur, pose-la où tu veux. Pas d'objectif, juste se poser.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-[1fr_auto] items-start">
        {/* Mandala SVG */}
        <div className="mx-auto w-full max-w-[520px] rounded-2xl p-2 sm:p-3 bg-[#FBF6EC] border border-sage-200 shadow-sm">
          <svg
            viewBox={`0 0 ${SIZE} ${SIZE}`}
            className="w-full h-auto select-none"
            role="img"
            aria-label="Mandala à colorier"
          >
            <defs>
              <radialGradient id="mandala-bg" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#FBF6EC" />
                <stop offset="100%" stopColor="#F1E7D2" />
              </radialGradient>
              <style>
                {`.seg { transition: fill 600ms ease; cursor: pointer; }
                  .seg:hover { opacity: 0.92; }`}
              </style>
            </defs>

            {/* Fond circulaire doux */}
            <circle cx={CENTER} cy={CENTER} r={OUTER_RADIUS + 8} fill="url(#mandala-bg)" />

            {/* Segments coloriables */}
            {segments.map((seg) => (
              <path
                key={seg.id}
                d={seg.d}
                className="seg"
                fill={fills[seg.id] ?? "#FFFFFF"}
                stroke="#8B4513"
                strokeWidth={1.2}
                strokeLinejoin="round"
                onClick={() => handleSegmentClick(seg.id)}
              />
            ))}

            {/* Lignes guides décoratives */}
            {guides.map((d, i) => (
              <path
                key={`g-${i}`}
                d={d}
                stroke="#8B4513"
                strokeWidth={0.5}
                strokeOpacity={0.18}
                fill="none"
                pointerEvents="none"
              />
            ))}

            {/* Cercle de cadrage extérieur */}
            <circle
              cx={CENTER}
              cy={CENTER}
              r={OUTER_RADIUS}
              fill="none"
              stroke="#8B4513"
              strokeWidth={1.5}
              pointerEvents="none"
            />

            {/* Zone centrale + nuage Noûs décoratif */}
            <circle
              cx={CENTER}
              cy={CENTER}
              r={INNER_RADIUS}
              fill="#FBF6EC"
              stroke="#8B4513"
              strokeWidth={1.5}
              pointerEvents="none"
            />
            <g pointerEvents="none" transform={`translate(${CENTER}, ${CENTER})`}>
              {/* Nuage stylisé : 4 cercles blancs */}
              <g fill="#FFFFFF" stroke="#A7B9A7" strokeWidth={1}>
                <circle cx={-14} cy={4} r={12} />
                <circle cx={0} cy={-6} r={14} />
                <circle cx={14} cy={4} r={12} />
                <ellipse cx={0} cy={10} rx={22} ry={8} />
              </g>
            </g>
          </svg>
        </div>

        {/* Palette + actions */}
        <div className="md:w-56">
          <div className="rounded-2xl p-4 bg-white/70 border border-sage-200">
            <div className="text-sm font-semibold text-[#8B4513] mb-2 font-['Alice']">
              Palette
            </div>
            <div className="grid grid-cols-4 md:grid-cols-4 gap-2">
              {PALETTE.map((c) => {
                const active = selected === c.color;
                return (
                  <button
                    key={c.color}
                    onClick={() => setSelected(c.color)}
                    title={c.name}
                    aria-label={`Couleur ${c.name}`}
                    aria-pressed={active}
                    className={`w-10 h-10 rounded-full border-2 transition-transform ${
                      active
                        ? "border-sage-700 scale-110 shadow-md"
                        : "border-white/80 hover:scale-105"
                    }`}
                    style={{ backgroundColor: c.color }}
                  />
                );
              })}
            </div>
            <div className="mt-3 text-xs text-[#5C3A1E]/80">
              Couleur sélectionnée :{" "}
              <span
                className="inline-block align-middle w-3 h-3 rounded-full border border-sage-300 ml-1"
                style={{ backgroundColor: selected }}
              />
            </div>
          </div>

          <button
            onClick={reset}
            className="mt-3 w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            Recommencer
          </button>
          <button
            onClick={toggleLevel}
            className="mt-2 w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-white/70 text-[#8B4513] hover:bg-sage-50 border border-sage-300 transition-colors"
          >
            <Layers className="w-4 h-4" />
            Niveau : {LEVELS[level].label}
          </button>
        </div>
      </div>
    </div>
  );
};

export default MandalaColoriage;