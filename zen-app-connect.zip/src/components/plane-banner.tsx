import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import planeCloudAsset from "@/assets/plane-cloud.png.asset.json";
import { resolveAssetUrl } from "@/lib/asset-url";

const PLANE_CLOUD = resolveAssetUrl(planeCloudAsset.url);

export const PlaneBanner = () => {
  const [show, setShow] = useState(false);
  const [phase, setPhase] = useState<"pass1" | "pause" | "pass2">("pass1");
  const navigate = useNavigate();

  useEffect(() => {
    try {
      if (sessionStorage.getItem("nous_plane_banner_shown") === "1") return;
    } catch {
      /* ignore */
    }
    const t = setTimeout(() => {
      setShow(true);
      try {
        sessionStorage.setItem("nous_plane_banner_shown", "1");
      } catch {
        /* ignore */
      }
    }, 2500);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (phase !== "pause") return;
    const t = setTimeout(() => {
      setPhase("pass2");
    }, 2500);
    return () => clearTimeout(t);
  }, [phase]);

  if (!show) return null;

  const isPass1 = phase === "pass1";
  const text = isPass1 ? "Demandez votre plan perso" : "Cohérence cardiaque, méditations";
  const link = isPass1 ? "/?open=plan-perso" : "/exercices";
  const ariaLabel = isPass1 ? "Demandez votre plan perso" : "Cohérence cardiaque, méditations";

  const bannerButton = (
    <button
      type="button"
      onClick={() => navigate(link)}
      className="pointer-events-auto whitespace-nowrap rounded-md border-2 border-[#8B4513] bg-[#F5F0E6] px-6 py-2 text-lg font-medium text-[#8B4513] shadow-md"
      style={{
        fontFamily: "'Alice', serif",
        animation: "banner-wave 1.2s ease-in-out infinite",
        transformOrigin: isPass1 ? "left center" : "right center",
      }}
    >
      {text}
    </button>
  );

  const tail = <div className="h-0.5 w-8 bg-[#8B4513]/70" />;

  const plane = (
    <svg
      width="28"
      height="16"
      viewBox="0 0 28 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="mx-[-1px]"
      style={{ transform: isPass1 ? undefined : "scaleX(-1)" }}
      aria-hidden={true}
    >
      <path
        d="M0 8H20"
        stroke="#8B4513"
        strokeOpacity="0.7"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <path
        d="M18 2L26 8L18 14"
        stroke="#8B4513"
        strokeOpacity="0.7"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M20 8L26 8"
        stroke="#8B4513"
        strokeOpacity="0.7"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <path
        d="M16 5L22 8L16 11"
        stroke="#8B4513"
        strokeOpacity="0.7"
        strokeWidth="1"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );

  const cloud = (
    <button
      type="button"
      onClick={() => navigate(link)}
      className={`pointer-events-auto relative flex h-16 w-16 items-center justify-center ${!isPass1 ? "z-50" : ""}`}
      aria-label={ariaLabel}
    >
      <img
        src={PLANE_CLOUD}
        alt="Nuage Noûs sur avion"
        className="h-16 w-16 object-contain drop-shadow-md"
        style={{ transform: isPass1 ? "scaleX(-1)" : undefined }}
      />
    </button>
  );

  return (
    <>
      <style>{`
        @keyframes plane-fly-right {
          0% { transform: translateX(-60vw); }
          100% { transform: translateX(120vw); }
        }
        @keyframes plane-fly-left {
          0% { transform: translateX(120vw); }
          100% { transform: translateX(-60vw); }
        }
        @keyframes banner-wave {
          0%, 100% { transform: rotate(-1deg); }
          50% { transform: rotate(1.5deg); }
        }
      `}</style>
      <div
        className="pointer-events-none fixed left-0 top-24 z-40 w-full overflow-hidden"
        aria-hidden={true}
      >
        <div
          className="flex items-center"
          style={{
            animation: isPass1
              ? "plane-fly-right 14s linear forwards"
              : "plane-fly-left 14s linear forwards",
            width: "max-content",
          }}
          onAnimationEnd={() => {
            if (isPass1) {
              setPhase("pause");
            } else {
              setShow(false);
            }
          }}
        >
          {isPass1 ? (
            <>
              {bannerButton}
              {tail}
              {plane}
              {cloud}
            </>
          ) : (
            <>
              {cloud}
              {plane}
              {tail}
              {bannerButton}
            </>
          )}
        </div>
      </div>
    </>
  );
};
