import { useEffect, useRef, useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Volume2, VolumeX } from "lucide-react";

type Pebble = { x: number; y: number; rx: number; ry: number; rot: number; shade: number };

const SAND_BG = "#E8D5A8";
const SAND_SHADOW = "rgba(120, 85, 40, 0.18)";
const SAND_HIGHLIGHT = "rgba(255, 248, 225, 0.55)";
const RAKE_TINES = 5;
const RAKE_WIDTH = 22;

function drawSandTexture(ctx: CanvasRenderingContext2D, w: number, h: number) {
  // base
  ctx.fillStyle = SAND_BG;
  ctx.fillRect(0, 0, w, h);
  // subtle grain
  const img = ctx.getImageData(0, 0, w, h);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (Math.random() - 0.5) * 18;
    d[i] = Math.max(0, Math.min(255, d[i] + n));
    d[i + 1] = Math.max(0, Math.min(255, d[i + 1] + n));
    d[i + 2] = Math.max(0, Math.min(255, d[i + 2] + n * 0.6));
  }
  ctx.putImageData(img, 0, 0);
}

function drawPebble(ctx: CanvasRenderingContext2D, p: Pebble) {
  ctx.save();
  ctx.translate(p.x, p.y);
  ctx.rotate(p.rot);
  // soft shadow under pebble
  ctx.beginPath();
  ctx.ellipse(2, 4, p.rx * 1.05, p.ry * 1.05, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(80, 60, 30, 0.22)";
  ctx.fill();
  // pebble body
  const grad = ctx.createRadialGradient(-p.rx * 0.3, -p.ry * 0.4, p.ry * 0.2, 0, 0, p.rx);
  const base = 140 + p.shade;
  grad.addColorStop(0, `rgb(${base + 30}, ${base + 28}, ${base + 25})`);
  grad.addColorStop(1, `rgb(${base - 30}, ${base - 32}, ${base - 35})`);
  ctx.beginPath();
  ctx.ellipse(0, 0, p.rx, p.ry, 0, 0, Math.PI * 2);
  ctx.fillStyle = grad;
  ctx.fill();
  ctx.restore();
}

export function JardinSableZen() {
  const sandRef = useRef<HTMLCanvasElement>(null);
  const trailRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [pebbles, setPebbles] = useState<Pebble[]>([]);
  const [size, setSize] = useState({ w: 0, h: 0 });
  const [soundOn, setSoundOn] = useState(false);
  const lastPt = useRef<{ x: number; y: number } | null>(null);
  const drawing = useRef(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const noiseRef = useRef<{ src: AudioBufferSourceNode; gain: GainNode } | null>(null);

  // size canvas to container
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const measure = () => {
      const w = Math.max(0, el.clientWidth - 28); // minus padding (14 * 2)
      const h = Math.max(260, Math.round(w * 0.62));
      setSize((prev) => (prev.w === w && prev.h === h ? prev : { w, h }));
    };
    measure();
    let raf = 0;
    const ro = new ResizeObserver(() => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(measure);
    });
    ro.observe(el);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, []);

  // paint sand + pebbles when size changes
  useEffect(() => {
    if (!size.w || !size.h) return;
    const sand = sandRef.current;
    const trail = trailRef.current;
    if (!sand || !trail) return;
    const dpr = window.devicePixelRatio || 1;
    [sand, trail].forEach((c) => {
      c.width = size.w * dpr;
      c.height = size.h * dpr;
      c.style.width = size.w + "px";
      c.style.height = size.h + "px";
    });
    const sctx = sand.getContext("2d")!;
    sctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawSandTexture(sctx, size.w, size.h);

    // place pebbles only once (or when size unset)
    setPebbles((prev) => {
      if (prev.length) {
        prev.forEach((p) => drawPebble(sctx, p));
        return prev;
      }
      const count = 3 + Math.floor(Math.random() * 2);
      const next: Pebble[] = [];
      const margin = 30;
      for (let i = 0; i < count; i++) {
        for (let t = 0; t < 20; t++) {
          const rx = 14 + Math.random() * 14;
          const ry = rx * (0.55 + Math.random() * 0.25);
          const x = margin + Math.random() * (size.w - margin * 2);
          const y = margin + Math.random() * (size.h - margin * 2);
          const ok = next.every((q) => Math.hypot(q.x - x, q.y - y) > q.rx + rx + 14);
          if (ok) {
            next.push({ x, y, rx, ry, rot: Math.random() * Math.PI, shade: Math.random() * 25 });
            break;
          }
        }
      }
      next.forEach((p) => drawPebble(sctx, p));
      return next;
    });

    const tctx = trail.getContext("2d")!;
    tctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    tctx.clearRect(0, 0, size.w, size.h);
  }, [size]);

  const startSound = useCallback(() => {
    if (!soundOn) return;
    if (noiseRef.current) return;
    try {
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ac = audioCtxRef.current || new Ctx();
      audioCtxRef.current = ac;
      const buf = ac.createBuffer(1, ac.sampleRate * 1, ac.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * 0.35;
      const src = ac.createBufferSource();
      src.buffer = buf;
      src.loop = true;
      const filt = ac.createBiquadFilter();
      filt.type = "bandpass";
      filt.frequency.value = 2200;
      filt.Q.value = 0.7;
      const gain = ac.createGain();
      gain.gain.value = 0;
      src.connect(filt).connect(gain).connect(ac.destination);
      src.start();
      noiseRef.current = { src, gain };
    } catch {
      /* noop */
    }
  }, [soundOn]);

  const stopSound = useCallback(() => {
    const n = noiseRef.current;
    if (!n) return;
    try {
      n.gain.gain.setTargetAtTime(0, audioCtxRef.current!.currentTime, 0.05);
      setTimeout(() => {
        try { n.src.stop(); } catch { /* noop */ }
      }, 200);
    } catch { /* noop */ }
    noiseRef.current = null;
  }, []);

  useEffect(() => () => stopSound(), [stopSound]);
  useEffect(() => { if (!soundOn) stopSound(); }, [soundOn, stopSound]);

  const setSandGain = (v: number) => {
    const n = noiseRef.current;
    if (!n || !audioCtxRef.current) return;
    n.gain.gain.setTargetAtTime(v, audioCtxRef.current.currentTime, 0.03);
  };

  const drawRakeSegment = (x1: number, y1: number, x2: number, y2: number) => {
    const trail = trailRef.current;
    if (!trail) return;
    const ctx = trail.getContext("2d")!;
    const dx = x2 - x1;
    const dy = y2 - y1;
    const len = Math.hypot(dx, dy) || 1;
    const nx = -dy / len;
    const ny = dx / len;
    const step = RAKE_WIDTH / (RAKE_TINES - 1);
    const start = -RAKE_WIDTH / 2;
    for (let i = 0; i < RAKE_TINES; i++) {
      const off = start + i * step;
      // dark groove
      ctx.strokeStyle = SAND_SHADOW;
      ctx.lineWidth = 1.6;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(x1 + nx * off, y1 + ny * off);
      ctx.lineTo(x2 + nx * off, y2 + ny * off);
      ctx.stroke();
      // light edge slightly offset
      ctx.strokeStyle = SAND_HIGHLIGHT;
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.moveTo(x1 + nx * (off + 0.9), y1 + ny * (off + 0.9));
      ctx.lineTo(x2 + nx * (off + 0.9), y2 + ny * (off + 0.9));
      ctx.stroke();
    }
  };

  const getPt = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = (e.target as HTMLCanvasElement).getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  const onDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    (e.target as HTMLCanvasElement).setPointerCapture(e.pointerId);
    drawing.current = true;
    lastPt.current = getPt(e);
    if (soundOn) {
      startSound();
      setSandGain(0.12);
    }
  };

  const onMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawing.current || !lastPt.current) return;
    e.preventDefault();
    const p = getPt(e);
    drawRakeSegment(lastPt.current.x, lastPt.current.y, p.x, p.y);
    lastPt.current = p;
    if (soundOn) setSandGain(0.14);
  };

  const onUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    drawing.current = false;
    lastPt.current = null;
    try { (e.target as HTMLCanvasElement).releasePointerCapture(e.pointerId); } catch { /* noop */ }
    if (soundOn) setSandGain(0);
  };

  const smooth = () => {
    const trail = trailRef.current;
    if (!trail) return;
    const ctx = trail.getContext("2d")!;
    const start = performance.now();
    const duration = 600;
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      ctx.save();
      ctx.globalCompositeOperation = "destination-out";
      ctx.fillStyle = `rgba(0,0,0,${0.08 + t * 0.12})`;
      ctx.fillRect(0, 0, size.w, size.h);
      ctx.restore();
      if (t < 1) requestAnimationFrame(tick);
      else ctx.clearRect(0, 0, size.w, size.h);
    };
    requestAnimationFrame(tick);
  };

  return (
    <div className="w-full">
      <div className="text-center mb-3">
        <h3 className="font-alice text-2xl text-[#8B4513]">Jardin zen</h3>
        <p className="text-sm text-[#A0522D]/80 italic">Trace, ratisse, laisse aller.</p>
      </div>

      <div
        ref={wrapRef}
        className="relative w-full rounded-2xl overflow-hidden select-none"
        style={{
          padding: 14,
          background:
            "repeating-linear-gradient(45deg, #8B5A2B 0 6px, #6B3F1A 6px 12px, #A0651E 12px 18px, #6B3F1A 18px 24px)",
          boxShadow: "0 10px 24px -12px rgba(60,30,10,0.45), inset 0 0 0 2px rgba(255,235,200,0.15)",
        }}
      >
        <div className="relative rounded-xl overflow-hidden" style={{ boxShadow: "inset 0 0 24px rgba(80,50,20,0.35)" }}>
          <canvas ref={sandRef} className="block w-full h-auto" />
          <canvas
            ref={trailRef}
            className="absolute inset-0 block w-full h-full"
            style={{ touchAction: "none", cursor: "crosshair" }}
            onPointerDown={onDown}
            onPointerMove={onMove}
            onPointerUp={onUp}
            onPointerCancel={onUp}
            onPointerLeave={onUp}
          />
          {/* Nuage Noûs en filigrane */}
          <svg
            aria-hidden
            viewBox="0 0 100 60"
            className="pointer-events-none absolute bottom-3 right-3 w-20 opacity-[0.18]"
          >
            <path
              d="M20 40c-8 0-12-6-10-12 2-5 8-6 11-4 1-7 9-11 16-8 4-2 11-1 13 4 7 0 12 5 11 11-1 6-7 9-12 9H20z"
              fill="#6B3F1A"
            />
            <text x="50" y="55" textAnchor="middle" fontSize="8" fontFamily="Alice, serif" fill="#6B3F1A">
              Noûs
            </text>
          </svg>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-3 mt-4">
        <Button
          onClick={smooth}
          className="bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300"
        >
          Lisser le sable
        </Button>
        <button
          type="button"
          onClick={() => setSoundOn((v) => !v)}
          aria-label={soundOn ? "Couper le son" : "Activer le son"}
          className="flex items-center gap-2 text-sm text-[#8B4513] px-3 py-2 rounded-full border border-sage-300 hover:bg-sage-50"
        >
          {soundOn ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          <span>{soundOn ? "Son sable" : "Silencieux"}</span>
        </button>
      </div>
    </div>
  );
}

export default JardinSableZen;