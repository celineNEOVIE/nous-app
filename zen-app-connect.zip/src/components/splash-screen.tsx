import { useEffect, useState } from "react";
import { ImageWithFallback } from "@/components/image-with-fallback";

export const SplashScreen = ({ onFinish }: { onFinish: () => void }) => {
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setLeaving(true), 5000);
    const t2 = setTimeout(() => onFinish(), 5800);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [onFinish]);

  return (
    <div
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#F5F0E6] transition-opacity duration-700 ${
        leaving ? "opacity-0 pointer-events-none" : "opacity-100"
      }`}
    >
      <ImageWithFallback
        src="/lovable-uploads/1919c5e1-b704-4470-9256-3863b6b72f49.png"
        alt="Noûs"
        className="max-h-[85vh] md:max-h-[55vh] max-w-[95vw] md:max-w-[80vw] h-auto w-auto object-contain animate-[breathe_5s_ease-in-out_infinite]"
        loading="eager"
      />
      <div className="relative mt-10 h-8 w-64 text-center">
        <span className="absolute inset-0 text-lg tracking-widest text-sage-700 animate-[inhaleText_5s_ease-in-out_infinite]">
          Inspirez…
        </span>
        <span className="absolute inset-0 text-lg tracking-widest text-sage-700 animate-[exhaleText_5s_ease-in-out_infinite]">
          Expirez…
        </span>
      </div>
    </div>
  );
};