import { useEffect, useRef, useState } from "react";
import { ImageWithFallback } from "@/components/image-with-fallback";

export const SplashScreen = ({ onFinish }: { onFinish: () => void }) => {
  const [leaving, setLeaving] = useState(false);
  const [soundReady, setSoundReady] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const intervalRef = useRef<number | null>(null);
  const startedRef = useRef(false);

  useEffect(() => {
    const t1 = setTimeout(() => setLeaving(true), 5000);
    const t2 = setTimeout(() => onFinish(), 5800);
    // On iOS/iPad, autoplay is blocked; only start on first user interaction.
    const onFirstInteract = () => startBreathSound();
    window.addEventListener("pointerdown", onFirstInteract, { once: true });
    window.addEventListener("keydown", onFirstInteract, { once: true });
    window.addEventListener("touchstart", onFirstInteract, { once: true });
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      window.removeEventListener("pointerdown", onFirstInteract);
      window.removeEventListener("keydown", onFirstInteract);
      window.removeEventListener("touchstart", onFirstInteract);
      if (intervalRef.current) window.clearInterval(intervalRef.current);
      if (audioCtxRef.current) {
        audioCtxRef.current.close().catch(() => {});
        audioCtxRef.current = null;
      }
    };
  }, [onFinish]);

  const startBreathSound = () => {
    if (startedRef.current) return;
    startedRef.current = true;
    setSoundReady(true);

    try {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      const ctx = new AC();
      audioCtxRef.current = ctx;

      // Build a 2s buffer of soft pink-ish noise once, reuse for each breath
      const noiseBuffer = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
      const data = noiseBuffer.getChannelData(0);
      let lastOut = 0;
      for (let i = 0; i < data.length; i++) {
        const white = Math.random() * 2 - 1;
        // simple low-pass for softness
        lastOut = (lastOut + 0.02 * white) / 1.02;
        data[i] = lastOut * 3.5;
      }

      const playBreath = (durationSec: number, peakGain: number, brightness: number) => {
        if (ctx.state === "closed") return;
        const src = ctx.createBufferSource();
        src.buffer = noiseBuffer;
        src.loop = true;

        const filter = ctx.createBiquadFilter();
        filter.type = "lowpass";
        filter.frequency.value = brightness;
        filter.Q.value = 0.7;

        const gain = ctx.createGain();
        const now = ctx.currentTime;
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(peakGain, now + durationSec * 0.45);
        gain.gain.linearRampToValueAtTime(0, now + durationSec);

        src.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);
        src.start(now);
        src.stop(now + durationSec + 0.05);
      };

      // Cycle matches the 5s breathe animation: 2.4s inhale, short pause, 2.4s exhale
      const cycle = () => {
        playBreath(2.4, 0.18, 900); // inhale: softer, slightly brighter
        window.setTimeout(() => {
          playBreath(2.4, 0.14, 600); // exhale: lower, gentler
        }, 2500);
      };

      // Resume context (required on some browsers) then start
      ctx.resume().then(() => {
        cycle();
        intervalRef.current = window.setInterval(cycle, 5000);
      });
    } catch {
      // Audio creation failed (permission, mobile restriction, etc.).
      // The splash screen lifecycle must remain unaffected.
    }
  };

  return (
    <div
      onPointerDown={startBreathSound}
      onTouchStart={startBreathSound}
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#F5F0E6] transition-opacity duration-700 ${
        leaving ? "opacity-0 pointer-events-none" : "opacity-100"
      }`}
    >
      <ImageWithFallback
        src="/lovable-uploads/1919c5e1-b704-4470-9256-3863b6b72f49.png"
        alt="Noûs"
        className="max-h-[85vh] md:max-h-[55vh] max-w-[95vw] md:max-w-[80vw] h-auto w-auto object-contain animate-[breathe_5s_ease-in-out_infinite]"
        loading="eager"
      />
      <div className="relative mt-10 h-8 w-64 text-center">
        <span className="absolute inset-0 text-lg tracking-widest text-sage-700 animate-[inhaleText_5s_ease-in-out_infinite]">
          Inspirez…
        </span>
        <span className="absolute inset-0 text-lg tracking-widest text-sage-700 animate-[exhaleText_5s_ease-in-out_infinite]">
          Expirez…
        </span>
      </div>
      {!soundReady && (
        <button
          type="button"
          onClick={startBreathSound}
          className="mt-6 text-xs tracking-wide text-sage-700/80 underline underline-offset-4"
        >
          Touchez pour activer le son
        </button>
      )}
    </div>
  );
};