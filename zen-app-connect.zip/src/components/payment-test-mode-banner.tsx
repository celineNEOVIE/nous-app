const clientToken = import.meta.env.VITE_PAYMENTS_CLIENT_TOKEN;

export function PaymentTestModeBanner() {
  if (!clientToken) {
    return (
      <div className="w-full bg-red-100 border-b border-red-300 px-4 py-2 text-center text-sm text-red-800">
        Les paiements en production ne sont pas encore configurés. Finalisez le go-live Stripe pour accepter les vrais paiements.
      </div>
    );
  }
  if (clientToken.startsWith("pk_test_")) {
    return (
      <div className="w-full bg-orange-100 border-b border-orange-300 px-4 py-2 text-center text-sm text-orange-800">
        Les paiements en aperçu sont en mode test — aucun débit réel n'est effectué.
      </div>
    );
  }
  return null;
}