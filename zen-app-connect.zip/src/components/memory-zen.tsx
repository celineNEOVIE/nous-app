import { useCallback, useEffect, useMemo, useState } from "react";
import {
  RefreshCw,
  Cloud,
  Leaf,
  Droplet,
  Sun,
  Moon,
  Flower2,
  Feather,
  Shell,
  Sparkles,
  type LucideIcon,
} from "lucide-react";

// ---------------------------------------------------------------------------
// MemoryZen — mini-jeu de mémoire pour Noûs
// Aucune pression : pas de minuteur, juste un compteur discret de paires trouvées.
// ---------------------------------------------------------------------------

type Level = "simple" | "detailed";

type Symbol = { id: string; Icon: LucideIcon; label: string };

const SYMBOLS: Symbol[] = [
  { id: "cloud", Icon: Cloud, label: "Nuage" },
  { id: "leaf", Icon: Leaf, label: "Feuille" },
  { id: "drop", Icon: Droplet, label: "Goutte d'eau" },
  { id: "sun", Icon: Sun, label: "Soleil" },
  { id: "moon", Icon: Moon, label: "Lune" },
  { id: "flower", Icon: Flower2, label: "Fleur" },
  { id: "feather", Icon: Feather, label: "Plume" },
  { id: "shell", Icon: Shell, label: "Coquillage" },
];

type Card = {
  uid: string;
  symbolId: string;
  Icon: LucideIcon;
  label: string;
};

const shuffle = <T,>(arr: T[]): T[] => {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
};

function buildDeck(level: Level): Card[] {
  const pairs = level === "simple" ? 6 : 8;
  const chosen = shuffle(SYMBOLS).slice(0, pairs);
  const deck: Card[] = [];
  chosen.forEach((s) => {
    deck.push({ uid: `${s.id}-a`, symbolId: s.id, Icon: s.Icon, label: s.label });
    deck.push({ uid: `${s.id}-b`, symbolId: s.id, Icon: s.Icon, label: s.label });
  });
  return shuffle(deck);
}

export const MemoryZen = () => {
  const [level, setLevel] = useState<Level>("simple");
  const [deck, setDeck] = useState<Card[]>(() => buildDeck("simple"));
  const [flipped, setFlipped] = useState<string[]>([]); // uids actuellement retournées
  const [matched, setMatched] = useState<Set<string>>(new Set()); // symbolIds appariés
  const [moves, setMoves] = useState(0);
  const [locked, setLocked] = useState(false);

  const reset = useCallback(
    (lvl: Level = level) => {
      setDeck(buildDeck(lvl));
      setFlipped([]);
      setMatched(new Set());
      setMoves(0);
      setLocked(false);
    },
    [level],
  );

  const toggleLevel = useCallback(() => {
    const next: Level = level === "simple" ? "detailed" : "simple";
    setLevel(next);
    reset(next);
  }, [level, reset]);

  const pairsTotal = deck.length / 2;
  const allFound = matched.size === pairsTotal;

  const handleCardClick = (card: Card) => {
    if (locked) return;
    if (matched.has(card.symbolId)) return;
    if (flipped.includes(card.uid)) return;
    if (flipped.length === 2) return;

    const next = [...flipped, card.uid];
    setFlipped(next);

    if (next.length === 2) {
      setMoves((m) => m + 1);
      const [a, b] = next.map((uid) => deck.find((c) => c.uid === uid)!);
      if (a.symbolId === b.symbolId) {
        setMatched((prev) => {
          const n = new Set(prev);
          n.add(a.symbolId);
          return n;
        });
        setTimeout(() => setFlipped([]), 450);
      } else {
        setLocked(true);
        setTimeout(() => {
          setFlipped([]);
          setLocked(false);
        }, 850);
      }
    }
  };

  useEffect(() => {
    // garantit un re-render propre quand le deck change de taille
  }, [deck]);

  const gridCols = useMemo(
    () =>
      level === "simple"
        ? "grid-cols-3 sm:grid-cols-4"
        : "grid-cols-4",
    [level],
  );

  return (
    <div className="w-full">
      <div className="text-center mb-4">
        <h3 className="font-['Alice'] text-2xl text-[#8B4513]">Memory zen</h3>
        <p className="text-sm text-[#5C3A1E] mt-1">
          Retrouve les paires en douceur, à ton rythme.
        </p>
      </div>

      {/* Barre d'options */}
      <div className="flex flex-wrap items-center justify-center gap-2 mb-4">
        <button
          onClick={toggleLevel}
          className="px-4 py-2 rounded-full bg-white/70 border border-sage-300 text-sm text-[#5C3A1E] hover:bg-sage-50 transition-colors"
        >
          Niveau : {level === "simple" ? "Simple (6 paires)" : "Détaillé (8 paires)"}
        </button>
        <button
          onClick={() => reset()}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300 transition-colors text-sm"
        >
          <RefreshCw className="w-4 h-4" />
          Recommencer
        </button>
        <span className="text-xs text-[#8B4513]/70 ml-1">
          {matched.size}/{pairsTotal} paires · {moves} essais
        </span>
      </div>

      {/* Grille de cartes */}
      <div
        className={`mx-auto max-w-md grid ${gridCols} gap-3 sm:gap-4`}
        style={{ perspective: "1000px" }}
      >
        {deck.map((card) => {
          const isMatched = matched.has(card.symbolId);
          const isFlipped = flipped.includes(card.uid) || isMatched;
          const Icon = card.Icon;
          return (
            <button
              key={card.uid}
              type="button"
              onClick={() => handleCardClick(card)}
              aria-label={isFlipped ? card.label : "Carte cachée"}
              className="relative aspect-square min-w-[48px] min-h-[48px] w-full rounded-xl focus:outline-none focus-visible:ring-2 focus-visible:ring-sage-400"
              style={{ transformStyle: "preserve-3d" }}
            >
              <span
                className="absolute inset-0 transition-transform duration-500"
                style={{
                  transformStyle: "preserve-3d",
                  transform: isFlipped ? "rotateY(180deg)" : "rotateY(0deg)",
                }}
              >
                {/* Dos de la carte */}
                <span
                  className="absolute inset-0 rounded-xl bg-gradient-to-br from-sage-200 to-sage-300 border border-sage-300 shadow-sm flex items-center justify-center"
                  style={{ backfaceVisibility: "hidden" }}
                >
                  <span className="w-8 h-8 rounded-full bg-white/40 border border-white/60" />
                </span>
                {/* Face de la carte */}
                <span
                  className={`absolute inset-0 rounded-xl border flex items-center justify-center transition-colors ${
                    isMatched
                      ? "bg-sage-100 border-sage-300 text-sage-700"
                      : "bg-[#FBF6EC] border-sage-200 text-[#8B4513]"
                  }`}
                  style={{
                    backfaceVisibility: "hidden",
                    transform: "rotateY(180deg)",
                  }}
                >
                  <Icon className="w-8 h-8 sm:w-10 sm:h-10" strokeWidth={1.4} />
                </span>
              </span>
            </button>
          );
        })}
      </div>

      {/* Message de fin bienveillant */}
      {allFound && (
        <div className="mt-6 relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#FBF6EC] to-sage-100 border border-sage-200 p-6 text-center animate-fadeIn">
          <div className="flex justify-center mb-3">
            <div
              className="relative w-20 h-12 bg-white rounded-full shadow-inner animate-[breathe_5s_ease-in-out_infinite]"
              aria-hidden
            >
              <span className="absolute -left-3 top-1 w-10 h-10 bg-white rounded-full" />
              <span className="absolute -right-2 top-0 w-12 h-12 bg-white rounded-full" />
              <span className="absolute left-4 -top-3 w-12 h-12 bg-white rounded-full" />
            </div>
          </div>
          <div className="inline-flex items-center gap-2 text-sage-700">
            <Sparkles className="w-4 h-4" />
            <span className="font-['Alice'] text-xl text-[#8B4513]">
              Bravo, tu as retrouvé toutes les paires
            </span>
            <Sparkles className="w-4 h-4" />
          </div>
          <p className="text-sm text-[#5C3A1E] mt-2">
            Prends une grande inspiration… et savoure ce petit moment de calme.
          </p>
        </div>
      )}
    </div>
  );
};

export default MemoryZen;