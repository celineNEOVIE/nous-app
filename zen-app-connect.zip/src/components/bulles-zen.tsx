import { useCallback, useEffect, useRef, useState } from "react";
import { Sparkles } from "lucide-react";

// ---------------------------------------------------------------------------
// BullesZen — mini-jeu de relaxation "éclate les bulles au bon moment"
// Autonome. Session libre : ni score final, ni pénalité, ni game over.
// ---------------------------------------------------------------------------

type Bubble = {
  id: number;
  x: number; // % horizontal position (0-100)
  hue: "sage" | "blue";
  bornAt: number;
  popped?: "success" | "miss" | "expired";
  particles?: Array<{ dx: number; dy: number; id: number }>;
};

// Timings (ms)
const GROW_MS = 4000;
const HOLD_MS = 1000;
const SHRINK_MS = 4000;
const LIFE_MS = GROW_MS + HOLD_MS + SHRINK_MS;
const SPAWN_INTERVAL_MS = 1600;
const MAX_BUBBLES = 3;

const MAX_SIZE = 140; // px
const MIN_SIZE = 20;

let bubbleIdCounter = 0;
const nextBubbleId = () => ++bubbleIdCounter;

const bubbleSize = (age: number) => {
  if (age < GROW_MS) {
    const t = age / GROW_MS;
    return MIN_SIZE + (MAX_SIZE - MIN_SIZE) * t;
  }
  if (age < GROW_MS + HOLD_MS) return MAX_SIZE;
  const t = (age - GROW_MS - HOLD_MS) / SHRINK_MS;
  return MAX_SIZE - (MAX_SIZE - MIN_SIZE) * Math.min(1, t);
};

const isInSweetSpot = (age: number) =>
  age >= GROW_MS - 200 && age <= GROW_MS + HOLD_MS + 300;

export const BullesZen = () => {
  const [bubbles, setBubbles] = useState<Bubble[]>([]);
  const [count, setCount] = useState(0);
  const [now, setNow] = useState(() => Date.now());
  const areaRef = useRef<HTMLDivElement | null>(null);

  // rAF ticker
  useEffect(() => {
    let raf = 0;
    const tick = () => {
      setNow(Date.now());
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  // Spawner
  useEffect(() => {
    const spawn = () => {
      setBubbles((prev) => {
        const alive = prev.filter((b) => !b.popped);
        if (alive.length >= MAX_BUBBLES) return prev;
        const x = 15 + Math.random() * 70;
        const hue: Bubble["hue"] = Math.random() < 0.5 ? "sage" : "blue";
        return [
          ...prev,
          { id: nextBubbleId(), x, hue, bornAt: Date.now() },
        ];
      });
    };
    spawn();
    const iv = setInterval(spawn, SPAWN_INTERVAL_MS);
    return () => clearInterval(iv);
  }, []);

  // Auto-expire bubbles when they finish their life
  useEffect(() => {
    setBubbles((prev) => {
      let changed = false;
      const next = prev
        .map((b) => {
          if (b.popped) return b;
          const age = now - b.bornAt;
          if (age >= LIFE_MS) {
            changed = true;
            return { ...b, popped: "expired" as const };
          }
          return b;
        })
        .filter((b) => {
          if (!b.popped) return true;
          // keep pop animation ~700ms
          return now - b.bornAt < LIFE_MS + 800;
        });
      return changed || next.length !== prev.length ? next : prev;
    });
  }, [now]);

  const popBubble = useCallback((b: Bubble) => {
    if (b.popped) return;
    const age = Date.now() - b.bornAt;
    const success = isInSweetSpot(age);
    const particles = success
      ? Array.from({ length: 8 }).map((_, i) => {
          const angle = (i / 8) * Math.PI * 2;
          const dist = 40 + Math.random() * 20;
          return {
            id: i,
            dx: Math.cos(angle) * dist,
            dy: Math.sin(angle) * dist,
          };
        })
      : undefined;
    setBubbles((prev) =>
      prev.map((x) =>
        x.id === b.id
          ? { ...x, popped: success ? "success" : "miss", particles }
          : x,
      ),
    );
    if (success) setCount((c) => c + 1);
  }, []);

  const handleReset = () => {
    setBubbles([]);
    setCount(0);
  };

  return (
    <div className="w-full">
      <div className="text-center mb-3">
        <h3 className="font-['Alice'] text-2xl text-[#8B4513]">Bulles Zen</h3>
        <p className="text-sm text-[#5C3A1E] mt-1">
          Touchez chaque bulle lorsqu&apos;elle est à sa taille maximale.
        </p>
      </div>

      <div className="flex items-center justify-between mb-2 px-1">
        <div className="inline-flex items-center gap-2 text-sm text-sage-700 bg-sage-100 border border-sage-200 rounded-full px-3 py-1">
          <Sparkles className="w-4 h-4" />
          <span>Bulles apaisées : {count}</span>
        </div>
        <button
          onClick={handleReset}
          className="text-xs px-3 py-1 rounded-full border border-sage-300 text-[#8B4513] hover:bg-sage-50 transition-colors"
        >
          Réinitialiser
        </button>
      </div>

      <div
        ref={areaRef}
        className="relative w-full rounded-2xl overflow-hidden border border-sage-200 select-none"
        style={{
          height: "min(70vh, 460px)",
          background:
            "linear-gradient(135deg,#EAF3E8,#DCEBF0,#E6EEE3,#D8E7EE)",
          backgroundSize: "300% 300%",
          animation: "meditation-gradient 24s ease infinite",
          touchAction: "manipulation",
          WebkitTapHighlightColor: "transparent",
        }}
      >
        {bubbles.map((b) => {
          const age = now - b.bornAt;
          const size = b.popped ? MAX_SIZE : bubbleSize(age);
          const sweet = !b.popped && isInSweetSpot(age);
          const gradient =
            b.hue === "sage"
              ? "radial-gradient(circle at 30% 30%, rgba(255,255,255,0.85), rgba(179,214,174,0.55) 55%, rgba(139,180,132,0.35) 100%)"
              : "radial-gradient(circle at 30% 30%, rgba(255,255,255,0.85), rgba(180,210,230,0.55) 55%, rgba(120,160,200,0.35) 100%)";

          const isPopping = !!b.popped;
          const opacity = b.popped === "expired" ? 0 : isPopping ? 0 : 1;
          const transform = isPopping ? "scale(1.4)" : "scale(1)";

          return (
            <div
              key={b.id}
              style={{
                position: "absolute",
                left: `${b.x}%`,
                bottom: "10%",
                width: size,
                height: size,
                marginLeft: -size / 2,
                borderRadius: "9999px",
                background: gradient,
                boxShadow: sweet
                  ? "0 0 0 3px rgba(137,161,137,0.35), 0 4px 20px rgba(0,0,0,0.08)"
                  : "0 4px 20px rgba(0,0,0,0.06)",
                border: "1px solid rgba(255,255,255,0.7)",
                transition:
                  "transform 350ms ease-out, opacity 350ms ease-out, box-shadow 200ms",
                transform,
                opacity,
                touchAction: "manipulation",
                cursor: "pointer",
              }}
              onPointerDown={(e) => {
                e.preventDefault();
                popBubble(b);
              }}
              role="button"
              aria-label="Bulle zen"
            >
              {b.particles && (
                <>
                  {b.particles.map((p) => (
                    <span
                      key={p.id}
                      style={{
                        position: "absolute",
                        left: "50%",
                        top: "50%",
                        width: 6,
                        height: 6,
                        borderRadius: "9999px",
                        background:
                          b.hue === "sage"
                            ? "rgba(139,180,132,0.9)"
                            : "rgba(120,160,200,0.9)",
                        transform: `translate(${p.dx}px, ${p.dy}px)`,
                        opacity: 0,
                        transition:
                          "transform 600ms ease-out, opacity 600ms ease-out",
                      }}
                    />
                  ))}
                </>
              )}
            </div>
          );
        })}

        {/* Hint at start */}
        {count === 0 && (
          <div className="absolute inset-x-0 top-3 text-center text-xs text-[#5C3A1E]/70 pointer-events-none">
            Respirez… tapez la bulle quand elle atteint sa pleine taille.
          </div>
        )}
      </div>
    </div>
  );
};

export default BullesZen;