import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const STORAGE_KEY = "nous-cookie-consent";

export const CookieBanner = (): JSX.Element | null => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    try {
      if (!localStorage.getItem(STORAGE_KEY)) setVisible(true);
    } catch {
      setVisible(true);
    }
  }, []);

  const decide = (choice: "accepted" | "refused") => {
    try {
      localStorage.setItem(STORAGE_KEY, choice);
    } catch {
      /* ignore */
    }
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div
      role="dialog"
      aria-live="polite"
      aria-label="Consentement aux cookies"
      className="fixed inset-x-0 bottom-0 z-[90] p-3 sm:p-4"
    >
      <div className="mx-auto max-w-3xl rounded-2xl border border-[#D9C9A8] bg-[#F5F0E6]/95 backdrop-blur shadow-lg p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4">
          <img
            src="/lovable-uploads/1919c5e1-b704-4470-9256-3863b6b72f49.png"
            alt=""
            aria-hidden="true"
            className="h-8 w-8 sm:h-9 sm:w-9 object-contain shrink-0 opacity-90"
          />
          <p className="text-sm leading-relaxed text-[#5B3A1E] flex-1">
            Noûs utilise uniquement des cookies techniques nécessaires au bon fonctionnement du site.
            En savoir plus dans notre{" "}
            <Link
              to="/politique-confidentialite"
              className="underline underline-offset-2 text-[#8B4513] hover:text-[#6b3410]"
            >
              politique de confidentialité
            </Link>
            .
          </p>
          <div className="flex gap-2 sm:shrink-0">
            <Button
              variant="outline"
              size="sm"
              onClick={() => decide("refused")}
              className="flex-1 sm:flex-none border-[#8B4513] text-[#8B4513] hover:bg-[#8B4513]/10"
            >
              Refuser
            </Button>
            <Button
              size="sm"
              onClick={() => decide("accepted")}
              className="flex-1 sm:flex-none bg-[#8B4513] text-[#F5F0E6] hover:bg-[#6b3410]"
            >
              Accepter
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;