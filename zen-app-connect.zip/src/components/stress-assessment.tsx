import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Volume2, VolumeX, Play, ArrowLeft, Square } from "lucide-react";
import binauralBrainAsset from "@/assets/binaural-brain.png.asset.json";
import lacherPriseAudio from "@/assets/lacher-prise.mp3.asset.json";
import binauralThetaAudio from "@/assets/binaural-8hz-theta.m4a.asset.json";
import binauralBannerAsset from "@/assets/fond-binaural-bandeau.png.asset.json";
import binauralDeltaAudio from "@/assets/binaural-2hz-delta.m4a.asset.json";
import binauralDeltaBannerAsset from "@/assets/fond-binaural-sommeil-bandeau.png.asset.json";
import binauralAlphaAudio from "@/assets/binaural-10hz-alpha.wav.asset.json";
import binauralAlphaBannerAsset from "@/assets/fond-binaural-alpha-bandeau.png.asset.json";
import binaural963Audio from "@/assets/binaural-963hz-guerison.m4a.asset.json";
import binaural963BannerAsset from "@/assets/fond-binaural-963hz-bandeau.png.asset.json";
import bulleDouceurVideo from "@/assets/bulle-douceur.mp4.asset.json";
import meditationBackgroundVideo from "@/assets/meditation-background.mp4.asset.json";
import pauseRespirationVideo from "@/assets/pause-respiration-v2.mp4.asset.json";
import meditationZenVideo from "@/assets/meditation-zen.mp4.asset.json";
import meditationRiviereVideo from "@/assets/meditation-riviere.mp4.asset.json";
import meditationBaladeVideo from "@/assets/meditation-balade.mp4.asset.json";

import { startNatureSound, type NatureSound, type NatureSoundHandle } from "@/lib/nature-sounds";
import { resolveAssetUrl } from "@/lib/asset-url";

const BINAURAL_BRAIN_ICON = resolveAssetUrl(binauralBrainAsset.url);
const BINAURAL_BANNER = resolveAssetUrl(binauralBannerAsset.url);
const BINAURAL_DELTA_BANNER = resolveAssetUrl(binauralDeltaBannerAsset.url);
const BINAURAL_ALPHA_BANNER = resolveAssetUrl(binauralAlphaBannerAsset.url);
const BINAURAL_963_BANNER = resolveAssetUrl(binaural963BannerAsset.url);
import { BreathingCloud } from "@/components/breathing-cloud";
import { CoherenceExercise, type Phase, type CoherencePalette } from "@/components/coherence-exercise";
import { BullesZen } from "@/components/bulles-zen";
import { MandalaColoriage } from "@/components/mandala-coloriage";
import { MemoryZen } from "@/components/memory-zen";
import { JardinSableZen } from "@/components/jardin-sable-zen";

type CoherenceExerciseId = "express" | "soir" | "profonde";

interface CoherenceExerciseConfig {
  id: CoherenceExerciseId;
  title: string;
  shortDesc: string;
  introText: string;
  palette: CoherencePalette;
  pattern: Phase[];
  durationOptions: number[]; // in minutes
  defaultDurationMin: number;
}

const COHERENCE_EXERCISES: Record<CoherenceExerciseId, CoherenceExerciseConfig> = {
  express: {
    id: "express",
    title: "Cohérence express",
    shortDesc: "Un format rapide pour calmer une montée de stress, où que vous soyez.",
    introText: "Respiration carrée\nInspirez, retenez, expirez, retenez — 4 secondes chacun.",
    palette: "day",
    pattern: [
      { kind: "in", label: "Inspirez…", duration: 4 },
      { kind: "hold-in", label: "Retenez…", duration: 4 },
      { kind: "out", label: "Expirez…", duration: 4 },
      { kind: "hold-out", label: "Retenez…", duration: 4 },
    ],
    durationOptions: [2, 3],
    defaultDurationMin: 2,
  },
  soir: {
    id: "soir",
    title: "Cohérence du soir",
    shortDesc: "Une respiration apaisante pour préparer le corps et l'esprit au sommeil.",
    introText: "Technique 4-7-8\nInspirez 4s, retenez 7s, expirez lentement 8s.",
    palette: "night",
    pattern: [
      { kind: "in", label: "Inspirez doucement…", duration: 4 },
      { kind: "hold-in", label: "Retenez…", duration: 7 },
      { kind: "out", label: "Expirez lentement…", duration: 8 },
    ],
    durationOptions: [5],
    defaultDurationMin: 5,
  },
  profonde: {
    id: "profonde",
    title: "Cohérence profonde",
    shortDesc: "La pratique de référence en cohérence cardiaque (6 respirations par minute), idéale pour un ancrage quotidien.",
    introText: "5 secondes d'inspiration, 5 secondes d'expiration.\nLaissez-vous porter par le rythme.",
    palette: "day",
    pattern: [
      { kind: "in", label: "Inspirez…", duration: 5 },
      { kind: "out", label: "Expirez…", duration: 5 },
    ],
    durationOptions: [5, 10],
    defaultDurationMin: 5,
  },
};

type Category = "Sommeil" | "Tensions physiques" | "Charge mentale" | "Émotions" | "Relations";

const QUESTIONS: { category: Category; text: string }[] = [
  { category: "Sommeil", text: "Avez-vous du mal à vous endormir ou à rester endormi ?" },
  { category: "Sommeil", text: "Vous réveillez-vous fatigué(e) même après une nuit de sommeil ?" },
  { category: "Tensions physiques", text: "Ressentez-vous des tensions musculaires (cou, épaules, mâchoire) ?" },
  { category: "Tensions physiques", text: "Souffrez-vous de maux de tête, de ventre ou de dos sans cause médicale identifiée ?" },
  { category: "Charge mentale", text: "Avez-vous l'impression d'avoir trop de choses à gérer en même temps ?" },
  { category: "Charge mentale", text: "Avez-vous du mal à vous concentrer ou à prendre des décisions\u00A0?" },
  { category: "Émotions", text: "Vous sentez-vous irritable, anxieux(se) ou submergé(e) par vos émotions ?" },
  { category: "Émotions", text: "Avez-vous du mal à profiter de moments qui vous plaisaient avant ?" },
  { category: "Relations", text: "Avez-vous tendance à vous isoler ou à éviter les autres ?" },
  { category: "Relations", text: "Avez-vous l'impression de manquer de soutien de votre entourage ?" },
];

const ANSWERS = [
  { label: "Jamais", value: 0 },
  { label: "Parfois", value: 1 },
  { label: "Souvent", value: 2 },
  { label: "Tout le temps", value: 3 },
];


function messageForScore(score: number) {
  if (score <= 2) return "Cette dimension semble plutôt équilibrée.";
  if (score <= 4) return "Cette dimension mérite votre attention.";
  return "Cette dimension semble particulièrement sous tension.";
}

function suggestionForCategory(category: Category | undefined) {
  if (!category) return null;
  if (category === "Sommeil" || category === "Tensions physiques") {
    return "D'après vos réponses, la Cohérence cardiaque pourrait particulièrement vous convenir, mais vous êtes libre de choisir ce qui vous semble le plus juste pour vous maintenant.";
  }
  return "D'après vos réponses, la Méditation guidée pourrait particulièrement vous convenir, mais vous êtes libre de choisir ce qui vous semble le plus juste pour vous maintenant.";
}

export const StressAssessment = ({
  open,
  onOpenChange,
  targetView,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  targetView?: "coherence" | "meditation" | "meditation-zen" | "exercices" | "tools" | null;
}) => {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [view, setView] = useState<"intro" | "questions" | "results" | "coherence" | "meditation" | "exercices" | "sons" | "nature" | "contact" | "contact-sent">("intro");
  const [mode, setMode] = useState<"assessment" | "tools">("assessment");
  const [preAnswers, setPreAnswers] = useState<{ followedUp: boolean | null; consulted: boolean | null }>({ followedUp: null, consulted: null });
  const [coherenceSubView, setCoherenceSubView] = useState<"menu" | "breathing" | "video" | "cloud" | "exercise-setup" | "exercise-run">("menu");
  const [meditationSubView, setMeditationSubView] = useState<"menu" | "bulle-douceur" | "zen" | "riviere" | "balade">("menu");
  const [exerciceSubView, setExerciceSubView] = useState<"menu" | "bulles-zen" | "mandala" | "memory" | "jardin">("menu");
  const [sonsSubView, setSonsSubView] = useState<"menu" | "binaural" | "binauralDelta" | "binauralAlpha" | "binaural963">("menu");
  const [activeExerciseId, setActiveExerciseId] = useState<CoherenceExerciseId | null>(null);
  const [exerciseDurationMin, setExerciseDurationMin] = useState<number>(2);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [videoPlaying, setVideoPlaying] = useState(false);
  const [contact, setContact] = useState({ name: "", phone: "", slots: "" });
  const [soundOn, setSoundOn] = useState(false);
  const [openCycle, setOpenCycle] = useState(0);
  const meditationAudioRef = useRef<HTMLAudioElement | null>(null);
  const [meditationPlaying, setMeditationPlaying] = useState(false);
  const meditationVideoRef = useRef<HTMLVideoElement | null>(null);
  const bulleDouceurVideoRef = useRef<HTMLVideoElement | null>(null);
  const zenVideoRef = useRef<HTMLVideoElement | null>(null);
const riviereVideoRef = useRef<HTMLVideoElement | null>(null);
const baladeVideoRef = useRef<HTMLVideoElement | null>(null);
  const [coherenceSound, setCoherenceSound] = useState<NatureSound | "drone">("drone");
  const [meditationNature, setMeditationNature] = useState<NatureSound>("none");
  const natureRef = useRef<NatureSoundHandle | null>(null);
  const audioRef = useRef<{
    ctx: AudioContext;
    nodes: { stop: () => void };
  } | null>(null);

  const stopNatureSound = () => {
    if (natureRef.current) {
      natureRef.current.stop();
      natureRef.current = null;
    }
  };

  const playNatureSound = (kind: NatureSound, volume = 0.3) => {
    stopNatureSound();
    if (kind === "none") return;
    natureRef.current = startNatureSound(kind, volume);
  };

  const stopAmbientSound = () => {
    if (audioRef.current) {
      audioRef.current.nodes.stop();
      audioRef.current.ctx.close().catch(() => {});
      audioRef.current = null;
    }
    stopNatureSound();
  };

  const startAmbientSound = () => {
    if (audioRef.current) return;
    try {
      const Ctx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx: AudioContext = new Ctx();
      // Some browsers (Safari/iOS, Chrome with strict autoplay) create the
      // context in a "suspended" state — without resume() no sound is heard.
      if (ctx.state === "suspended") {
        ctx.resume().catch(() => {});
      }
      const master = ctx.createGain();
      master.gain.value = 0.15;
      master.connect(ctx.destination);

      const osc1 = ctx.createOscillator();
      osc1.type = "sine";
      osc1.frequency.value = 110;
      const osc2 = ctx.createOscillator();
      osc2.type = "sine";
      osc2.frequency.value = 220;
      const osc3 = ctx.createOscillator();
      osc3.type = "sine";
      osc3.frequency.value = 164.81;

      const g1 = ctx.createGain(); g1.gain.value = 0.6;
      const g2 = ctx.createGain(); g2.gain.value = 0.25;
      const g3 = ctx.createGain(); g3.gain.value = 0.2;

      // LFO modulation on master gain for breathing-like swell
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.1;
      const lfoGain = ctx.createGain();
      lfoGain.gain.value = 0.02;
      lfo.connect(lfoGain);
      lfoGain.connect(master.gain);

      osc1.connect(g1).connect(master);
      osc2.connect(g2).connect(master);
      osc3.connect(g3).connect(master);

      osc1.start(); osc2.start(); osc3.start(); lfo.start();

      audioRef.current = {
        ctx,
        nodes: {
          stop: () => {
            try { osc1.stop(); osc2.stop(); osc3.stop(); lfo.stop(); } catch {}
          },
        },
      };
    } catch {}
  };

  const stopAllMedia = () => {
    const meditationAudio = meditationAudioRef.current;
    if (meditationAudio) {
      meditationAudio.pause();
      meditationAudio.currentTime = 0;
    }
    const videos = [videoRef.current, meditationVideoRef.current, bulleDouceurVideoRef.current, zenVideoRef.current, riviereVideoRef.current, baladeVideoRef.current];
    videos.forEach((video) => {
      if (!video) return;
      video.pause();
      video.currentTime = 0;
    });
    stopAmbientSound();
  };

  const resetMediaState = () => {
    stopAllMedia();
    setMeditationPlaying(false);
    setVideoPlaying(false);
    setSoundOn(false);
  };

  useEffect(() => {
    if (open) setOpenCycle((cycle) => cycle + 1);
  }, [open]);

  // Stop sound automatically when leaving the exercise views or closing the dialog
  useEffect(() => {
    if ((view !== "coherence" && view !== "meditation" && view !== "nature") || !open) {
      resetMediaState();
    }
  }, [view, open]);

  // Cleanup on unmount
  useEffect(() => {
    return () => stopAllMedia();
  }, []);

  // Sync background video with meditation audio playback
  useEffect(() => {
    const v = meditationVideoRef.current;
    if (!v) return;
    if (meditationPlaying) {
      v.currentTime = 0;
      v.play().catch(() => {});
    } else {
      v.pause();
    }
  }, [meditationPlaying]);

  // Zen meditation: audio is embedded in the video itself — no parallel <audio> needed.

  // Auto-navigate to a specific exercise when requested from outside
  useEffect(() => {
    if (open && targetView === "coherence") {
      setView("coherence");
      setSoundOn(false);
    } else if (open && targetView === "meditation") {
      setView("meditation");
      setSoundOn(false);
    } else if (open && targetView === "meditation-zen") {
      setView("meditation");
      setMeditationSubView("zen");
      setSoundOn(false);
    } else if (open && targetView === "exercices") {
      setView("exercices");
    } else if (open && targetView === "tools") {
      setMode("tools");
      setView("results");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, targetView]);

  const handleStartCoherence = () => {
    setView("coherence");
    setSoundOn(false);
  };

  const handleStartMeditation = () => {
    setView("meditation");
    setSoundOn(false);
  };

  const handleToggleSound = () => {
    if (view === "meditation") {
      const el = meditationAudioRef.current;
      const willPlay = el ? el.paused : !soundOn;
      if (willPlay) {
        el?.play().catch(() => {});
        if (meditationNature !== "none" && !natureRef.current) {
          playNatureSound(meditationNature, 0.18);
        }
        setSoundOn(true);
      } else {
        el?.pause();
        stopNatureSound();
        setSoundOn(false);
      }
      return;
    }
    if (audioRef.current || natureRef.current) {
      stopAmbientSound();
      setSoundOn(false);
    } else {
      if (coherenceSound === "drone") startAmbientSound();
      else playNatureSound(coherenceSound, 0.35);
      setSoundOn(true);
    }
  };

  const handlePickCoherenceSound = (kind: NatureSound | "drone") => {
    setCoherenceSound(kind);
    if (view !== "coherence" || !soundOn) return;
    stopAmbientSound();
    if (kind === "drone") startAmbientSound();
    else playNatureSound(kind, 0.35);
  };

  const handlePickMeditationNature = (kind: NatureSound) => {
    setMeditationNature(kind);
    if (view !== "meditation" || !soundOn) return;
    stopNatureSound();
    if (kind !== "none") playNatureSound(kind, 0.18);
  };

  const handleStopMeditation = () => {
    const audio = meditationAudioRef.current;
    if (audio) {
      audio.pause();
      audio.currentTime = 0;
    }
    stopAmbientSound();
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
    setMeditationPlaying(false);
    setVideoPlaying(false);
    setSoundOn(false);
  };

  const reset = () => {
    setStep(0);
    setAnswers([]);
    setView("intro");
    setCoherenceSubView("menu");
    setMeditationSubView("menu");
    setExerciceSubView("menu");
    setSonsSubView("menu");
    setPreAnswers({ followedUp: null, consulted: null });
    setContact({ name: "", phone: "", slots: "" });
    setMode("assessment");
    resetMediaState();
  };

  const handleAnswer = (value: number) => {
    const next = [...answers, value];
    setAnswers(next);
    if (step + 1 < QUESTIONS.length) {
      setStep(step + 1);
    } else {
      setView("results");
    }
  };

  const handleClose = (o: boolean) => {
    if (!o) {
      resetMediaState();
      reset();
    }
    onOpenChange(o);
  };

  const scoresByCategory: Record<Category, number> = {
    "Sommeil": 0,
    "Tensions physiques": 0,
    "Charge mentale": 0,
    "Émotions": 0,
    "Relations": 0,
  };
  answers.forEach((v, i) => {
    scoresByCategory[QUESTIONS[i].category] += v;
  });
  const total = answers.reduce((a, b) => a + b, 0);
  const topCategory = (Object.entries(scoresByCategory) as [Category, number][])
    .sort((a, b) => b[1] - a[1])[0]?.[0] as Category | undefined;

  const progress = view === "questions" ? ((step) / QUESTIONS.length) * 100 : 100;

  const introReady = preAnswers.followedUp !== null && preAnswers.consulted !== null;

  return (
    <>
      {open && view === "meditation" && meditationPlaying && (
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-[60] opacity-95 transition-opacity duration-[2000ms] ease-in-out"
      >
        <div className="absolute inset-0 meditation-bg" />
        {/* Vidéo de fond animée */}
        <video
          ref={meditationVideoRef}
          src={resolveAssetUrl(meditationBackgroundVideo.url)}
          className="absolute inset-0 w-full h-full object-cover"
          muted
          playsInline
          loop
          preload="auto"
          aria-hidden
        />
        <div className="absolute inset-0 bg-black/20" />
        {/* Particules flottantes */}
        <div className="absolute inset-0">
          {Array.from({ length: 14 }).map((_, i) => {
            const size = 3 + ((i * 1.7) % 5);
            const left = (i * 37) % 90 + 5;
            const top = (i * 53) % 80 + 5;
            const delay = (i * 0.7) % 4;
            const duration = 5 + ((i * 0.9) % 4);
            return (
              <span
                key={i}
                className="absolute rounded-full meditation-particle"
                style={{
                  width: `${size}px`,
                  height: `${size}px`,
                  left: `${left}%`,
                  top: `${top}%`,
                  background: `rgba(200,180,255,${0.2 + ((i % 5) * 0.08)})`,
                  animationDelay: `${delay}s`,
                  animationDuration: `${duration}s`,
                }}
              />
            );
          })}
        </div>
        {/* Cercle de respiration */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="meditation-breath w-[160px] h-[160px] rounded-full flex items-center justify-center"
               style={{ background: "rgba(180,150,255,0.18)", border: "1.5px solid rgba(200,170,255,0.4)" }}>
            <div className="w-[100px] h-[100px] rounded-full flex items-center justify-center"
                 style={{ background: "rgba(200,170,255,0.22)", border: "1px solid rgba(220,200,255,0.5)" }}>
              <div className="w-[52px] h-[52px] rounded-full"
                   style={{ background: "rgba(230,215,255,0.35)" }} />
            </div>
          </div>
        </div>
      </div>
      )}
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent
        key={openCycle}
        className="mobile-scroll-dialog !block bg-[#F5F0E6] border-sage-300 p-4 pb-[calc(1rem+env(safe-area-inset-bottom))] sm:!grid sm:w-[calc(100vw-1rem)] sm:max-w-xl sm:p-6"
      >
        <div className="min-h-0 pr-1">
        {view === "intro" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-[#8B4513]">Évaluer mon stress</DialogTitle>
              <DialogDescription className="text-[#A0522D]">
                Quelques questions pour mieux cerner votre ressenti du moment.
              </DialogDescription>
            </DialogHeader>
            <div className="mt-4 space-y-6">
              <div className="p-4 rounded-lg bg-white/60 border border-sage-200 text-sm text-[#5C3A1E] leading-relaxed">
                <strong className="text-[#8B4513]">Important :</strong> cet outil ne remplace pas un avis médical, un diagnostic ou un suivi par un professionnel de santé. Il vise simplement à mieux cerner votre ressenti du moment et à vous orienter vers des ressources adaptées.
              </div>
              <div className="space-y-4">
                <div>
                  <p className="text-[#5C3A1E] mb-2">
                    Êtes-vous actuellement suivi(e) par un médecin ou un psychologue/psychiatre pour cette situation ?
                  </p>
                  <div className="flex gap-3">
                    {([true, false] as const).map((val) => (
                      <button
                        key={val ? "oui" : "non"}
                        onClick={() => setPreAnswers((p) => ({ ...p, followedUp: val }))}
                        className={`flex-1 px-4 py-2 text-sm font-medium rounded-lg border transition-colors ${
                          preAnswers.followedUp === val
                            ? "bg-sage-200 text-sage-700 border-sage-400"
                            : "bg-white/60 text-[#5C3A1E] border-sage-200 hover:bg-sage-50"
                        }`}
                      >
                        {val ? "Oui" : "Non"}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-[#5C3A1E] mb-2">
                    Avez-vous déjà consulté un professionnel de santé à ce sujet ?
                  </p>
                  <div className="flex gap-3">
                    {([true, false] as const).map((val) => (
                      <button
                        key={val ? "oui" : "non"}
                        onClick={() => setPreAnswers((p) => ({ ...p, consulted: val }))}
                        className={`flex-1 px-4 py-2 text-sm font-medium rounded-lg border transition-colors ${
                          preAnswers.consulted === val
                            ? "bg-sage-200 text-sage-700 border-sage-400"
                            : "bg-white/60 text-[#5C3A1E] border-sage-200 hover:bg-sage-50"
                        }`}
                      >
                        {val ? "Oui" : "Non"}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <Button
                disabled={!introReady}
                onClick={() => setView("questions")}
                className="w-full bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300 disabled:opacity-50 disabled:pointer-events-none"
              >
                Commencer le questionnaire
              </Button>
              <p className="text-xs text-center text-[#A0522D]/70">
                Vos réponses ne sont pas enregistrées sur un serveur et restent uniquement sur votre appareil.
              </p>
            </div>
          </>
        )}

        {view === "questions" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-[#8B4513]">
                {QUESTIONS[step].category}
              </DialogTitle>
              <DialogDescription className="text-[#A0522D]">
                Question {step + 1} sur {QUESTIONS.length}
              </DialogDescription>
            </DialogHeader>
            <Progress value={progress} className="h-2" />
            <p className="mt-6 mb-6 text-lg text-[#5C3A1E] leading-relaxed">
              {QUESTIONS[step].text}
            </p>
            <div className="grid gap-3">
              {ANSWERS.map((a) => (
                <button
                  key={a.label}
                  onClick={() => handleAnswer(a.value)}
                  className="w-full px-6 py-3 text-base font-medium transition-colors rounded-lg bg-sage-100 text-sage-700 hover:bg-sage-200 border border-sage-300"
                >
                  {a.label}
                </button>
              ))}
            </div>
            <p className="mt-6 text-xs text-center text-[#A0522D]/70">
              Vos réponses ne sont pas enregistrées sur un serveur et restent uniquement sur votre appareil.
            </p>
          </>
        )}

        {view === "results" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-[#8B4513]">
                {mode === "tools" ? "Exercices" : "Vos résultats"}
              </DialogTitle>
              <DialogDescription className="text-[#A0522D]">
                {mode === "tools"
                  ? "Retrouvez vos outils de détente, de respiration et de méditation."
                  : `Score global : ${total} / 30`}
              </DialogDescription>
            </DialogHeader>
            {mode === "assessment" && (
            <div className="space-y-4 mt-4">
              {(Object.entries(scoresByCategory) as [Category, number][]).map(([cat, score]) => (
                <div key={cat} className="p-4 rounded-lg bg-white/60 border border-sage-200">
                  <div className="flex items-baseline justify-between mb-1">
                    <h3 className="font-semibold text-[#8B4513]">{cat}</h3>
                    <span className="text-sm text-[#A0522D]">{score} / 6</span>
                  </div>
                  <p className="text-sm text-[#5C3A1E]">{messageForScore(score)}</p>
                </div>
              ))}
            </div>
            )}
            {mode === "assessment" && preAnswers.followedUp && (
              <div className="mt-4 p-4 rounded-lg bg-sage-50 border border-sage-200 text-sm text-[#5C3A1E] leading-relaxed">
                Vous bénéficiez déjà d'un suivi professionnel, c'est important de le maintenir. Cet outil peut être un complément, en lien avec votre praticien si besoin.
              </div>
            )}
            <div className="mt-6 space-y-3">
              {mode === "assessment" && topCategory && (
                <p className="text-sm text-center text-[#5C3A1E] italic leading-relaxed">
                  {suggestionForCategory(topCategory)}
                </p>
              )}
              <button
                onClick={handleStartCoherence}
                className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
              >
                <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center text-sage-700 font-semibold text-xs shrink-0">
                  5 min
                </div>
                <div>
                  <div className="font-semibold text-[#8B4513]">Cohérence cardiaque</div>
                  <div className="text-sm text-[#5C3A1E]">Exercice de respiration guidée</div>
                </div>
              </button>
              <button
                onClick={() => { setView("meditation"); setMeditationSubView("menu"); }}
                className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
              >
                <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center text-sage-700 shrink-0">
                  <span className="text-2xl">🧘</span>
                </div>
                <div>
                  <div className="font-semibold text-[#8B4513]">Méditations</div>
                  <div className="text-sm text-[#5C3A1E]">Guidée et zen</div>
                </div>
              </button>
              <button
                onClick={() => { setView("exercices"); setExerciceSubView("menu"); }}
                className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
              >
                <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center text-sage-700 shrink-0">
                  <span className="text-2xl">🌿</span>
                </div>
                <div>
                  <div className="font-semibold text-[#8B4513]">Exercices de détente</div>
                  <div className="text-sm text-[#5C3A1E]">Bulles Zen et mandala</div>
                </div>
              </button>
              <button
                onClick={() => { setView("sons"); setSonsSubView("menu"); }}
                className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
              >
                <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center shrink-0">
                  <img src={BINAURAL_BRAIN_ICON} alt="" className="h-11 w-11 object-contain" />
                </div>
                <div>
                  <div className="font-semibold text-[#8B4513]">Sons</div>
                  <div className="text-sm text-[#5C3A1E]">Fréquences et ambiances sonores</div>
                </div>
              </button>
              <button
                onClick={() => setView("contact")}
                className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
              >
                <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center text-sage-700 font-semibold text-xs shrink-0">
                  Contact
                </div>
                <div>
                  <div className="font-semibold text-[#8B4513]">Être recontacté par un praticien</div>
                  <div className="text-sm text-[#5C3A1E]">Nom, téléphone et créneaux préférés</div>
                </div>
              </button>
            </div>
            <p className="mt-4 text-xs text-center text-[#A0522D]/70">
              Vos réponses ne sont pas enregistrées sur un serveur et restent uniquement sur votre appareil.
            </p>
          </>
        )}

        {view === "coherence" && (
          <>
            <button
              type="button"
              onClick={handleStopMeditation}
              aria-label="Arrêter l'exercice"
              className="absolute right-20 top-4 p-2 rounded-full text-[#8B4513] hover:bg-sage-100 transition-colors"
            >
              <Square className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={handleToggleSound}
              aria-label={soundOn ? "Couper le son" : "Activer le son"}
              className="absolute right-12 top-4 p-2 rounded-full text-[#8B4513] hover:bg-sage-100 transition-colors"
            >
              {soundOn ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </button>
            <DialogHeader>
              <DialogTitle className="text-[#8B4513]">Cohérence cardiaque</DialogTitle>
              <DialogDescription className="text-[#A0522D]">
                Exercice de respiration guidée — choisissez votre mode
              </DialogDescription>
            </DialogHeader>

            {coherenceSubView === "menu" && (
              <div className="mt-6 space-y-3">
                <button
                  onClick={() => {
                    setCoherenceSubView("breathing");
                    setSoundOn(false);
                  }}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
                >
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center text-sage-700 shrink-0">
                    <Volume2 className="h-7 w-7" />
                  </div>
                  <div>
                    <div className="font-semibold text-[#8B4513]">Respiration guidée</div>
                    <div className="text-sm text-[#5C3A1E]">Texte + ambiance sonore — 5 min</div>
                  </div>
                </button>


                {(Object.values(COHERENCE_EXERCISES)).map((ex) => (
                  <button
                    key={ex.id}
                    onClick={() => {
                      stopAmbientSound();
                      setSoundOn(false);
                      setActiveExerciseId(ex.id);
                      setExerciseDurationMin(ex.defaultDurationMin);
                      setCoherenceSubView("exercise-setup");
                    }}
                    className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
                  >
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 ${
                      ex.palette === "night" ? "bg-[#2A2350] text-[#E8DCFB]" : "bg-sage-200 text-sage-700"
                    }`}>
                      <span className="text-2xl">{ex.palette === "night" ? "🌙" : "☁️"}</span>
                    </div>
                    <div>
                      <div className="font-semibold text-[#8B4513]">{ex.title}</div>
                      <div className="text-sm text-[#5C3A1E]">{ex.shortDesc}</div>
                    </div>
                  </button>
                ))}


              </div>
            )}

            {coherenceSubView === "exercise-setup" && activeExerciseId && (() => {
              const ex = COHERENCE_EXERCISES[activeExerciseId];
              return (
                <div className="mt-4 space-y-4">
                  <div>
                    <div className="font-semibold text-[#8B4513] text-lg font-['Alice']">{ex.title}</div>
                    <p className="text-sm text-[#5C3A1E] mt-1 leading-relaxed">{ex.shortDesc}</p>
                    <p className="text-xs text-[#A0522D]/70 mt-2 whitespace-pre-line">{ex.introText}</p>
                  </div>
                  {ex.durationOptions.length > 1 && (
                    <div>
                      <p className="text-xs font-medium text-[#8B4513] mb-2">Durée</p>
                      <div className="flex flex-wrap gap-2">
                        {ex.durationOptions.map((min) => (
                          <button
                            key={min}
                            type="button"
                            onClick={() => setExerciseDurationMin(min)}
                            className={`px-3 py-1.5 text-xs rounded-full border transition-colors ${
                              exerciseDurationMin === min
                                ? "bg-sage-300 text-sage-800 border-sage-400"
                                : "bg-white/60 text-[#5C3A1E] border-sage-200 hover:bg-sage-50"
                            }`}
                          >
                            {min} min
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  <div className="flex justify-end">
                    <Button
                      onClick={() => setCoherenceSubView("exercise-run")}
                      className="bg-sage-300 text-sage-800 hover:bg-sage-400 border border-sage-400"
                    >
                      Commencer
                    </Button>
                  </div>
                </div>
              );
            })()}

            {coherenceSubView === "exercise-run" && activeExerciseId && (() => {
              const ex = COHERENCE_EXERCISES[activeExerciseId];
              return (
                <div className="mt-4">
                  <CoherenceExercise
                    pattern={ex.pattern}
                    durationSec={exerciseDurationMin * 60}
                    introText={ex.introText}
                    palette={ex.palette}
                    title={ex.title}
                    muted
                    onFinish={() => {
                      setCoherenceSubView("menu");
                      setActiveExerciseId(null);
                    }}
                  />
                </div>
              );
            })()}

            {coherenceSubView === "breathing" && (
              <>
                <p className="mt-4 text-[#5C3A1E] leading-relaxed">
                  Installez-vous confortablement. Inspirez 5 secondes par le nez, expirez 5 secondes par la bouche, pendant 5 minutes. Laissez le son d'ambiance vous guider dans votre rythme.
                </p>
                <div className="mt-4">
                  <p className="text-xs font-medium text-[#8B4513] mb-2">Ambiance sonore</p>
                  <div className="flex flex-wrap gap-2">
                    {([
                      { id: "drone", label: "Drone zen" },
                      { id: "waves", label: "Vagues" },
                      { id: "rain", label: "Pluie" },
                      { id: "birds", label: "Oiseaux" },
                    ] as const).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => handlePickCoherenceSound(opt.id)}
                        className={`px-3 py-1.5 text-xs rounded-full border transition-colors ${
                          coherenceSound === opt.id
                            ? "bg-sage-300 text-sage-800 border-sage-400"
                            : "bg-white/60 text-[#5C3A1E] border-sage-200 hover:bg-sage-50"
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            {coherenceSubView === "video" && (
              <div className="mt-4">
                <div className="rounded-xl overflow-hidden border border-sage-200 bg-black/5 flex items-center justify-center">
                  <video
                    ref={videoRef}
                    src={resolveAssetUrl(pauseRespirationVideo.url)}
                    controls
                    preload="metadata"
                    className="w-full h-auto max-h-[75vh] object-contain"
                    onPlay={() => setVideoPlaying(true)}
                    onPause={() => setVideoPlaying(false)}
                    onEnded={() => setVideoPlaying(false)}
                  />
                </div>
                <p className="mt-3 text-sm text-[#5C3A1E] leading-relaxed">
                  Suivez la respiration guidée par la vidéo. Installez-vous confortablement et laissez-vous porter par les mouvements visuels.
                </p>
                <p className="mt-1 text-xs text-[#A0522D]/60">
                  Conseil : pour un meilleur confort, vous pouvez activer le plein écran via le bouton du lecteur vidéo.
                </p>
              </div>
            )}


            {coherenceSubView === "cloud" && (
              <div className="mt-4">
                <BreathingCloud
                  onFinish={() => {
                    stopAmbientSound();
                    setCoherenceSubView("menu");
                    handleClose(false);
                  }}
                />
              </div>
            )}



            {coherenceSubView !== "cloud" && coherenceSubView !== "exercise-run" && (
            <div className="flex justify-end gap-3 mt-6">
              {coherenceSubView !== "menu" && (
                <Button
                  variant="outline"
                  onClick={() => {
                    stopAmbientSound();
                    if (videoRef.current) {
                      videoRef.current.pause();
                      videoRef.current.currentTime = 0;
                    }
                    setVideoPlaying(false);
                    setCoherenceSubView("menu");
                  }}
                  className="border-sage-300 text-[#8B4513] flex items-center gap-2"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Retour
                </Button>
              )}
              <Button
                variant="outline"
                onClick={() => {
                  stopAmbientSound();
                  if (videoRef.current) {
                    videoRef.current.pause();
                    videoRef.current.currentTime = 0;
                  }
                  setVideoPlaying(false);
                  setCoherenceSubView("menu");
                  setView("results");
                }}
                className="border-sage-300 text-[#8B4513]"
              >
                Résultats
              </Button>
              <Button onClick={() => handleClose(false)} className="bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300">
                Terminer
              </Button>
            </div>
            )}
          </>
        )}

        {view === "meditation" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-[#8B4513]">Méditations</DialogTitle>
              <DialogDescription className="text-[#A0522D]">
                Choisissez ce qui vous fait du bien en ce moment.
              </DialogDescription>
            </DialogHeader>

            {meditationSubView === "menu" && (
              <div className="mt-6 space-y-3">
                <button
                  onClick={() => setMeditationSubView("zen")}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
                >
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center text-sage-700 font-semibold text-xs shrink-0">
                    2 min
                  </div>
                  <div>
                    <div className="font-semibold text-[#8B4513]">Méditation zen</div>
                    <div className="text-sm text-[#5C3A1E]">Vidéo guidée</div>
                  </div>
                </button>
                <button
                  onClick={() => setMeditationSubView("balade")}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
                >
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center text-sage-700 font-semibold text-xs shrink-0">
                    4 min
                  </div>
                  <div>
                    <div className="font-semibold text-[#8B4513]">Balade méditative</div>
                    <div className="text-sm text-[#5C3A1E]">Vidéo guidée — 4 min 44</div>
                  </div>
                </button>
                <button
                  onClick={() => setMeditationSubView("bulle-douceur")}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
                >
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center text-sage-700 font-semibold text-xs shrink-0">
                    8 min
                  </div>
                  <div>
                    <div className="font-semibold text-[#8B4513]">Bulle de douceur</div>
                    <div className="text-sm text-[#5C3A1E]">Vidéo guidée — 8 min 31</div>
                  </div>
                </button>
                <button
                  onClick={() => setMeditationSubView("riviere")}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
                >
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center text-sage-700 font-semibold text-xs shrink-0">
                    13 min
                  </div>
                  <div>
                    <div className="font-semibold text-[#8B4513]">Méditation de la rivière nettoyante</div>
                    <div className="text-sm text-[#5C3A1E]">Vidéo guidée — 12 min 48</div>
                  </div>
                </button>
                <div className="flex justify-end gap-3 mt-6">
                  <Button variant="outline" onClick={() => setView("results")} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                  <Button onClick={() => handleClose(false)} className="bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300">
                    Terminer
                  </Button>
                </div>
              </div>
            )}

            {meditationSubView === "bulle-douceur" && (
              <>
                <DialogHeader>
                  <DialogTitle className="text-[#8B4513]">Bulle de douceur</DialogTitle>
                  <DialogDescription className="text-[#A0522D] flex items-center gap-2">
                    <span className="inline-flex items-center px-2 py-0.5 text-xs font-medium rounded-full bg-sage-200 text-sage-700 border border-sage-300">
                      8 min 31
                    </span>
                    Vidéo guidée
                  </DialogDescription>
                </DialogHeader>
                <div className="mt-4 rounded-xl overflow-hidden border border-sage-200 bg-black/5 flex items-center justify-center">
                  <video
                    ref={bulleDouceurVideoRef}
                    src={resolveAssetUrl(bulleDouceurVideo.url)}
                    controls
                    preload="metadata"
                    className="w-full h-auto max-h-[75vh] object-contain"
                  />
                </div>
                <p className="mt-3 text-sm text-[#5C3A1E] leading-relaxed">
                  Laissez-vous envelopper par cette bulle de douceur : une méditation guidée pour relâcher les tensions et retrouver un moment de calme.
                </p>
                <div className="flex justify-end gap-3 mt-6">
                  <Button variant="outline" onClick={() => { bulleDouceurVideoRef.current?.pause(); setMeditationSubView("menu"); }} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                  <Button onClick={() => handleClose(false)} className="bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300">
                    Terminer
                  </Button>
                </div>
              </>
            )}

            {meditationSubView === "zen" && (
              <>
                <DialogHeader>
                  <DialogTitle className="text-[#8B4513]">Méditation zen</DialogTitle>
                  <DialogDescription className="text-[#A0522D] flex items-center gap-2">
                    <span className="inline-flex items-center px-2 py-0.5 text-xs font-medium rounded-full bg-sage-200 text-sage-700 border border-sage-300">
                      2 min
                    </span>
                    Méditation
                  </DialogDescription>
                </DialogHeader>
                <div className="mt-4 rounded-xl overflow-hidden border border-sage-200 bg-black/5 flex items-center justify-center">
                  <video
                    ref={zenVideoRef}
                    src={resolveAssetUrl(meditationZenVideo.url)}
                    controls
                    preload="metadata"
                    className="w-full h-auto max-h-[75vh] object-contain"
                  />
                </div>
                <p className="mt-3 text-sm text-[#5C3A1E] leading-relaxed">
                  Installez-vous confortablement et laissez-vous porter par cette courte méditation visuelle.
                </p>
                <div className="flex justify-end gap-3 mt-6">
                  <Button variant="outline" onClick={() => setMeditationSubView("menu")} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                  <Button onClick={() => handleClose(false)} className="bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300">
                    Terminer
                  </Button>
                </div>
              </>
            )}

            {meditationSubView === "riviere" && (
              <>
                <DialogHeader>
                  <DialogTitle className="text-[#8B4513]">Méditation de la rivière nettoyante</DialogTitle>
                  <DialogDescription className="text-[#A0522D] flex items-center gap-2">
                    <span className="inline-flex items-center px-2 py-0.5 text-xs font-medium rounded-full bg-sage-200 text-sage-700 border border-sage-300">
                      12 min 48
                    </span>
                    Vidéo guidée
                  </DialogDescription>
                </DialogHeader>
                <div className="mt-4 rounded-xl overflow-hidden border border-sage-200 bg-black/5 flex items-center justify-center">
                  <video
                    ref={riviereVideoRef}
                    src={resolveAssetUrl(meditationRiviereVideo.url)}
                    controls
                    preload="metadata"
                    className="w-full h-auto max-h-[75vh] object-contain"
                  />
                </div>
                <p className="mt-3 text-sm text-[#5C3A1E] leading-relaxed">
                  Laissez le courant emporter ce qui pèse, et accueillez une sensation de clarté renouvelée.
                </p>
                <div className="flex justify-end gap-3 mt-6">
                  <Button variant="outline" onClick={() => { riviereVideoRef.current?.pause(); setMeditationSubView("menu"); }} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                  <Button onClick={() => handleClose(false)} className="bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300">
                    Terminer
                  </Button>
                </div>
              </>
            )}

            {meditationSubView === "balade" && (
              <>
                <DialogHeader>
                  <DialogTitle className="text-[#8B4513]">Balade méditative</DialogTitle>
                  <DialogDescription className="text-[#A0522D] flex items-center gap-2">
                    <span className="inline-flex items-center px-2 py-0.5 text-xs font-medium rounded-full bg-sage-200 text-sage-700 border border-sage-300">
                      4 min 44
                    </span>
                    Vidéo guidée
                  </DialogDescription>
                </DialogHeader>
                <div className="mt-4 rounded-xl overflow-hidden border border-sage-200 bg-black/5 flex items-center justify-center">
                  <video
                    ref={baladeVideoRef}
                    src={resolveAssetUrl(meditationBaladeVideo.url)}
                    controls
                    preload="metadata"
                    className="w-full h-auto max-h-[75vh] object-contain"
                  />
                </div>
                <p className="mt-3 text-sm text-[#5C3A1E] leading-relaxed">
                  Laissez-vous guider pas à pas dans une promenade apaisante au cœur du sous-bois.
                </p>
                <div className="flex justify-end gap-3 mt-6">
                  <Button variant="outline" onClick={() => { baladeVideoRef.current?.pause(); setMeditationSubView("menu"); }} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                  <Button onClick={() => handleClose(false)} className="bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300">
                    Terminer
                  </Button>
                </div>
              </>
            )}
          </>
        )}



        {view === "exercices" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-[#8B4513]">Exercices de détente</DialogTitle>
              <DialogDescription className="text-[#A0522D]">
                Prenez un moment pour vous, sans objectif.
              </DialogDescription>
            </DialogHeader>

            {exerciceSubView === "menu" && (
              <div className="mt-6 space-y-3">
                <button
                  onClick={() => setExerciceSubView("bulles-zen")}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
                >
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center text-sage-700 shrink-0">
                    <span className="text-2xl">🫧</span>
                  </div>
                  <div>
                    <div className="font-semibold text-[#8B4513]">Bulles Zen</div>
                    <div className="text-sm text-[#5C3A1E]">Éclatez les bulles au bon moment</div>
                  </div>
                </button>
                <button
                  onClick={() => setExerciceSubView("mandala")}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
                >
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center text-sage-700 shrink-0">
                    <span className="text-2xl">🌸</span>
                  </div>
                  <div>
                    <div className="font-semibold text-[#8B4513]">Mandala à colorier</div>
                    <div className="text-sm text-[#5C3A1E]">Coloriage zen — sans objectif</div>
                  </div>
                </button>
                <button
                  onClick={() => setExerciceSubView("memory")}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
                >
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center text-sage-700 shrink-0">
                    <span className="text-2xl">🃏</span>
                  </div>
                  <div>
                    <div className="font-semibold text-[#8B4513]">Memory zen</div>
                    <div className="text-sm text-[#5C3A1E]">Retrouve les paires, sans pression</div>
                  </div>
                </button>
                <button
                  onClick={() => setExerciceSubView("jardin")}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
                >
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center text-sage-700 shrink-0">
                    <span className="text-2xl">🪴</span>
                  </div>
                  <div>
                    <div className="font-semibold text-[#8B4513]">Jardin zen</div>
                    <div className="text-sm text-[#5C3A1E]">Ratisse le sable, librement</div>
                  </div>
                </button>
                <div className="flex justify-end gap-3 mt-6">
                  <Button variant="outline" onClick={() => setView("results")} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                  <Button onClick={() => handleClose(false)} className="bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300">
                    Terminer
                  </Button>
                </div>
              </div>
            )}

            {exerciceSubView === "bulles-zen" && (
              <div className="mt-4">
                <BullesZen />
                <div className="flex justify-end gap-3 mt-4">
                  <Button variant="outline" onClick={() => setExerciceSubView("menu")} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                </div>
              </div>
            )}

            {exerciceSubView === "mandala" && (
              <div className="mt-4">
                <MandalaColoriage />
                <div className="flex justify-end gap-3 mt-4">
                  <Button variant="outline" onClick={() => setExerciceSubView("menu")} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                </div>
              </div>
            )}

            {exerciceSubView === "memory" && (
              <div className="mt-4">
                <MemoryZen />
                <div className="flex justify-end gap-3 mt-4">
                  <Button variant="outline" onClick={() => setExerciceSubView("menu")} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                </div>
              </div>
            )}

            {exerciceSubView === "jardin" && (
              <div className="mt-4">
                <JardinSableZen />
                <div className="flex justify-end gap-3 mt-4">
                  <Button variant="outline" onClick={() => setExerciceSubView("menu")} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                </div>
              </div>
            )}

          </>
        )}

        {view === "sons" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-[#8B4513]">Sons</DialogTitle>
              <DialogDescription className="text-[#A0522D]">
                Fréquences et ambiances sonores.
              </DialogDescription>
            </DialogHeader>

            {sonsSubView === "menu" && (
              <div className="mt-6 space-y-3">
                <button
                  onClick={() => setSonsSubView("binaural")}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
                >
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center shrink-0">
                    <img src={BINAURAL_BRAIN_ICON} alt="" className="h-11 w-11 object-contain" />
                  </div>
                  <div>
                    <div className="font-semibold text-[#8B4513]">Sons binauraux — 8 Hz (ondes Thêta)</div>
                    <div className="text-sm text-[#5C3A1E]">À écouter au casque</div>
                  </div>
                </button>
                <button
                  onClick={() => setSonsSubView("binauralDelta")}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
                >
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center shrink-0">
                    <img src={BINAURAL_BRAIN_ICON} alt="" className="h-11 w-11 object-contain" />
                  </div>
                  <div>
                    <div className="font-semibold text-[#8B4513]">Sons binauraux — 2 Hz (ondes Delta, sommeil)</div>
                    <div className="text-sm text-[#5C3A1E]">Pour un endormissement profond, au casque</div>
                  </div>
                </button>
                <button
                  onClick={() => setSonsSubView("binauralAlpha")}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
                >
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center shrink-0">
                    <img src={BINAURAL_BRAIN_ICON} alt="" className="h-11 w-11 object-contain" />
                  </div>
                  <div>
                    <div className="font-semibold text-[#8B4513]">Sons binauraux — 10 Hz (ondes Alpha, concentration)</div>
                    <div className="text-sm text-[#5C3A1E]">Pour une concentration détendue, au casque</div>
                  </div>
                </button>
                <button
                  onClick={() => setSonsSubView("binaural963")}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/60 border border-sage-200 hover:bg-sage-50 transition-colors text-left"
                >
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center shrink-0">
                    <img src={BINAURAL_BRAIN_ICON} alt="" className="h-11 w-11 object-contain" />
                  </div>
                  <div>
                    <div className="font-semibold text-[#8B4513]">Fréquences de bien-être du cerveau — 963 Hz</div>
                    <div className="text-sm text-[#5C3A1E]">Réduisez stress et anxiété, au casque</div>
                  </div>
                </button>
                <div className="flex justify-end gap-3 mt-6">
                  <Button variant="outline" onClick={() => setView("results")} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                  <Button onClick={() => handleClose(false)} className="bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300">
                    Terminer
                  </Button>
                </div>
              </div>
            )}

            {sonsSubView === "binaural" && (
              <div className="mt-4 space-y-4">
                <div
                  className="w-full h-40 rounded-2xl bg-cover bg-center bg-no-repeat"
                  style={{ backgroundImage: `url(${BINAURAL_BANNER})` }}
                  aria-label="Bannière sons binauraux"
                  role="img"
                />
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center shrink-0">
                    <img src={BINAURAL_BRAIN_ICON} alt="" className="h-11 w-11 object-contain" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#8B4513]">Sons binauraux — 8 Hz (ondes Thêta)</h3>
                    <p className="text-xs text-[#A0522D]">À écouter au casque pour un effet optimal</p>
                  </div>
                </div>
                <p className="text-sm text-[#5C3A1E] leading-relaxed">
                  Deux fréquences légèrement différentes, une par oreille, créent une troisième onde perçue par le cerveau. Cette technique favorise la relaxation profonde et la méditation.
                </p>
                <div className="rounded-xl border border-sage-200 bg-white/60 p-4">
                  <audio
                    src={resolveAssetUrl(binauralThetaAudio.url)}
                    controls
                    preload="metadata"
                    className="w-full"
                  />
                </div>
                <div className="flex justify-end gap-3 mt-4">
                  <Button variant="outline" onClick={() => setSonsSubView("menu")} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                </div>
              </div>
            )}

            {sonsSubView === "binauralDelta" && (
              <div className="mt-4 space-y-4">
                <div
                  className="w-full h-40 rounded-2xl bg-cover bg-center bg-no-repeat"
                  style={{ backgroundImage: `url(${BINAURAL_DELTA_BANNER})` }}
                  aria-label="Bannière sons binauraux sommeil"
                  role="img"
                />
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center shrink-0">
                    <img src={BINAURAL_BRAIN_ICON} alt="" className="h-11 w-11 object-contain" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#8B4513]">Sons binauraux — 2 Hz (ondes Delta, sommeil)</h3>
                    <p className="text-xs text-[#A0522D]">Pour un endormissement profond, au casque</p>
                  </div>
                </div>
                <p className="text-sm text-[#5C3A1E] leading-relaxed">
                  Deux fréquences proches, une par oreille, génèrent une onde de 2 Hz perçue par le cerveau — la fréquence des ondes Delta, associées au sommeil profond.
                </p>
                <div className="rounded-xl border border-sage-200 bg-white/60 p-4">
                  <audio
                    src={resolveAssetUrl(binauralDeltaAudio.url)}
                    controls
                    preload="metadata"
                    className="w-full"
                  />
                </div>
                <div className="flex justify-end gap-3 mt-4">
                  <Button variant="outline" onClick={() => setSonsSubView("menu")} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                </div>
              </div>
            )}

            {sonsSubView === "binauralAlpha" && (
              <div className="mt-4 space-y-4">
                <div
                  className="w-full h-40 rounded-2xl bg-cover bg-center bg-no-repeat"
                  style={{ backgroundImage: `url(${BINAURAL_ALPHA_BANNER})` }}
                  aria-label="Bannière sons binauraux concentration"
                  role="img"
                />
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center shrink-0">
                    <img src={BINAURAL_BRAIN_ICON} alt="" className="h-11 w-11 object-contain" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#8B4513]">Sons binauraux — 10 Hz (ondes Alpha, concentration)</h3>
                    <p className="text-xs text-[#A0522D]">Pour une concentration détendue, au casque</p>
                  </div>
                </div>
                <p className="text-sm text-[#5C3A1E] leading-relaxed">
                  Deux fréquences proches, une par oreille, génèrent une onde de 10 Hz perçue par le cerveau — la fréquence des ondes Alpha, associées à un état de concentration calme et détendue.
                </p>
                <div className="rounded-xl border border-sage-200 bg-white/60 p-4">
                  <audio
                    src={resolveAssetUrl(binauralAlphaAudio.url)}
                    controls
                    preload="metadata"
                    className="w-full"
                  />
                </div>
                <div className="flex justify-end gap-3 mt-4">
                  <Button variant="outline" onClick={() => setSonsSubView("menu")} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                </div>
              </div>
            )}

            {sonsSubView === "binaural963" && (
              <div className="mt-4 space-y-4">
                <div
                  className="w-full h-40 rounded-2xl bg-cover bg-center bg-no-repeat"
                  style={{ backgroundImage: `url(${BINAURAL_963_BANNER})` }}
                  aria-label="Bannière fréquences de bien-être 963 Hz"
                  role="img"
                />
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-sage-200 flex items-center justify-center shrink-0">
                    <img src={BINAURAL_BRAIN_ICON} alt="" className="h-11 w-11 object-contain" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#8B4513]">Fréquences de bien-être du cerveau — 963 Hz</h3>
                    <p className="text-xs text-[#A0522D]">Réduisez stress et anxiété, au casque</p>
                  </div>
                </div>
                <p className="text-sm text-[#5C3A1E] leading-relaxed">
                  La fréquence 963 Hz, associée à un apaisement du mental, est ici combinée à un effet binaural de 4 Hz pour favoriser une relaxation profonde et réduire le stress et l'anxiété.
                </p>
                <div className="rounded-xl border border-sage-200 bg-white/60 p-4">
                  <audio
                    src={resolveAssetUrl(binaural963Audio.url)}
                    controls
                    preload="metadata"
                    className="w-full"
                  />
                </div>
                <div className="flex justify-end gap-3 mt-4">
                  <Button variant="outline" onClick={() => setSonsSubView("menu")} className="border-sage-300 text-[#8B4513]">
                    Retour
                  </Button>
                </div>
              </div>
            )}
          </>
        )}

                {view === "nature" && (
          <>
            <button
              type="button"
              onClick={handleStopMeditation}
              aria-label="Arrêter la méditation"
              className="absolute right-20 top-4 p-2 rounded-full text-[#8B4513] hover:bg-sage-100 transition-colors"
            >
              <Square className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={handleToggleSound}
              aria-label={soundOn ? "Couper le son" : "Activer le son"}
              className="absolute right-12 top-4 p-2 rounded-full text-[#8B4513] hover:bg-sage-100 transition-colors"
            >
              {soundOn ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </button>
            <DialogHeader>
              <DialogTitle className="text-[#8B4513]">Méditation nature</DialogTitle>
              <DialogDescription className="text-[#A0522D]">
                Choisissez votre ambiance et laissez-vous porter.
              </DialogDescription>
            </DialogHeader>
            <p className="mt-4 text-[#5C3A1E] leading-relaxed">
              Installez-vous confortablement, fermez les yeux si vous le souhaitez, et respirez doucement en vous laissant bercer par le son que vous aurez choisi.
            </p>
            <div className="mt-4 grid grid-cols-3 gap-2">
              {([
                { id: "waves", label: "Vagues" },
                { id: "rain", label: "Pluie" },
                { id: "birds", label: "Oiseaux" },
              ] as const).map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => {
                    setMeditationNature(opt.id);
                    playNatureSound(opt.id, 0.35);
                    setSoundOn(true);
                  }}
                  className={`px-3 py-2 text-sm rounded-lg border transition-colors ${
                    meditationNature === opt.id
                      ? "bg-sage-300 text-sage-800 border-sage-400"
                      : "bg-white/60 text-[#5C3A1E] border-sage-200 hover:bg-sage-50"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <Button variant="outline" onClick={() => { stopAmbientSound(); setView("results"); }} className="border-sage-300 text-[#8B4513]">
                Retour
              </Button>
              <Button onClick={() => handleClose(false)} className="bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300">
                Terminer
              </Button>
            </div>
          </>
        )}

        {view === "contact" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-[#8B4513]">Être recontacté(e)</DialogTitle>
              <DialogDescription className="text-[#A0522D]">
                Un praticien vous recontactera selon vos disponibilités.
              </DialogDescription>
            </DialogHeader>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setView("contact-sent");
              }}
              className="space-y-4 mt-4"
            >
              <div>
                <Label htmlFor="name" className="text-[#8B4513]">Nom</Label>
                <Input id="name" required value={contact.name} onChange={(e) => setContact({ ...contact, name: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="phone" className="text-[#8B4513]">Téléphone</Label>
                <Input id="phone" type="tel" required value={contact.phone} onChange={(e) => setContact({ ...contact, phone: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="slots" className="text-[#8B4513]">Créneaux de disponibilité préférés</Label>
                <Textarea id="slots" required placeholder="Ex. mardi matin, jeudi après-midi…" value={contact.slots} onChange={(e) => setContact({ ...contact, slots: e.target.value })} />
              </div>
              <div className="flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={() => setView("results")} className="border-sage-300 text-[#8B4513]">
                  Retour
                </Button>
                <Button type="submit" className="bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300">
                  Envoyer
                </Button>
              </div>
            </form>
          </>
        )}

        {view === "contact-sent" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-[#8B4513]">Demande envoyée</DialogTitle>
              <DialogDescription className="text-[#A0522D]">
                Merci {contact.name}, un praticien vous recontactera prochainement.
              </DialogDescription>
            </DialogHeader>
            <div className="flex justify-end mt-4">
              <Button onClick={() => handleClose(false)} className="bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300">
                Fermer
              </Button>
            </div>
          </>
        )}
        </div>
      </DialogContent>
    </Dialog>
    </>
  );
};