import { useEffect, useRef, useState } from "react";
import { Mic, MicOff, Send, Sparkles } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSelectExercise?: (exercise: "coherence" | "meditation" | "meditation-zen") => void;
};

export const AiSupportDialog = ({ open, onOpenChange }: Props) => {
  const [text, setText] = useState("");
  const [email, setEmail] = useState("");
  const [listening, setListening] = useState(false);
  const [supported, setSupported] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SR =
      (typeof window !== "undefined" &&
        ((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition)) ||
      null;
    if (!SR) {
      setSupported(false);
      return;
    }
    const rec = new SR();
    rec.lang = "fr-FR";
    rec.continuous = true;
    rec.interimResults = true;
    rec.onresult = (e: any) => {
      let finalText = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        finalText += e.results[i][0].transcript;
      }
      setText((prev) => (prev ? prev + " " : "") + finalText.trim());
    };
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    recognitionRef.current = rec;
    return () => {
      try {
        rec.stop();
      } catch {}
    };
  }, []);

  useEffect(() => {
    if (!open) {
      setText("");
      setEmail("");
      setSent(false);
      try {
        recognitionRef.current?.stop();
      } catch {}
      setListening(false);
    }
  }, [open]);

  const toggleMic = () => {
    if (!recognitionRef.current) return;
    if (listening) {
      recognitionRef.current.stop();
      setListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setListening(true);
      } catch {}
    }
  };

  const submit = async () => {
    const problematique = text.trim();
    const e = email.trim();
    if (!problematique || !e) {
      toast({ title: "Champs requis", description: "Merci de remplir votre ressenti et votre email.", variant: "destructive" });
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) {
      toast({ title: "Email invalide", description: "Merci de vérifier votre adresse email.", variant: "destructive" });
      return;
    }
    setSubmitting(true);
    try {
      const { error } = await supabase.functions.invoke("request-program", {
        body: { problematique, email: e },
      });
      if (error) throw error;
      setSent(true);
    } catch (err) {
      console.error(err);
      toast({ title: "Envoi impossible", description: "Veuillez réessayer dans un instant.", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#F5F0E6] border-sage-300 max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-[#8B4513] font-alice">
            <Sparkles className="w-5 h-5 text-sage-600" />
            Mon Plan Perso ✨ (gratuit)
          </DialogTitle>
          <DialogDescription className="text-[#A0522D]">
            Exprimez ce que vous ressentez, par écrit ou à la voix. Nous reviendrons vers vous avec des suggestions personnalisées.
            <br />
            <span className="text-xs opacity-80">
              Cet outil ne remplace pas un avis médical. Votre texte n'est pas enregistré et reste sur votre appareil.
            </span>
          </DialogDescription>
        </DialogHeader>

        {sent ? (
          <div className="space-y-3">
            <div className="p-4 rounded-lg border border-sage-300 bg-sage-50 text-[#5C2E0E]">
              <p className="font-medium mb-1 text-sage-700">Demande bien reçue 🌿</p>
              <p className="text-sm">Nous reviendrons vers vous sous 48h.</p>
            </div>
            <div className="flex justify-end">
              <button
                onClick={() => onOpenChange(false)}
                className="px-4 py-2 text-sm rounded-lg bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300"
              >
                Fermer
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="relative">
              <Textarea
                value={text}
                onChange={(ev) => setText(ev.target.value)}
                placeholder="Je me sens stressé(e), j'ai du mal à dormir…"
                className="min-h-[120px] bg-white/60 border-sage-300 text-[#5C2E0E] placeholder:text-[#A0522D]/50 pr-14"
                maxLength={3000}
              />
              {supported && (
                <button
                  type="button"
                  onClick={toggleMic}
                  aria-label={listening ? "Arrêter le micro" : "Activer le micro"}
                  className={`absolute top-2 right-2 p-2 rounded-full border transition-colors ${
                    listening
                      ? "bg-sage-300 border-sage-400 text-sage-800 animate-pulse"
                      : "bg-sage-100 border-sage-300 text-sage-700 hover:bg-sage-200"
                  }`}
                >
                  {listening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </button>
              )}
            </div>
            {!supported && (
              <p className="text-xs text-[#A0522D]/70">
                La saisie vocale n'est pas disponible sur ce navigateur. Vous pouvez écrire votre ressenti.
              </p>
            )}

            <div>
              <label className="block text-sm font-medium text-[#8B4513] mb-1">Votre email</label>
              <Input
                type="email"
                value={email}
                onChange={(ev) => setEmail(ev.target.value)}
                placeholder="vous@exemple.com"
                className="bg-white/60 border-sage-300 text-[#5C2E0E]"
                maxLength={255}
              />
            </div>

            <p className="text-xs text-[#A0522D]/80">
              Cet accompagnement ne se substitue pas à un avis médical.
            </p>

            <div className="flex justify-end">
              <button
                onClick={submit}
                disabled={submitting}
                className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium rounded-lg bg-sage-300 text-sage-800 hover:bg-sage-400 border border-sage-400 transition-colors disabled:opacity-60"
              >
                <Send className="w-4 h-4" />
                {submitting ? "Envoi…" : "Envoyer ma demande"}
              </button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};