import { useEffect, useRef, useState } from "react";
import { Mic, MicOff, Send, Sparkles } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSelectExercise?: (exercise: "coherence" | "meditation" | "meditation-zen") => void;
};

type Suggestion = {
  exercise: "coherence" | "meditation" | "meditation-zen";
  title: string;
  desc: string;
};

type Theme = {
  keys: string[];
  label: string;
  priority?: "practitioner";
  suggestions: Suggestion[];
};

// Mots-clés (sans accents, en minuscules pour la comparaison)
const THEMES: Theme[] = [
  {
    keys: ["stress", "anxiete", "anxieux", "angoisse", "tension mentale", "nerveux", "nerveuse", "panique", "charge mentale", "surcharge", "deborde", "debordee", "trop a gerer", "concentrer"],
    label: "Stress / Charge mentale",
    suggestions: [
      { exercise: "coherence", title: "Cohérence cardiaque (5 min)", desc: "pour apaiser rapidement les tensions du moment." },
      { exercise: "meditation", title: "Méditation guidée (10 min)", desc: "méditation relaxante." },
      { exercise: "meditation-zen", title: "Méditation zen (2 min 36)", desc: "méditation courte et apaisante." },
    ],
  },
  {
    keys: ["tensions physiques", "tension", "tendu", "tendue", "mal au dos", "mal de dos", "nuque", "epaules", "machoire", "maux de tete", "mal de tete", "mal au ventre", "courbatures", "douleurs"],
    label: "Tensions physiques",
    suggestions: [
      { exercise: "coherence", title: "Cohérence cardiaque (5 min)", desc: "pour relâcher les tensions corporelles par la respiration." },
      { exercise: "meditation", title: "Méditation guidée (10 min)", desc: "pour un relâchement plus profond du corps." },
      { exercise: "meditation-zen", title: "Méditation zen (2 min 36)", desc: "méditation courte et apaisante." },
    ],
  },
  {
    keys: ["emotion", "emotions", "emotive", "emotif", "triste", "tristesse", "colere", "en colere", "irritable", "peur", "pleurer", "pleure", "submerge", "submergee", "frustre", "frustree"],
    label: "Émotions",
    suggestions: [
      { exercise: "coherence", title: "Cohérence cardiaque (5 min)", desc: "pour calmer une émotion forte dans l'instant." },
      { exercise: "meditation", title: "Méditation guidée (10 min)", desc: "pour accueillir et apaiser ce que vous ressentez." },
      { exercise: "meditation-zen", title: "Méditation zen (2 min 36)", desc: "méditation courte et apaisante." },
    ],
  },
  {
    keys: ["sommeil", "insomnie", "dormir", "endormir", "fatigue", "fatiguee", "epuise", "epuisee", "burn-out", "burn out", "burnout", "reveille", "reveillee"],
    label: "Sommeil / Fatigue",
    suggestions: [
      { exercise: "coherence", title: "Cohérence cardiaque (5 min)", desc: "peut aider à favoriser un endormissement plus calme." },
      { exercise: "meditation", title: "Méditation guidée (10 min)", desc: "pour relâcher les tensions accumulées dans la journée." },
      { exercise: "meditation-zen", title: "Méditation zen (2 min 36)", desc: "méditation courte et apaisante." },
    ],
  },
  {
    keys: ["seul", "seule", "isolement", "isole", "isolee", "personne", "solitude", "relation", "relations", "couple", "famille", "conflit", "dispute", "amis"],
    label: "Relations / Isolement",
    suggestions: [
      { exercise: "coherence", title: "Cohérence cardiaque (5 min)", desc: "pour retrouver son calme avant d'aborder une situation relationnelle." },
      { exercise: "meditation", title: "Méditation guidée (10 min)", desc: "pour vous reconnecter à vous-même." },
      { exercise: "meditation-zen", title: "Méditation zen (2 min 36)", desc: "méditation courte et apaisante." },
    ],
  },
  {
    keys: ["deuil", "perte", "disparition", "perdu", "perdue", "mal-etre", "mal etre", "malaise", "depression", "deprime", "deprimee", "vide", "desespoir", "desespere", "desesperee"],
    label: "Deuil / Mal-être profond",
    priority: "practitioner",
    suggestions: [
      { exercise: "meditation", title: "Méditation guidée (10 min)", desc: "pour vous accorder un moment de douceur." },
      { exercise: "meditation-zen", title: "Méditation zen (2 min 36)", desc: "méditation courte et apaisante." },
    ],
  },
];

const INSULTS = [
  "con", "conne", "connard", "connasse", "salope", "salaud", "putain", "merde", "merdique",
  "enculé", "encule", "fdp", "ntm", "ta gueule", "ferme la", "idiot", "idiote", "abruti", "abrutie",
  "débile", "debile", "crétin", "cretin", "nul", "nulle", "stupide", "imbécile", "imbecile",
  "bite", "couille", "chier", "chiant", "chiante",
];

const DISTRESS_KEYWORDS = [
  "je n'en peux plus",
  "je ne vois pas d'issue",
  "envie de disparaître",
  "envie de mourir",
  "veux mourir",
  "plus envie de vivre",
  "sans issue",
  "abandonner",
  "tout lacher",
  "fini",
  "je veux en finir",
  "suicide",
  "me suicider",
  "me tuer",
  "me faire du mal",
  "ne plus exister",
];

const normalize = (s: string) =>
  s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");

const detectInsult = (text: string) => {
  const n = " " + normalize(text) + " ";
  return INSULTS.some((w) => n.includes(" " + w + " ") || n.includes(" " + w + ".") || n.includes(" " + w + ","));
};

const detectThemes = (text: string) => {
  const n = normalize(text);
  return THEMES.filter((t) => t.keys.some((k) => n.includes(normalize(k))));
};

const detectDistress = (text: string) => {
  const n = normalize(text);
  return DISTRESS_KEYWORDS.some((k) => n.includes(normalize(k)));
};

type Result =
  | { kind: "idle" }
  | { kind: "blocked" }
  | { kind: "empty" }
  | { kind: "distress" }
  | { kind: "none" }
  | { kind: "themes"; matched: typeof THEMES };

export const AiSupportDialog = ({ open, onOpenChange, onSelectExercise }: Props) => {
  const [text, setText] = useState("");
  const [listening, setListening] = useState(false);
  const [supported, setSupported] = useState(true);
  const [result, setResult] = useState<Result>({ kind: "idle" });
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SR =
      (typeof window !== "undefined" &&
        ((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition)) ||
      null;
    if (!SR) {
      setSupported(false);
      return;
    }
    const rec = new SR();
    rec.lang = "fr-FR";
    rec.continuous = true;
    rec.interimResults = true;
    rec.onresult = (e: any) => {
      let finalText = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        finalText += e.results[i][0].transcript;
      }
      setText((prev) => (prev ? prev + " " : "") + finalText.trim());
    };
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    recognitionRef.current = rec;
    return () => {
      try {
        rec.stop();
      } catch {}
    };
  }, []);

  useEffect(() => {
    if (!open) {
      setText("");
      setResult({ kind: "idle" });
      try {
        recognitionRef.current?.stop();
      } catch {}
      setListening(false);
    }
  }, [open]);

  const toggleMic = () => {
    if (!recognitionRef.current) return;
    if (listening) {
      recognitionRef.current.stop();
      setListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setListening(true);
      } catch {}
    }
  };

  const analyze = () => {
    const t = text.trim();
    if (!t) {
      setResult({ kind: "empty" });
      return;
    }
    if (detectDistress(t)) {
      setResult({ kind: "distress" });
      return;
    }
    if (detectInsult(t)) {
      setResult({ kind: "blocked" });
      return;
    }
    const matched = detectThemes(t);
    if (matched.length === 0) {
      setResult({ kind: "none" });
      return;
    }
    setResult({ kind: "themes", matched });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#F5F0E6] border-sage-300 max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-[#8B4513] font-alice">
            <Sparkles className="w-5 h-5 text-sage-600" />
            Parler à Noûs
          </DialogTitle>
          <DialogDescription className="text-[#A0522D]">
            Exprimez ce que vous ressentez, par écrit ou à la voix. Nous vous orienterons vers une méditation
            adaptée ou un de nos praticiens.
            <br />
            <span className="text-xs opacity-80">
              Cet outil ne remplace pas un avis médical. Votre texte n'est pas enregistré et reste sur votre appareil.
            </span>
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="relative">
            <Textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Je me sens stressé(e), j'ai du mal à dormir…"
              className="min-h-[120px] bg-white/60 border-sage-300 text-[#5C2E0E] placeholder:text-[#A0522D]/50 pr-14"
            />
            {supported && (
              <button
                type="button"
                onClick={toggleMic}
                aria-label={listening ? "Arrêter le micro" : "Activer le micro"}
                className={`absolute top-2 right-2 p-2 rounded-full border transition-colors ${
                  listening
                    ? "bg-sage-300 border-sage-400 text-sage-800 animate-pulse"
                    : "bg-sage-100 border-sage-300 text-sage-700 hover:bg-sage-200"
                }`}
              >
                {listening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>
            )}
          </div>
          {!supported && (
            <p className="text-xs text-[#A0522D]/70">
              La saisie vocale n'est pas disponible sur ce navigateur. Vous pouvez écrire votre ressenti.
            </p>
          )}

          <div className="flex justify-end">
            <button
              onClick={analyze}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium rounded-lg bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300 transition-colors"
            >
              <Send className="w-4 h-4" />
              Recevoir une suggestion
            </button>
          </div>

          {result.kind === "distress" && (
            <div className="p-4 rounded-lg border border-red-300/50 bg-red-50/60 text-[#5C2E0E]">
              <p className="font-medium mb-2 text-red-800">Ce que vous traversez semble difficile. 🌿</p>
              <p className="text-sm mb-3">
                Échanger avec un professionnel pourrait vous aider. Vous n'êtes pas seul(e).
              </p>
              <a
                href="#praticiens"
                onClick={() => onOpenChange(false)}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg bg-[#8B4513] text-white hover:bg-[#6B3410] transition-colors"
              >
                Être recontacté(e) par un praticien
              </a>
            </div>
          )}

          {result.kind === "blocked" && (
            <div className="p-4 rounded-lg border border-[#A0522D]/30 bg-[#A0522D]/10 text-[#5C2E0E]">
              <p className="font-medium mb-1">Cet espace est dédié au bien-être 🌿</p>
              <p className="text-sm">
                Merci de rester respectueux. Reformulez votre ressenti avec bienveillance et nous pourrons
                vous accompagner.
              </p>
            </div>
          )}

          {result.kind === "empty" && (
            <p className="text-sm text-[#A0522D]">Écrivez ou dictez quelques mots pour commencer.</p>
          )}

          {result.kind === "none" && (
            <div className="p-4 rounded-lg border border-sage-300 bg-white/60 text-[#5C2E0E]">
              <p className="text-sm">
                Nous n'avons pas identifié de thème précis. N'hésitez pas à{" "}
                <a href="#praticiens" onClick={() => onOpenChange(false)} className="underline text-sage-700">
                  contacter un de nos praticiens
                </a>{" "}
                pour un échange personnalisé.
              </p>
            </div>
          )}

          {result.kind === "themes" && (
            <div className="space-y-3">
              <p className="text-sm text-[#A0522D]">
                Nous avons identifié : <strong>{result.matched.map((m) => m.label).join(", ")}</strong>. Voici
                quelques pistes :
              </p>
              {result.matched.map((theme) => (
                <div key={theme.label} className="p-4 rounded-lg border border-sage-300 bg-white/60 space-y-3">
                  <p className="font-medium text-[#8B4513]">Pour {theme.label}</p>
                  {theme.priority === "practitioner" && (
                    <a
                      href="#praticiens"
                      onClick={() => onOpenChange(false)}
                      className="block p-3 rounded-lg border border-[#8B4513]/40 bg-[#8B4513]/10 hover:bg-[#8B4513]/15 transition-colors"
                    >
                      <p className="text-sm font-medium text-[#8B4513]">
                        Être recontacté(e) par un praticien
                      </p>
                      <p className="text-xs text-[#5C2E0E] mt-1">
                        Un échange humain peut particulièrement vous soutenir en ce moment.
                      </p>
                    </a>
                  )}
                  <div className="space-y-2">
                    {theme.suggestions.map((s) => (
                      <button
                        key={s.title}
                        type="button"
                        onClick={() => {
                          onOpenChange(false);
                          onSelectExercise?.(s.exercise);
                        }}
                        className="w-full text-left p-3 rounded-lg border border-sage-300 bg-sage-50 hover:bg-sage-100 transition-colors"
                      >
                        <span className="font-medium text-sage-700">{s.title} :</span>{" "}
                        <span className="text-sm text-[#5C2E0E]">{s.desc}</span>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              {!result.matched.some((t) => t.priority === "practitioner") && (
                <div className="p-3 rounded-lg bg-sage-100 border border-sage-300 text-sm text-[#5C2E0E]">
                  Vous préférez un accompagnement humain ?{" "}
                  <a
                    href="#praticiens"
                    onClick={() => onOpenChange(false)}
                    className="underline text-sage-700 font-medium"
                  >
                    Découvrir nos praticiens
                  </a>
                  .
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
