import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { RefreshCw, Check, Sparkles } from "lucide-react";

// ---------------------------------------------------------------------------
// MotsCaches — mini-jeu de détente (mots cachés) pour Noûs
// Autonome, sans appel API. Aucune pression : pas de minuteur, pas de score.
// ---------------------------------------------------------------------------

const WORD_BANK = [
  "CALME",
  "SERENITE",
  "RESPIRATION",
  "ANCRAGE",
  "HARMONIE",
  "DOUCEUR",
  "EQUILIBRE",
  "GRATITUDE",
  "PRESENCE",
  "BIENETRE",
  "APAISEMENT",
  "ZEN",
  "ENERGIE",
  "NATURE",
  "SILENCE",
  "COCON",
];

const GRID_SIZE = 10;
const WORDS_PER_GAME = 6;
const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

// Directions autorisées : horizontale →, verticale ↓, diagonales ↘ et ↙
// (sens normal pour la lecture, pas de mots à l'envers — pour rester accessible)
const DIRECTIONS: Array<{ dr: number; dc: number }> = [
  { dr: 0, dc: 1 }, // horizontal
  { dr: 1, dc: 0 }, // vertical
  { dr: 1, dc: 1 }, // diagonale ↘
  { dr: 1, dc: -1 }, // diagonale ↙
];

type Cell = { r: number; c: number };
type PlacedWord = { word: string; cells: Cell[] };

const cellKey = (r: number, c: number) => `${r}-${c}`;

const shuffle = <T,>(arr: T[]): T[] => {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
};

const randomLetter = () =>
  ALPHABET[Math.floor(Math.random() * ALPHABET.length)];

function buildGrid(): { grid: string[][]; placed: PlacedWord[] } {
  const candidates = shuffle(WORD_BANK).filter((w) => w.length <= GRID_SIZE);
  const grid: (string | null)[][] = Array.from({ length: GRID_SIZE }, () =>
    Array<string | null>(GRID_SIZE).fill(null),
  );
  const placed: PlacedWord[] = [];

  for (const word of candidates) {
    if (placed.length >= WORDS_PER_GAME) break;
    let success = false;
    for (let attempt = 0; attempt < 120 && !success; attempt++) {
      const dir = DIRECTIONS[Math.floor(Math.random() * DIRECTIONS.length)];
      const len = word.length;
      const minR = 0;
      const maxR = dir.dr === 0 ? GRID_SIZE - 1 : GRID_SIZE - 1 - (len - 1) * dir.dr;
      const minC = dir.dc === -1 ? len - 1 : 0;
      const maxC = dir.dc === 1 ? GRID_SIZE - len : GRID_SIZE - 1;
      if (maxR < minR || maxC < minC) continue;
      const r0 = minR + Math.floor(Math.random() * (maxR - minR + 1));
      const c0 = minC + Math.floor(Math.random() * (maxC - minC + 1));

      const cells: Cell[] = [];
      let ok = true;
      for (let i = 0; i < len; i++) {
        const r = r0 + dir.dr * i;
        const c = c0 + dir.dc * i;
        const existing = grid[r][c];
        if (existing !== null && existing !== word[i]) {
          ok = false;
          break;
        }
        cells.push({ r, c });
      }
      if (!ok) continue;
      cells.forEach(({ r, c }, i) => {
        grid[r][c] = word[i];
      });
      placed.push({ word, cells });
      success = true;
    }
  }

  // Remplir les cases vides
  const finalGrid: string[][] = grid.map((row) =>
    row.map((ch) => ch ?? randomLetter()),
  );
  return { grid: finalGrid, placed };
}

function cellsInLine(from: Cell, to: Cell): Cell[] | null {
  const dr = to.r - from.r;
  const dc = to.c - from.c;
  if (dr === 0 && dc === 0) return [from];
  const stepR = dr === 0 ? 0 : dr > 0 ? 1 : -1;
  const stepC = dc === 0 ? 0 : dc > 0 ? 1 : -1;
  // doit être horizontal, vertical ou diagonal pur
  if (dr !== 0 && dc !== 0 && Math.abs(dr) !== Math.abs(dc)) return null;
  const len = Math.max(Math.abs(dr), Math.abs(dc)) + 1;
  const cells: Cell[] = [];
  for (let i = 0; i < len; i++) {
    cells.push({ r: from.r + stepR * i, c: from.c + stepC * i });
  }
  return cells;
}

export const MotsCaches = () => {
  const [game, setGame] = useState(() => buildGrid());
  const [found, setFound] = useState<Set<string>>(new Set());
  const [foundCells, setFoundCells] = useState<Set<string>>(new Set());
  const [start, setStart] = useState<Cell | null>(null);
  const [hover, setHover] = useState<Cell | null>(null);
  const [flash, setFlash] = useState<"ok" | "no" | null>(null);
  const isPointerDown = useRef(false);
  const lastPointerType = useRef<string>("");

  const reset = useCallback(() => {
    setGame(buildGrid());
    setFound(new Set());
    setFoundCells(new Set());
    setStart(null);
    setHover(null);
    setFlash(null);
  }, []);

  const selection = useMemo<Cell[]>(() => {
    if (!start || !hover) return [];
    return cellsInLine(start, hover) ?? [start];
  }, [start, hover]);

  const selectionSet = useMemo(
    () => new Set(selection.map((c) => cellKey(c.r, c.c))),
    [selection],
  );

  const resolveSelection = useCallback((from: Cell | null, to: Cell | null) => {
    if (!from || !to) {
      setStart(null);
      setHover(null);
      return;
    }
    const cells = cellsInLine(from, to);
    setStart(null);
    setHover(null);
    if (!cells || cells.length < 3) return;
    const word = cells.map(({ r, c }) => game.grid[r][c]).join("");
    const match = game.placed.find(
      (p) =>
        !found.has(p.word) &&
        p.cells.length === cells.length &&
        p.cells.every((pc, i) => pc.r === cells[i].r && pc.c === cells[i].c),
    );
    if (match || game.placed.some((p) => p.word === word && !found.has(word))) {
      const matched = match?.word ?? word;
      setFound((prev) => new Set(prev).add(matched));
      setFoundCells((prev) => {
        const next = new Set(prev);
        cells.forEach((c) => next.add(cellKey(c.r, c.c)));
        return next;
      });
      setFlash("ok");
      setTimeout(() => setFlash(null), 500);
    } else {
      setFlash("no");
      setTimeout(() => setFlash(null), 400);
    }
  }, [game, found]);

  const completeSelection = useCallback(() => {
    resolveSelection(start, hover);
  }, [resolveSelection, start, hover]);

  useEffect(() => {
    const up = () => {
      if (isPointerDown.current) {
        isPointerDown.current = false;
        completeSelection();
      }
    };
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    return () => {
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
  }, [completeSelection]);

  const allFound = found.size === game.placed.length;

  const handleCellEnterFromTouch = (e: React.PointerEvent) => {
    if (e.pointerType === "touch") return;
    if (!isPointerDown.current) return;
    const { width, height } = e.currentTarget.getBoundingClientRect();
    if (Math.abs(e.movementY) > Math.abs(e.movementX) || Math.abs(e.movementY) > Math.min(width, height) * 0.6) {
      isPointerDown.current = false;
      setStart(null);
      setHover(null);
      return;
    }
    const target = document.elementFromPoint(e.clientX, e.clientY) as HTMLElement | null;
    if (!target) return;
    const r = target.getAttribute?.("data-row");
    const c = target.getAttribute?.("data-col");
    if (r !== null && r !== undefined && c !== null && c !== undefined) {
      setHover({ r: Number(r), c: Number(c) });
    }
  };

  return (
    <div className="w-full touch-pan-y" style={{ touchAction: "pan-y" }}>
      <div className="text-center mb-4">
        <h3 className="font-['Alice'] text-2xl text-[#8B4513]">Mots cachés</h3>
        <p className="text-sm text-[#5C3A1E] mt-1">
          Retrouve, en douceur, les mots du calme dans la grille.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-[1fr_auto] items-start">
        {/* Grille */}
        <div
          className={`mx-auto touch-pan-y select-none rounded-2xl p-2 sm:p-3 bg-[#FBF6EC] border border-sage-200 shadow-sm transition-shadow ${
            flash === "ok" ? "shadow-[0_0_0_3px_rgba(137,161,137,0.45)]" : ""
          } ${flash === "no" ? "shadow-[0_0_0_3px_rgba(160,82,45,0.25)]" : ""}`}
          style={{ WebkitUserSelect: "none", touchAction: "pan-y" }}
        >
          <div
            className="grid touch-pan-y"
            style={{
              gridTemplateColumns: `repeat(${GRID_SIZE}, minmax(0, 1fr))`,
              gap: "6px",
              touchAction: "pan-y",
            }}
          >
            {game.grid.map((row, r) =>
              row.map((letter, c) => {
                const key = cellKey(r, c);
                const isFound = foundCells.has(key);
                const isSelected = selectionSet.has(key);
                return (
                  <button
                    key={key}
                    data-row={r}
                    data-col={c}
                    type="button"
                    onPointerDown={(e) => {
                      lastPointerType.current = e.pointerType;
                      if (e.pointerType === "touch") return;
                      isPointerDown.current = true;
                      setStart({ r, c });
                      setHover({ r, c });
                    }}
                    onPointerEnter={(e) => {
                      if (e.pointerType === "touch") return;
                      if (isPointerDown.current) setHover({ r, c });
                    }}
                    onPointerMove={handleCellEnterFromTouch}
                    onClick={() => {
                      if (lastPointerType.current !== "touch") return;
                      const cell = { r, c };
                      if (!start) {
                        setStart(cell);
                        setHover(cell);
                        return;
                      }
                      resolveSelection(start, cell);
                    }}
                    className={[
                      "aspect-square touch-pan-y flex items-center justify-center rounded-md font-semibold transition-colors",
                      "text-sm sm:text-base md:text-lg",
                      isFound
                        ? "bg-sage-300 text-sage-800"
                        : isSelected
                          ? "bg-sage-200 text-sage-800"
                          : "bg-white/80 text-[#5C3A1E] hover:bg-sage-50",
                    ].join(" ")}
                    style={{ touchAction: "pan-y" }}
                    aria-label={`Lettre ${letter}, ligne ${r + 1}, colonne ${c + 1}`}
                  >
                    {letter}
                  </button>
                );
              }),
            )}
          </div>
        </div>

        {/* Liste des mots */}
        <div className="md:w-56">
          <div className="rounded-2xl p-4 bg-white/70 border border-sage-200">
            <div className="text-sm font-semibold text-[#8B4513] mb-2 font-['Alice']">
              À trouver
            </div>
            <ul className="grid grid-cols-2 md:grid-cols-1 gap-1.5">
              {game.placed.map((p) => {
                const done = found.has(p.word);
                return (
                  <li
                    key={p.word}
                    className={`flex items-center gap-2 text-sm px-2 py-1 rounded-md transition-colors ${
                      done
                        ? "bg-sage-100 text-sage-700 line-through"
                        : "text-[#5C3A1E]"
                    }`}
                  >
                    <span
                      className={`inline-flex items-center justify-center w-4 h-4 rounded-full border ${
                        done
                          ? "bg-sage-300 border-sage-400 text-white"
                          : "border-sage-300"
                      }`}
                    >
                      {done && <Check className="w-3 h-3" />}
                    </span>
                    <span className="tracking-wide">{p.word}</span>
                  </li>
                );
              })}
            </ul>
          </div>

          <button
            onClick={reset}
            className="mt-3 w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            Nouvelle grille
          </button>
        </div>
      </div>

      {/* Message de fin bienveillant */}
      {allFound && (
        <div className="mt-6 relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#FBF6EC] to-sage-100 border border-sage-200 p-6 text-center animate-fadeIn">
          <div className="flex justify-center mb-3">
            <div
              className="relative w-20 h-12 bg-white rounded-full shadow-inner animate-[breathe_5s_ease-in-out_infinite]"
              aria-hidden
            >
              <span className="absolute -left-3 top-1 w-10 h-10 bg-white rounded-full" />
              <span className="absolute -right-2 top-0 w-12 h-12 bg-white rounded-full" />
              <span className="absolute left-4 -top-3 w-12 h-12 bg-white rounded-full" />
            </div>
          </div>
          <div className="inline-flex items-center gap-2 text-sage-700">
            <Sparkles className="w-4 h-4" />
            <span className="font-['Alice'] text-xl text-[#8B4513]">
              Bravo, tu as trouvé un moment de calme
            </span>
            <Sparkles className="w-4 h-4" />
          </div>
          <p className="text-sm text-[#5C3A1E] mt-2">
            Respire profondément… et savoure cette petite victoire intérieure.
          </p>
        </div>
      )}
    </div>
  );
};

export default MotsCaches;