import { useState } from "react";
import { StressAssessment } from "@/components/stress-assessment";
import { AiSupportDialog } from "@/components/ai-support-dialog";

export const HeroSection = () => {
  const [open, setOpen] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [exerciseTarget, setExerciseTarget] = useState<"coherence" | "meditation" | "meditation-zen" | "exercices" | null>(null);
  return (
    <section className="relative overflow-hidden bg-[#F5F0E6]">
      <div className="container px-4 py-24 mx-auto sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <span className="inline-block px-4 py-1.5 mb-4 text-sm font-medium rounded-full bg-sage-200 text-sage-700 border border-sage-300">
            Agréé services à la personne
          </span>
          <div className="mb-8">
            <img 
              src="/lovable-uploads/88749433-04e9-4c75-933c-2d56236e6779.png"
              alt="Noûs Logo et Tagline" 
              className="h-48 w-auto mx-auto"
            />
          </div>
          <div className="mb-8">
            <img 
              src="/lovable-uploads/1919c5e1-b704-4470-9256-3863b6b72f49.png"
              alt="Noûs Services Logo" 
              className="h-48 w-auto mx-auto animate-[breathe_5s_ease-in-out_infinite]"
            />
            <div className="relative mt-4 h-6 text-center">
              <span className="absolute inset-0 text-sm tracking-widest text-sage-600 animate-[inhaleText_5s_ease-in-out_infinite]">
                Inspirez…
              </span>
              <span className="absolute inset-0 text-sm tracking-widest text-sage-600 animate-[exhaleText_5s_ease-in-out_infinite]">
                Expirez…
              </span>
            </div>
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            <button
              onClick={() => setOpen(true)}
              className="px-6 py-3 text-sm font-medium transition-colors rounded-lg bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300"
            >
              Évaluer mon stress
            </button>
            <button
              onClick={() => setAiOpen(true)}
              className="px-6 py-3 text-sm font-medium transition-colors rounded-lg bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300"
            >
              Parler à Noûs
            </button>
          </div>
        </div>
      </div>
      <StressAssessment
        open={open}
        onOpenChange={(o) => {
          setOpen(o);
          if (!o) setExerciseTarget(null);
        }}
        targetView={exerciseTarget}
      />
      <AiSupportDialog
        open={aiOpen}
        onOpenChange={setAiOpen}
        onSelectExercise={(ex) => {
          setExerciseTarget(ex);
          setOpen(true);
        }}
      />
    </section>
  );
};

