import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation, Navigate } from "react-router-dom";

import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { CookieBanner } from "@/components/cookie-banner";
import Index from "./pages/Index";
import FAQ from "./pages/FAQ";
import MentionsLegales from "./pages/MentionsLegales";
import PolitiqueConfidentialite from "./pages/PolitiqueConfidentialite";
import PaiementConfirmation from "./pages/PaiementConfirmation";
import Unsubscribe from "./pages/Unsubscribe";
import Exercices from "./pages/Exercices";
import Blog from "./pages/Blog";
import BlogArticle from "./pages/BlogArticle";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const RedirectOrNotFound = () => {
  const { pathname } = useLocation();
  const normalized = pathname.toLowerCase();
  const target = "/politique-confidentialite";

  if (
    normalized !== target &&
    (normalized.includes("politique-de-confidentialite") ||
      normalized.includes("privacy-policy") ||
      normalized.includes("confidentialite"))
  ) {
    return <Navigate to={target} replace />;
  }

  return <NotFound />;
};


const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/mentions-legales" element={<MentionsLegales />} />
          <Route path="/politique-confidentialite" element={<PolitiqueConfidentialite />} />
          <Route path="/paiement-confirmation" element={<PaiementConfirmation />} />
          <Route path="/unsubscribe" element={<Unsubscribe />} />
          <Route path="/exercices" element={<Exercices />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogArticle />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<RedirectOrNotFound />} />
        </Routes>
        <Footer />
        <CookieBanner />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
