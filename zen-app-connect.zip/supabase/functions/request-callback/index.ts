import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";

const PRATICIENS: Record<string, { email: string; firstName: string }> = {
  "sophie clouet": { email: "contact@philo-sophie.fr", firstName: "Sophie" },
  "laurence giudicelli": { email: "laurencegiudicelli08@gmail.com", firstName: "Laurence" },
  "nathalie garnier": { email: "nathaliebazingarnier@gmail.com", firstName: "Nathalie" },
  "camille chopinot": { email: "camillechopinot@naturohygieniste.fr", firstName: "Camille" },
};

const MOMENT_LABELS: Record<string, string> = {
  morning: "Matin",
  afternoon: "Après-midi",
  evening: "Soir",
};
const DAY_LABELS: Record<string, string> = {
  mon: "Lundi", tue: "Mardi", wed: "Mercredi", thu: "Jeudi",
  fri: "Vendredi", sat: "Samedi", sun: "Dimanche",
};

function escapeHtml(s: unknown): string {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405, headers: corsHeaders });
  }

  try {
    const { praticienName, firstName, lastName, phone, email, moments, days, dateTime } = await req.json();

    if (!praticienName || !firstName || !lastName || !phone || !email) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const key = String(praticienName).trim().toLowerCase();
    const praticien = PRATICIENS[key];

    if (!praticien) {
      // Praticien email not yet configured (e.g. Clara Regnier, Océane Danjon)
      console.log("No email configured for praticien:", praticienName);
      return new Response(JSON.stringify({ ok: true, notified: false }), {
        status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const preferredMoments = Array.isArray(moments)
      ? moments.map((m: string) => MOMENT_LABELS[m] ?? m).join(", ")
      : "";
    const preferredDays = Array.isArray(days)
      ? days.map((d: string) => DAY_LABELS[d] ?? d).join(", ")
      : "";

    const idempotencyKey = `callback-${key.replace(/\s+/g, "-")}-${phone}-${Date.now()}`;

    // Notify Noûs admin via Resend
    await notifyAdmin({
      subject: `Nouvelle demande de RDV — ${firstName} ${lastName}`,
      lines: [
        `Praticien demandé : ${praticienName}`,
        `Client : ${firstName} ${lastName}`,
        `Téléphone : ${phone}`,
        `Email : ${email}`,
        preferredDays ? `Jours préférés : ${preferredDays}` : "",
        preferredMoments ? `Moments préférés : ${preferredMoments}` : "",
        dateTime ? `Date/heure : ${dateTime}` : "",
      ].filter(Boolean),
    });

    // Send confirmation email to the client
    await sendClientConfirmation({
      to: email,
      firstName,
      praticienName,
      preferredDays,
      preferredMoments,
      dateTime,
    });

    const { error } = await supabase.functions.invoke("send-transactional-email", {
      body: {
        templateName: "callback-request-praticien",
        recipientEmail: praticien.email,
        idempotencyKey,
        templateData: {
          praticienName: praticien.firstName,
          clientFirstName: firstName,
          clientLastName: lastName,
          clientPhone: phone,
          preferredMoments,
          preferredDays,
        },
      },
    });

    if (error) {
      console.error("send-transactional-email error:", error);
      return new Response(JSON.stringify({ error: "Failed to send email" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ ok: true, notified: true }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("request-callback error:", e);
    return new Response(JSON.stringify({ error: "Une erreur est survenue." }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

async function notifyAdmin({ subject, lines }: { subject: string; lines: string[] }) {
  const apiKey = Deno.env.get("RESEND_API_KEY");
  if (!apiKey) {
    console.error("RESEND_API_KEY not set, skipping admin notification");
    return;
  }
  try {
    const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#111;line-height:1.6">
      <h2 style="margin:0 0 12px">${escapeHtml(subject)}</h2>
      ${lines.map((l) => `<p style="margin:4px 0">${escapeHtml(l)}</p>`).join("")}
    </div>`;
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        from: "Noûs <noreply@app-nous.fr>",
        to: ["contact.neovie@gmail.com"],
        subject,
        html,
      }),
    });
    if (!res.ok) console.error("Resend admin notify failed:", res.status, await res.text());
  } catch (e) {
    console.error("Resend admin notify error:", e);
  }
}

async function sendClientConfirmation({
  to, firstName, praticienName, preferredDays, preferredMoments, dateTime,
}: {
  to: string; firstName: string; praticienName: string;
  preferredDays: string; preferredMoments: string; dateTime?: string;
}) {
  const apiKey = Deno.env.get("RESEND_API_KEY");
  if (!apiKey) {
    console.error("RESEND_API_KEY not set, skipping client confirmation");
    return;
  }
  try {
    const details: string[] = [
      `<p style="margin:6px 0"><strong>Praticien :</strong> ${escapeHtml(praticienName)}</p>`,
    ];
    if (preferredDays) details.push(`<p style="margin:6px 0"><strong>Jours préférés :</strong> ${escapeHtml(preferredDays)}</p>`);
    if (preferredMoments) details.push(`<p style="margin:6px 0"><strong>Moments préférés :</strong> ${escapeHtml(preferredMoments)}</p>`);
    if (dateTime) details.push(`<p style="margin:6px 0"><strong>Date/heure :</strong> ${escapeHtml(dateTime)}</p>`);

    const html = `<div style="font-family:Georgia,'Times New Roman',serif;background:#F5F0E6;padding:32px;color:#5C4033">
      <div style="max-width:560px;margin:0 auto;background:#ffffff;border-radius:12px;padding:32px;border:1px solid #E3E9E3">
        <h2 style="margin:0 0 16px;color:#8B4513;font-weight:normal">Bonjour ${escapeHtml(firstName)},</h2>
        <p style="margin:0 0 12px;line-height:1.6">Merci pour votre demande de rappel auprès de Noûs.</p>
        <p style="margin:0 0 12px;line-height:1.6">Nous avons bien reçu votre demande et vous recontacterons très prochainement afin de convenir d'un rendez-vous.</p>
        <div style="margin:20px 0;padding:16px;background:#F5F0E6;border-radius:8px;font-family:Arial,sans-serif;font-size:14px;color:#5C4033">
          <p style="margin:0 0 8px;font-weight:bold;color:#8B4513">Récapitulatif de votre demande</p>
          ${details.join("")}
        </div>
        <p style="margin:16px 0 0;line-height:1.6">À très bientôt,<br/>L'équipe Noûs</p>
        <p style="margin:24px 0 0;font-size:12px;color:#A0522D">Agréé Services à la Personne</p>
      </div>
    </div>`;

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        from: "Noûs <noreply@app-nous.fr>",
        to: [to],
        subject: "Votre demande de rappel a bien été reçue — Noûs",
        html,
      }),
    });
    if (!res.ok) console.error("Resend client confirm failed:", res.status, await res.text());
  } catch (e) {
    console.error("Resend client confirm error:", e);
  }
}