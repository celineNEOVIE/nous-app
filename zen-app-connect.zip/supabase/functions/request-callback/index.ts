import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import * as React from "npm:react@18.3.1";
import { render } from "npm:@react-email/render@0.0.17";
import { template as callbackPraticienTemplate } from "../_shared/transactional-email-templates/callback-request-praticien.tsx";

const PRATICIENS: Record<string, { email: string; firstName: string }> = {
  "sophie clouet": { email: "contact@philo-sophie.fr", firstName: "Sophie" },
  "laurence giudicelli": { email: "laurencegiudicelli08@gmail.com", firstName: "Laurence" },
  "nathalie garnier": { email: "nathaliebazingarnier@gmail.com", firstName: "Nathalie" },
  "camille chopinot": { email: "camillechopinot@naturohygieniste.fr", firstName: "Camille" },
  "océane danjon": { email: "oceanedanjon06@gmail.com", firstName: "Océane" },
  "clara regnier": { email: "justeuninstantpoursoi@gmail.com", firstName: "Clara" },
};

const MOMENT_LABELS: Record<string, string> = {
  morning: "Matin",
  afternoon: "Après-midi",
  evening: "Soir",
};
const DAY_LABELS: Record<string, string> = {
  mon: "Lundi", tue: "Mardi", wed: "Mercredi", thu: "Jeudi",
  fri: "Vendredi", sat: "Samedi", sun: "Dimanche",
};

function escapeHtml(s: unknown): string {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405, headers: corsHeaders });
  }

  try {
    const { praticienName, firstName, lastName, phone, email, moments, days, dateTime } = await req.json();

    if (!praticienName || !firstName || !lastName || !phone || !email) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const key = String(praticienName).trim().toLowerCase();
    const praticien = PRATICIENS[key];

    if (!praticien) {
      console.log("No email configured for praticien:", praticienName);
    }

    const preferredMoments = Array.isArray(moments)
      ? moments.map((m: string) => MOMENT_LABELS[m] ?? m).join(", ")
      : "";
    const preferredDays = Array.isArray(days)
      ? days.map((d: string) => DAY_LABELS[d] ?? d).join(", ")
      : "";

    // Run all 3 sends independently; a failure on one must never block the others.
    const [adminResult, clientResult, praticienResult] = await Promise.allSettled([
      notifyAdmin({
        subject: `Nouvelle demande de RDV — ${firstName} ${lastName}`,
        lines: [
          `Praticien demandé : ${praticienName}`,
          `Client : ${firstName} ${lastName}`,
          `Téléphone : ${phone}`,
          `Email : ${email}`,
          preferredDays ? `Jours préférés : ${preferredDays}` : "",
          preferredMoments ? `Moments préférés : ${preferredMoments}` : "",
          dateTime ? `Date/heure : ${dateTime}` : "",
        ].filter(Boolean),
      }),
      sendClientConfirmation({
        to: email,
        firstName,
        praticienName,
        preferredDays,
        preferredMoments,
        dateTime,
      }),
      praticien
        ? notifyPraticien({
            to: praticien.email,
            praticienFirstName: praticien.firstName,
            clientFirstName: firstName,
            clientLastName: lastName,
            clientPhone: phone,
            preferredMoments,
            preferredDays,
          })
        : Promise.resolve({ ok: true, skipped: true } as const),
    ]);

    const adminOk = adminResult.status === "fulfilled" && adminResult.value?.ok !== false;
    const clientOk = clientResult.status === "fulfilled" && clientResult.value?.ok !== false;
    const praticienOk = praticienResult.status === "fulfilled" && praticienResult.value?.ok !== false;

    if (!adminOk) console.error("request-callback: admin notify failed", adminResult);
    if (!clientOk) console.error("request-callback: client confirmation failed", clientResult);
    if (!praticienOk) console.error("request-callback: praticien notify failed", praticienResult);

    // Client-facing status: succeed as long as the client's own confirmation email was sent.
    if (!clientOk) {
      return new Response(
        JSON.stringify({ error: "Client confirmation failed", adminOk, praticienOk }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    return new Response(
      JSON.stringify({ ok: true, adminOk, clientOk, praticienOk }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (e) {
    console.error("request-callback error:", e);
    return new Response(JSON.stringify({ error: "Une erreur est survenue." }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

async function notifyAdmin({ subject, lines }: { subject: string; lines: string[] }): Promise<{ ok: boolean }> {
  const apiKey = Deno.env.get("RESEND_API_KEY");
  if (!apiKey) {
    console.error("RESEND_API_KEY not set, skipping admin notification");
    return { ok: false };
  }
  try {
    const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#111;line-height:1.6">
      <h2 style="margin:0 0 12px">${escapeHtml(subject)}</h2>
      ${lines.map((l) => `<p style="margin:4px 0">${escapeHtml(l)}</p>`).join("")}
    </div>`;
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        from: "Noûs <noreply@app-nous.fr>",
        to: ["contact.neovie@gmail.com"],
        subject,
        html,
      }),
    });
    if (!res.ok) {
      console.error("Resend admin notify failed:", res.status, await res.text());
      return { ok: false };
    }
    return { ok: true };
  } catch (e) {
    console.error("Resend admin notify error:", e);
    return { ok: false };
  }
}

async function sendClientConfirmation({
  to, firstName, praticienName, preferredDays, preferredMoments, dateTime,
}: {
  to: string; firstName: string; praticienName: string;
  preferredDays: string; preferredMoments: string; dateTime?: string;
}): Promise<{ ok: boolean }> {
  const apiKey = Deno.env.get("RESEND_API_KEY");
  if (!apiKey) {
    console.error("RESEND_API_KEY not set, skipping client confirmation");
    return { ok: false };
  }
  try {
    const details: string[] = [
      `<p style="margin:6px 0"><strong>Praticien :</strong> ${escapeHtml(praticienName)}</p>`,
    ];
    if (preferredDays) details.push(`<p style="margin:6px 0"><strong>Jours préférés :</strong> ${escapeHtml(preferredDays)}</p>`);
    if (preferredMoments) details.push(`<p style="margin:6px 0"><strong>Moments préférés :</strong> ${escapeHtml(preferredMoments)}</p>`);
    if (dateTime) details.push(`<p style="margin:6px 0"><strong>Date/heure :</strong> ${escapeHtml(dateTime)}</p>`);

    const html = `<div style="font-family:Georgia,'Times New Roman',serif;background:#F5F0E6;padding:32px;color:#5C4033">
      <div style="max-width:560px;margin:0 auto;background:#ffffff;border-radius:12px;padding:32px;border:1px solid #E3E9E3">
        <h2 style="margin:0 0 16px;color:#8B4513;font-weight:normal">Bonjour ${escapeHtml(firstName)},</h2>
        <p style="margin:0 0 12px;line-height:1.6">Merci pour votre demande de rappel auprès de Noûs.</p>
        <p style="margin:0 0 12px;line-height:1.6">Nous avons bien reçu votre demande et vous recontacterons très prochainement afin de convenir d'un rendez-vous.</p>
        <div style="margin:20px 0;padding:16px;background:#F5F0E6;border-radius:8px;font-family:Arial,sans-serif;font-size:14px;color:#5C4033">
          <p style="margin:0 0 8px;font-weight:bold;color:#8B4513">Récapitulatif de votre demande</p>
          ${details.join("")}
        </div>
        <p style="margin:16px 0 0;line-height:1.6">À très bientôt,<br/>L'équipe Noûs</p>
        <p style="margin:24px 0 0;font-size:12px;color:#A0522D">Agréé Services à la Personne</p>
      </div>
    </div>`;

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        from: "Noûs <noreply@app-nous.fr>",
        to: [to],
        subject: "Votre demande de rappel a bien été reçue — Noûs",
        html,
      }),
    });
    if (!res.ok) {
      console.error("Resend client confirm failed:", res.status, await res.text());
      return { ok: false };
    }
    return { ok: true };
  } catch (e) {
    console.error("Resend client confirm error:", e);
    return { ok: false };
  }
}

async function notifyPraticien({
  to, praticienFirstName, clientFirstName, clientLastName, clientPhone, preferredMoments, preferredDays,
}: {
  to: string; praticienFirstName: string; clientFirstName: string; clientLastName: string;
  clientPhone: string; preferredMoments: string; preferredDays: string;
}): Promise<{ ok: boolean }> {
  const apiKey = Deno.env.get("RESEND_API_KEY");
  if (!apiKey) {
    console.error("RESEND_API_KEY not set, skipping praticien notification");
    return { ok: false };
  }
  try {
    const subject = typeof callbackPraticienTemplate.subject === "function"
      ? callbackPraticienTemplate.subject({ praticienName: praticienFirstName })
      : callbackPraticienTemplate.subject;

    const html = await render(
      React.createElement(callbackPraticienTemplate.component, {
        praticienName: praticienFirstName,
        clientFirstName,
        clientLastName,
        clientPhone,
        preferredMoments,
        preferredDays,
      }),
    );

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        from: "Noûs <noreply@app-nous.fr>",
        to: [to],
        subject,
        html,
      }),
    });
    if (!res.ok) {
      console.error("Resend praticien notify failed:", res.status, await res.text());
      return { ok: false };
    }
    return { ok: true };
  } catch (e) {
    console.error("Resend praticien notify error:", e);
    return { ok: false };
  }
}