import { createClient } from "npm:@supabase/supabase-js@2";
import { type StripeEnv, createStripeClient, verifyWebhook } from "../_shared/stripe.ts";

const PRATICIENS: Record<string, { name: string; email: string }> = {
  sophie: { name: "Sophie Clouet", email: "contact@philo-sophie.fr" },
  laurence: { name: "Laurence Giudicelli", email: "laurencegiudicelli08@gmail.com" },
};

function resolvePraticien(lookupKey: string | null | undefined) {
  if (lookupKey?.startsWith("sophie_")) return PRATICIENS.sophie;
  return PRATICIENS.laurence;
}

function formatAmount(amount: number | null | undefined, currency: string) {
  if (amount == null) return "";
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: currency.toUpperCase() }).format(amount / 100);
}

function escapeHtml(s: unknown): string {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

let _supabase: ReturnType<typeof createClient> | null = null;
function getSupabase() {
  if (!_supabase) {
    _supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );
  }
  return _supabase;
}

async function sendEmail(templateName: string, recipientEmail: string, idempotencyKey: string, templateData: Record<string, unknown>) {
  const { error } = await getSupabase().functions.invoke("send-transactional-email", {
    body: { templateName, recipientEmail, idempotencyKey, templateData },
  });
  if (error) console.error(`send-transactional-email ${templateName} -> ${recipientEmail}:`, error);
}

async function handleCheckoutCompleted(sessionObj: any, env: StripeEnv) {
  const stripe = createStripeClient(env);
  const session = await stripe.checkout.sessions.retrieve(sessionObj.id, {
    expand: ["line_items", "line_items.data.price.product"],
  });

  const item = session.line_items?.data?.[0];
  const price: any = item?.price;
  const lookupKey: string | undefined = price?.lookup_key;
  const product: any = price?.product;
  const sessionTitle: string = (typeof product === "object" && product?.name) || "Séance";

  const praticien = resolvePraticien(lookupKey);

  const clientEmail = session.customer_details?.email || session.customer_email;
  const clientName = session.customer_details?.name || undefined;
  const amount = formatAmount(session.amount_total, session.currency || "eur");

  if (!clientEmail) {
    console.error("No client email on session", session.id);
    return;
  }

  await Promise.all([
    sendEmail(
      "payment-confirmation-client",
      clientEmail,
      `stripe-${session.id}-client`,
      { clientName, praticienName: praticien.name, sessionTitle, amount },
    ),
    sendEmail(
      "payment-notification-praticien",
      praticien.email,
      `stripe-${session.id}-praticien`,
      {
        praticienName: praticien.name,
        clientName: clientName || "Client",
        clientEmail,
        sessionTitle,
        amount,
      },
    ),
    notifyAdmin({
      subject: `Paiement reçu — ${clientName || clientEmail}`,
      lines: [
        `Praticien : ${praticien.name}`,
        `Séance : ${sessionTitle}`,
        `Client : ${clientName || "—"}`,
        `Email client : ${clientEmail}`,
        session.customer_details?.phone ? `Téléphone : ${session.customer_details.phone}` : "",
        amount ? `Montant : ${amount}` : "",
      ].filter(Boolean),
    }),
  ]);
}

async function notifyAdmin({ subject, lines }: { subject: string; lines: string[] }) {
  const apiKey = Deno.env.get("RESEND_API_KEY");
  if (!apiKey) {
    console.error("RESEND_API_KEY not set, skipping admin notification");
    return;
  }
  try {
    const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#111;line-height:1.6">
      <h2 style="margin:0 0 12px">${escapeHtml(subject)}</h2>
      ${lines.map((l) => `<p style="margin:4px 0">${escapeHtml(l)}</p>`).join("")}
    </div>`;
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        from: "Noûs <noreply@app-nous.fr>",
        to: ["contact.neovie@gmail.com"],
        subject,
        html,
      }),
    });
    if (!res.ok) console.error("Resend admin notify failed:", res.status, await res.text());
  } catch (e) {
    console.error("Resend admin notify error:", e);
  }
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const rawEnv = new URL(req.url).searchParams.get("env");
  if (rawEnv !== "sandbox" && rawEnv !== "live") {
    console.error("Invalid env query param:", rawEnv);
    return new Response(JSON.stringify({ received: true, ignored: "invalid env" }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  }
  const env: StripeEnv = rawEnv;

  try {
    const event = await verifyWebhook(req, env);
    if (event.type === "checkout.session.completed") {
      await handleCheckoutCompleted(event.data.object, env);
    } else {
      console.log("Unhandled event:", event.type);
    }
    return new Response(JSON.stringify({ received: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("stripe-webhook error:", e);
    return new Response("Webhook error", { status: 400 });
  }
});