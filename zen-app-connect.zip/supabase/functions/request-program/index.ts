import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";

const ADMIN_EMAIL = "contactneovie@gmail.com";

function escapeHtml(s: unknown): string {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function isValidEmail(e: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405, headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const problematique = String(body?.problematique ?? "").trim().slice(0, 3000);
    const email = String(body?.email ?? "").trim().slice(0, 255);

    if (!problematique || !email || !isValidEmail(email)) {
      return new Response(JSON.stringify({ error: "Champs manquants ou invalides." }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const apiKey = Deno.env.get("RESEND_API_KEY");
    if (!apiKey) {
      console.error("RESEND_API_KEY not set");
      return new Response(JSON.stringify({ error: "Service indisponible." }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#111;line-height:1.6">
      <h2 style="margin:0 0 12px;color:#8B4513">Nouvelle demande de programme personnalisé</h2>
      <p style="margin:6px 0"><strong>Email du client :</strong> ${escapeHtml(email)}</p>
      <p style="margin:12px 0 6px"><strong>Problématique :</strong></p>
      <div style="white-space:pre-wrap;padding:12px;background:#F5F0E6;border-radius:8px;border:1px solid #E3E9E3">${escapeHtml(problematique)}</div>
    </div>`;

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        from: "Noûs <noreply@app-nous.fr>",
        to: [ADMIN_EMAIL],
        reply_to: email,
        subject: `Demande de programme personnalisé — ${email}`,
        html,
      }),
    });

    if (!res.ok) {
      const t = await res.text();
      console.error("Resend program request failed:", res.status, t);
      return new Response(JSON.stringify({ error: "Envoi impossible." }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ ok: true }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("request-program error:", e);
    return new Response(JSON.stringify({ error: "Une erreur est survenue." }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});