import * as React from 'npm:react@18.3.1'
import { Body, Container, Head, Heading, Html, Preview, Section, Text } from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  praticienName?: string
  clientFirstName?: string
  clientLastName?: string
  clientPhone?: string
  preferredMoments?: string
  preferredDays?: string
}

const Email = ({ praticienName, clientFirstName, clientLastName, clientPhone, preferredMoments, preferredDays }: Props) => (
  <Html lang="fr">
    <Head />
    <Preview>Nouvelle demande de rappel Noûs</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>Nouvelle demande de rappel 🌿</Heading>
        <Text style={text}>{praticienName ? `Bonjour ${praticienName},` : 'Bonjour,'}</Text>
        <Text style={text}>Une personne souhaite être rappelée pour convenir d'un rendez-vous avec vous.</Text>
        <Section style={card}>
          {(clientFirstName || clientLastName) && (
            <Text style={cardLine}><strong>Nom :</strong> {[clientFirstName, clientLastName].filter(Boolean).join(' ')}</Text>
          )}
          {clientPhone && <Text style={cardLine}><strong>Téléphone :</strong> {clientPhone}</Text>}
          {preferredMoments && <Text style={cardLine}><strong>Moments préférés :</strong> {preferredMoments}</Text>}
          {preferredDays && <Text style={cardLine}><strong>Jours préférés :</strong> {preferredDays}</Text>}
        </Section>
        <Text style={text}>Merci de rappeler la personne dans les meilleurs délais.</Text>
        <Text style={signature}>L'équipe Noûs</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: 'Nouvelle demande de rappel Noûs',
  displayName: 'Demande de rappel praticien',
  previewData: { praticienName: 'Sophie', clientFirstName: 'Marie', clientLastName: 'Dupont', clientPhone: '06 12 34 56 78', preferredMoments: 'Matin, Soir', preferredDays: 'Lundi, Mercredi' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Georgia, serif' }
const container = { maxWidth: '560px', margin: '0 auto', padding: '32px 24px', backgroundColor: '#F5F0E6', borderRadius: '12px' }
const h1 = { color: '#8B4513', fontSize: '24px', marginBottom: '16px' }
const text = { color: '#5C3A1E', fontSize: '15px', lineHeight: '1.6' }
const card = { backgroundColor: '#ffffff', padding: '16px 20px', borderRadius: '8px', margin: '20px 0' }
const cardLine = { color: '#5C3A1E', fontSize: '14px', margin: '4px 0' }
const signature = { color: '#8B4513', fontSize: '14px', marginTop: '24px', fontStyle: 'italic' }