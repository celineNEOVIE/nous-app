import * as React from 'npm:react@18.3.1'
import { Body, Container, Head, Heading, Html, Preview, Section, Text } from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  praticienName?: string
  clientName?: string
  clientEmail?: string
  sessionTitle?: string
  amount?: string
}

const Email = ({ praticienName, clientName, clientEmail, sessionTitle, amount }: Props) => (
  <Html lang="fr">
    <Head />
    <Preview>Nouvelle réservation Noûs</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>Nouvelle réservation 🌿</Heading>
        <Text style={text}>{praticienName ? `Bonjour ${praticienName},` : 'Bonjour,'}</Text>
        <Text style={text}>Vous venez de recevoir une nouvelle réservation payée via Noûs.</Text>
        <Section style={card}>
          {sessionTitle && <Text style={cardLine}><strong>Séance :</strong> {sessionTitle}</Text>}
          {amount && <Text style={cardLine}><strong>Montant :</strong> {amount}</Text>}
          {clientName && <Text style={cardLine}><strong>Client :</strong> {clientName}</Text>}
          {clientEmail && <Text style={cardLine}><strong>Email :</strong> {clientEmail}</Text>}
        </Section>
        <Text style={text}>Merci de contacter le client rapidement pour fixer le créneau.</Text>
        <Text style={signature}>L'équipe Noûs</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: 'Nouvelle réservation Noûs',
  displayName: 'Notification praticien',
  previewData: { praticienName: 'Laurence', clientName: 'Marie Dupont', clientEmail: 'marie@example.com', sessionTitle: 'Séance adulte', amount: '70 €' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Georgia, serif' }
const container = { maxWidth: '560px', margin: '0 auto', padding: '32px 24px', backgroundColor: '#F5F0E6', borderRadius: '12px' }
const h1 = { color: '#8B4513', fontSize: '24px', marginBottom: '16px' }
const text = { color: '#5C3A1E', fontSize: '15px', lineHeight: '1.6' }
const card = { backgroundColor: '#ffffff', padding: '16px 20px', borderRadius: '8px', margin: '20px 0' }
const cardLine = { color: '#5C3A1E', fontSize: '14px', margin: '4px 0' }
const signature = { color: '#8B4513', fontSize: '14px', marginTop: '24px', fontStyle: 'italic' }