import * as React from 'npm:react@18.3.1'
import { Body, Container, Head, Heading, Html, Preview, Section, Text } from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  clientName?: string
  praticienName?: string
  sessionTitle?: string
  amount?: string
}

const Email = ({ clientName, praticienName, sessionTitle, amount }: Props) => (
  <Html lang="fr">
    <Head />
    <Preview>Votre réservation Noûs est confirmée</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>Merci pour votre réservation 🌿</Heading>
        <Text style={text}>{clientName ? `Bonjour ${clientName},` : 'Bonjour,'}</Text>
        <Text style={text}>
          Votre paiement a bien été reçu. Votre séance est confirmée.
        </Text>
        <Section style={card}>
          {sessionTitle && <Text style={cardLine}><strong>Séance :</strong> {sessionTitle}</Text>}
          {praticienName && <Text style={cardLine}><strong>Praticien·ne :</strong> {praticienName}</Text>}
          {amount && <Text style={cardLine}><strong>Montant :</strong> {amount}</Text>}
        </Section>
        <Text style={text}>
          Votre praticien·ne vous contactera très prochainement pour convenir du créneau et vous transmettre le lien de visioconférence ou les modalités de l'appel.
        </Text>
        <Text style={signature}>L'équipe Noûs</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: 'Votre réservation Noûs est confirmée',
  displayName: 'Confirmation paiement client',
  previewData: { clientName: 'Marie', praticienName: 'Laurence Giudicelli', sessionTitle: 'Séance adulte', amount: '70 €' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Georgia, serif' }
const container = { maxWidth: '560px', margin: '0 auto', padding: '32px 24px', backgroundColor: '#F5F0E6', borderRadius: '12px' }
const h1 = { color: '#8B4513', fontSize: '24px', marginBottom: '16px' }
const text = { color: '#5C3A1E', fontSize: '15px', lineHeight: '1.6' }
const card = { backgroundColor: '#ffffff', padding: '16px 20px', borderRadius: '8px', margin: '20px 0' }
const cardLine = { color: '#5C3A1E', fontSize: '14px', margin: '4px 0' }
const signature = { color: '#8B4513', fontSize: '14px', marginTop: '24px', fontStyle: 'italic' }