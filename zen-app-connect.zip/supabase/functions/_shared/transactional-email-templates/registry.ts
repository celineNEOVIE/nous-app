import type * as React from 'npm:react@18.3.1'
import { template as paymentClient } from './payment-confirmation-client.tsx'
import { template as paymentPraticien } from './payment-notification-praticien.tsx'
import { template as callbackPraticien } from './callback-request-praticien.tsx'

export interface TemplateEntry {
  component: React.ComponentType<any>
  subject: string | ((data: any) => string)
  displayName?: string
  previewData?: Record<string, unknown>
  to?: string | ((data: any) => string)
}

export const TEMPLATES: Record<string, TemplateEntry> = {
  'payment-confirmation-client': paymentClient,
  'payment-notification-praticien': paymentPraticien,
  'callback-request-praticien': callbackPraticien,
}