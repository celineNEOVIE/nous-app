/// <reference types="npm:@types/react@18.3.1" />

import * as React from 'npm:react@18.3.1'

import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Html,
  Link,
  Preview,
  Text,
} from 'npm:@react-email/components@0.0.22'

interface InviteEmailProps {
  siteName: string
  siteUrl: string
  confirmationUrl: string
}

export const InviteEmail = ({
  siteName,
  siteUrl,
  confirmationUrl,
}: InviteEmailProps) => (
  <Html lang="fr" dir="ltr">
    <Head />
    <Preview>Vous êtes invité·e à rejoindre Noûs</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>Vous êtes invité·e</Heading>
        <Text style={text}>
          Vous avez été invité·e à rejoindre{' '}
          <Link href={siteUrl} style={link}>
            <strong>Noûs</strong>
          </Link>
          . Cliquez sur le bouton ci-dessous pour accepter l'invitation et créer
          votre compte.
        </Text>
        <Button style={button} href={confirmationUrl}>
          Accepter l'invitation
        </Button>
        <Text style={footer}>
          Si vous n'attendiez pas cette invitation, ignorez cet email.
        </Text>
      </Container>
    </Body>
  </Html>
)

export default InviteEmail

const main = { backgroundColor: '#ffffff', fontFamily: 'Georgia, "Times New Roman", serif' }
const container = { padding: '32px 28px', maxWidth: '560px' }
const h1 = {
  fontFamily: 'Alice, Georgia, "Times New Roman", serif',
  fontSize: '26px',
  fontWeight: 'normal' as const,
  color: '#5C4A3A',
  margin: '0 0 24px',
}
const text = { fontSize: '15px', color: '#6b5d4f', lineHeight: '1.6', margin: '0 0 22px' }
const link = { color: '#6B8E5A', textDecoration: 'underline' }
const button = {
  backgroundColor: '#6B8E5A',
  color: '#ffffff',
  fontSize: '15px',
  borderRadius: '8px',
  padding: '14px 28px',
  textDecoration: 'none',
  fontFamily: 'Georgia, "Times New Roman", serif',
}
const footer = { fontSize: '12px', color: '#a89c8e', margin: '32px 0 0', fontStyle: 'italic' as const }
