
import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      fontFamily: {
        'alice': ['Alice', 'serif'],
      },
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        sage: {
          50: "#f4f6f4",
          100: "#E3E9E3",
          200: "#c5d1c5",
          300: "#a7b9a7",
          400: "#89a189",
          500: "#6b896b",
          600: "#566e56",
          700: "#405240",
          800: "#2b372b",
          900: "#151b15",
        },
        warm: {
          50: "#FAFAFA",
          100: "#F5F5F5",
          200: "#E5E5E5",
          300: "#D4D4D4",
          400: "#A3A3A3",
          500: "#737373",
          600: "#525252",
          700: "#404040",
          800: "#262626",
          900: "#171717",
        },
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-5px)" },
        },
        fadeIn: {
          from: { opacity: "0", transform: "translateY(10px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        breathe: {
          "0%, 100%": { transform: "scale(0.65) translateY(0)" },
          "40%": { transform: "scale(1.5) translateY(-30px)" },
          "50%": { transform: "scale(1.5) translateY(-30px)" },
          "90%": { transform: "scale(0.65) translateY(0)" },
        },
        inhaleText: {
          "0%, 40%": { opacity: "1" },
          "50%, 95%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        exhaleText: {
          "0%, 40%": { opacity: "0" },
          "50%, 90%": { opacity: "1" },
          "100%": { opacity: "0" },
        },
        breatheCoherence: {
          "0%, 100%": { transform: "scale(1) translateY(0)" },
          "40%": { transform: "scale(1.08) translateY(-14px)" },
        },
        inhaleTextCoherence: {
          "0%": { opacity: "0" },
          "5%, 38%": { opacity: "1" },
          "45%, 100%": { opacity: "0" },
        },
        exhaleTextCoherence: {
          "0%, 42%": { opacity: "0" },
          "48%, 95%": { opacity: "1" },
          "100%": { opacity: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        float: "float 3s ease-in-out infinite",
        fadeIn: "fadeIn 0.5s ease-out forwards",
        breathe: "breathe 8s ease-in-out infinite",
        "breathe-coherence": "breatheCoherence 10s ease-in-out infinite",
        "inhale-text": "inhaleTextCoherence 10s ease-in-out infinite",
        "exhale-text": "exhaleTextCoherence 10s ease-in-out infinite",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config;
