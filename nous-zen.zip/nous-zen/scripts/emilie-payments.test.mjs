import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import vm from 'node:vm';

const practitioners = readFileSync(new URL('../src/data/practitioners.tsx', import.meta.url), 'utf8');
const emilie = practitioners.split('slug: "emilie-bechard"')[1]?.split('slug: "camille-chopinot"')[0];
assert.ok(emilie, 'Émilie must exist');
const pricingSource = emilie.match(/pricing:\s*(\[[\s\S]*?\])/)?.[1];
assert.ok(pricingSource, 'Émilie must have prices');
const pricing = vm.runInNewContext(`(${pricingSource})`);

test('Émilie individual session: 80 EUR with its checkout key', () => {
  const session = pricing.find((price) => price.title === 'Séance individuelle');
  assert.equal(session?.price, '80 €');
  assert.equal(session?.priceId, 'emilie_seance_80');
});

test('Émilie Chemin vers moi: 550 EUR with its checkout key', () => {
  const programme = pricing.find((price) => price.title === 'Programme « Chemin vers moi »');
  assert.equal(programme?.price, '550 €');
  assert.equal(programme?.priceId, 'emilie_chemin_vers_moi_550');
});

const webhook = readFileSync(new URL('../supabase/functions/payments-webhook/index.ts', import.meta.url), 'utf8');
const recipients = webhook.match(/const PRATICIENS:[^=]+=(\s*\{[\s\S]*?\n\});/)?.[1];
const resolver = webhook.match(/function resolvePraticien\([^)]*\)([\s\S]*?)\n\}/)?.[1];
assert.ok(recipients);
assert.ok(resolver);
const resolvePraticien = vm.runInNewContext(`const PRATICIENS = ${recipients}; (function(lookupKey) ${resolver}\n})`);

for (const priceId of ['emilie_seance_80', 'emilie_chemin_vers_moi_550']) {
  test(`${priceId} notifies Émilie at her requested email`, () => {
    const recipient = resolvePraticien(priceId);
    assert.equal(recipient.name, 'Émilie Béchard');
    assert.equal(recipient.email, 'contact@emiliebechardkinesiologue.fr');
  });
}