import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import vm from 'node:vm';
const source = readFileSync(new URL('../src/data/practitioners.tsx', import.meta.url), 'utf8');
for (const [slug, expected] of [
 ['charlotte-cammarata', [['50 €', 'charlotte_cours_en_ligne_50'], ['66 €', 'charlotte_cours_exterieur_66'], ['88 €', 'charlotte_cours_domicile_88']]],
 ['margaux-derode', [['175 €', 'margaux_stop_anxiete_175'], ['1 050 €', 'margaux_ma_serenite_1150'], ['99 €', 'margaux_seance_adulte_105'], ['75 €', 'margaux_seance_enfant_75']]],
]) {
 const block = source.split(`slug: "${slug}"`)[1]?.split('slug:')[0];
 const pricingSource = block?.match(/pricing:\s*(\[[\s\S]*?\])/)?.[1];
 assert.ok(pricingSource);
 const pricing = vm.runInNewContext(`(${pricingSource})`);
 expected.forEach(([price, priceId], index) => {
  test(`${slug} offer ${index + 1}: ${price} linked to Stripe`, () => {
   assert.equal(pricing[index]?.price, price);
   assert.equal(pricing[index]?.priceId, priceId);
  });
 });
}
