import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import vm from 'node:vm';

const source = readFileSync(new URL('../src/data/practitioners.tsx', import.meta.url), 'utf8');
const jacqui = source.split('slug: "jacqui-syndercombe"')[1];
assert.ok(jacqui);
const pricingSource = jacqui.match(/pricing:\s*(\[[\s\S]*?\])/)?.[1];
assert.ok(pricingSource);
const pricing = vm.runInNewContext(`(${pricingSource})`);

test('Jacqui individual coaching costs 150 EUR for one hour and opens Stripe', () => {
  assert.equal(pricing.length, 1);
  assert.equal(pricing[0].price, '150 €');
  assert.equal(pricing[0].subtitle, '1 heure');
  assert.equal(pricing[0].priceId, 'jacqui_seance_individuelle_150');
});

const webhook = readFileSync(new URL('../supabase/functions/payments-webhook/index.ts', import.meta.url), 'utf8');
const recipients = webhook.match(/const PRATICIENS:[^=]+=(\s*\{[\s\S]*?\n\});/)?.[1];
const resolver = webhook.match(/function resolvePraticien\([^)]*\)([\s\S]*?)\n\}/)?.[1];
assert.ok(recipients);
assert.ok(resolver);
const resolvePraticien = vm.runInNewContext(`const PRATICIENS = ${recipients}; (function(lookupKey) ${resolver}\n})`);

test('Jacqui payment notifications use her requested address', () => {
  const recipient = resolvePraticien('jacqui_seance_individuelle_150');
  assert.equal(recipient.name, 'Jacqui Syndercombe');
  assert.equal(recipient.email, 'jacqui.syndercombe@gmail.com');
});