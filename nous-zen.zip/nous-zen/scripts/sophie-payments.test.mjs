import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import vm from 'node:vm';

const source = readFileSync(new URL('../src/data/practitioners.tsx', import.meta.url), 'utf8');
const sophie = source.split('slug: "sophie-clouet"')[1];
assert.ok(sophie);
const pricingSource = sophie.match(/pricing:\s*(\[[\s\S]*?\])/)?.[1];
assert.ok(pricingSource);
const pricing = vm.runInNewContext(`(${pricingSource})`);

test('Sophie single session costs 95 EUR for one hour and opens Stripe', () => {
  assert.equal(pricing.length, 3);
  assert.equal(pricing[0].title, "Séance à l'unité");
  assert.equal(pricing[0].price, '95 €');
  assert.equal(pricing[0].subtitle, '1 heure de coaching');
  assert.equal(pricing[0].priceId, 'sophie_seance_unite_99');
});

test('Sophie discovery session and monthly plan are unchanged', () => {
  assert.equal(pricing[1].price, '115 €');
  assert.equal(pricing[1].priceId, 'sophie_seance_decouverte_115');
  assert.equal(pricing[2].price, '250 €/mois');
  assert.equal(pricing[2].priceId, 'sophie_forfait_mensuel_250');
});

const mcp = readFileSync(new URL('../src/lib/mcp/data.ts', import.meta.url), 'utf8');
const mcpSophie = mcp.split('slug: "sophie-clouet"')[1].match(/offers:\s*(\[[\s\S]*?\])/)?.[1];
assert.ok(mcpSophie);

test('AI assistants read Sophie single session at 95 EUR', () => {
  assert.match(mcpSophie, /"95 €"/);
  assert.doesNotMatch(mcpSophie, /"99 €"/);
});

const webhook = readFileSync(new URL('../supabase/functions/payments-webhook/index.ts', import.meta.url), 'utf8');
const recipients = webhook.match(/const PRATICIENS:[^=]+=(\s*\{[\s\S]*?\n\});/)?.[1];
const resolver = webhook.match(/function resolvePraticien\([^)]*\)([\s\S]*?)\n\}/)?.[1];
assert.ok(recipients);
assert.ok(resolver);
const resolvePraticien = vm.runInNewContext(`const PRATICIENS = ${recipients}; (function(lookupKey) ${resolver}\n})`);

test('Sophie payment notifications use her requested address', () => {
  const recipient = resolvePraticien('sophie_seance_unite_99');
  assert.equal(recipient.name, 'Sophie Clouet');
  assert.equal(recipient.email, 'contact@philo-sophie.fr');
});
