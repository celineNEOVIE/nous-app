import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import vm from 'node:vm';

const webhook = readFileSync(new URL('../supabase/functions/payments-webhook/index.ts', import.meta.url), 'utf8');
const recipients = webhook.match(/const PRATICIENS:[^=]+=(\s*\{[\s\S]*?\n\});/)?.[1];
const resolver = webhook.match(/function resolvePraticien\([^)]*\)([\s\S]*?)\n\}/)?.[1];
assert.ok(recipients);
assert.ok(resolver);
const resolvePraticien = vm.runInNewContext(`const PRATICIENS = ${recipients}; (function(lookupKey) ${resolver}\n})`);

for (const [name, email, keys] of [
  ['Jacqui Syndercombe', 'jacqui.syndercombe@gmail.com', ['jacqui_seance']],
  ['Margaux Derode', 'margauxderode@gmail.com', ['margaux_stop_anxiete_175', 'margaux_ma_serenite_1150', 'margaux_seance_adulte_105', 'margaux_seance_enfant_75']],
  ['Charlotte Cammarata', 'chamaste.yoga@gmail.com', ['charlotte_cours_en_ligne_50', 'charlotte_cours_exterieur_66', 'charlotte_cours_domicile_88']],
]) {
  test(`${name}: payments resolve to the requested notification recipient`, () => {
    for (const key of keys) {
      const recipient = resolvePraticien(key);
      assert.equal(recipient.name, name);
      assert.equal(recipient.email, email);
    }
  });
}