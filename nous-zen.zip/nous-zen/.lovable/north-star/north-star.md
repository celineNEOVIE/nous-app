<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Cap

Les personnes stressées reçoivent un vrai accompagnement d'un praticien bien-être certifié

## Indicateur

Séances de praticiens payées via le paiement Stripe chaque mois
