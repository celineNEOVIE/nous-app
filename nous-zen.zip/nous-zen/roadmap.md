# Roadmap

## En cours
- [ ] Mise en ligne de la nouvelle photo de Valérie Elineau sur app-nous.fr (en attente de validation).

## Terminé
- [x] Valérie Elineau : fiche créée (photo, présentation, 4 tarifs).
- [x] Valérie Elineau : offres de paiement créées et rattachées aux tarifs (75 €, 110 €, 350 €, 890 €).
- [x] Valérie Elineau : badge « ★ 5,0 · 95 avis Google ».
- [x] Valérie Elineau : email valerieelineau@gmail.com ajouté pour les demandes de rappel.
- [x] Valérie Elineau : pastilles « Santé de la femme » et « Désir d'enfant » côte à côte.
- [x] Valérie Elineau : pastille raccourcie en « Psycho-corporel & émotionnel ».
- [x] Valérie Elineau : photo remplacée par la version recadrée fournie.
- [x] Mise en ligne demandée sur app-nous.fr.
- [x] Retirer « (e) » de « Être rappelé » partout (boutons, titres de fenêtre, FAQ, politique de confidentialité)
