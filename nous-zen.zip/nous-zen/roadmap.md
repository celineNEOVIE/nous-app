# Roadmap

## En cours
- [ ] Jacqui : paiement de 150 € pour 1 heure relié à Stripe test ; mise en ligne et réception des notifications en attente de publication et de paiement.
- [ ] Charlotte et Margaux : synchronisation des sept prix réels en attente de publication ; encaissement et notifications non vérifiés.
- [ ] Émilie Béchard : synchronisation des prix live en attente de publication ; paiement complet et réception d'e-mail non vérifiés.
- [ ] Sophie Clouet : séance à l'unité à 95 € en attente de publication pour les prix réels ; notifications non testées.
- [ ] Mise en ligne de la nouvelle photo de Valérie Elineau sur app-nous.fr (en attente de validation).

## Terminé
- [x] Article « Stress des fêtes de fin d'année » : ajouté en tête (Blog, BlogArticle, sitemap, llms.txt, MCP généré), exercice lié cohérence cardiaque ; liens, référencement et affichage ordinateur/mobile vérifiés, compilation OK, sans publication.
- [x] Article « Réveil à 3 h du matin » : ajouté en tête, références et MCP généré actualisés ; liens, référencement et affichage ordinateur/mobile vérifiés, compilation OK, sans publication ni modification des autres articles.
- [x] Margaux : Ma sérénité 1 050 € et séance adulte 1h30 à 99 € (fiche + Stripe test), vérifiés à l'écran.
- [x] Sophie Clouet : séance à l'unité 99 € → 95 € (fiche, assistants IA, Stripe test) ; paiement embarqué à 95 € et 4 tests vérifiés.
- [x] Sophie Clouet : badge « Coaching santé » retiré, badges « Post cancer », « Retour emploi post maladie » et « Gestion du temps » ajoutés ; vérifié sur ordinateur et téléphone.
- [x] Mention rouge « après crédit d'impôt de 50 % » sous chaque prix (fenêtre Tarifs + fiche) ; sous-titre Camille « 10 séances ».
- [x] Notifications Jacqui, Margaux et Charlotte : destinataires fournis ajoutés, 14 tests réussis et fonction déployée ; réception réelle non testée.
- [x] Charlotte et Margaux : sept tarifs reliés à Stripe ; sept formulaires de test ouverts et 11 tests réussis. Aucun paiement effectué, aucune publication.
- [x] Article « Méditation pour débutants » : ajouté en tête avec sitemap, llms.txt et données MCP ; liens, SEO et affichage ordinateur/mobile vérifiés, compilation OK, sans publication.
- [x] Émilie Béchard : clés de paiement ajoutées, deux prix Stripe test uniques EUR créés (80 € / 550 €), notification ajoutée et fonction déployée ; formulaires Stripe vérifiés et 4 tests réussis.
- [x] Pages exercices : encart « Envie d'être accompagné(e) ? » vers /praticiens sous le texte de fin, sur les 5 pages (vérifié sur téléphone et ordinateur).
- [x] Pages exercices : descriptions « Sons binauraux » et « Méditations guidées » remplacées (metaDescription uniquement).
- [x] Article « Burn-out : 8 signes d'alerte » ajouté en tête du blog, au sitemap et à llms.txt ; liens, métadonnées et affichage vérifiés.
- [x] Liens « En savoir plus » sous les 5 cartes d'exercices de la fenêtre des outils (vers les pages /exercices/<slug>).
- [x] Article « Fatigue d'automne » ajouté au blog, aux données des assistants et au sitemap.
- [x] Valérie Elineau : fiche créée (photo, présentation, 4 tarifs).
- [x] Valérie Elineau : offres de paiement créées et rattachées aux tarifs (75 €, 110 €, 350 €, 890 €).
- [x] Valérie Elineau : badge « ★ 5,0 · 95 avis Google ».
- [x] Valérie Elineau : email valerieelineau@gmail.com ajouté pour les demandes de rappel.
- [x] Valérie Elineau : pastilles « Santé de la femme » et « Désir d'enfant » côte à côte.
- [x] Valérie Elineau : pastille raccourcie en « Psycho-corporel & émotionnel ».
- [x] Valérie Elineau : photo remplacée par la version recadrée fournie.
- [x] Mise en ligne demandée sur app-nous.fr.
- [x] Retirer « (e) » de « Être rappelé » partout (boutons, titres de fenêtre, FAQ, politique de confidentialité)
