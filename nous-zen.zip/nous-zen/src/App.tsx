import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation, Navigate } from "react-router-dom";

import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import Index from "./pages/Index";
import FAQ from "./pages/FAQ";
import MentionsLegales from "./pages/MentionsLegales";
import PolitiqueConfidentialite from "./pages/PolitiqueConfidentialite";
import PaiementConfirmation from "./pages/PaiementConfirmation";
import Unsubscribe from "./pages/Unsubscribe";
import Exercices from "./pages/Exercices";
import ExercicePage from "./pages/ExercicePage";
import Blog from "./pages/Blog";
import BlogArticle from "./pages/BlogArticle";
// Page Événements masquée temporairement (à réactiver plus tard)
// import Evenements from "./pages/Evenements";
import Praticiens from "./pages/Praticiens";
import APropos from "./pages/APropos";
import Praticien from "./pages/Praticien";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const RedirectOrNotFound = () => {
  const { pathname } = useLocation();
  const normalized = pathname.toLowerCase();
  const target = "/politique-confidentialite";

  if (
    normalized !== target &&
    (normalized.includes("politique-de-confidentialite") ||
      normalized.includes("privacy-policy") ||
      normalized.includes("confidentialite"))
  ) {
    return <Navigate to={target} replace />;
  }

  return <NotFound />;
};


const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/mentions-legales" element={<MentionsLegales />} />
          <Route path="/politique-confidentialite" element={<PolitiqueConfidentialite />} />
          <Route path="/paiement-confirmation" element={<PaiementConfirmation />} />
          <Route path="/unsubscribe" element={<Unsubscribe />} />
          <Route path="/exercices" element={<Exercices />} />
          <Route path="/exercices/:slug" element={<ExercicePage />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/charge-mentale-signes-conseils" element={<Navigate to="/blog/naturopathie-hiver-conseils" replace />} />
          <Route path="/blog/:slug" element={<BlogArticle />} />
          <Route path="/a-propos" element={<APropos />} />
          <Route path="/praticiens" element={<Praticiens />} />
          {/* <Route path="/evenements" element={<Evenements />} /> */}
          <Route path="/praticiens/:slug" element={<Praticien />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<RedirectOrNotFound />} />
        </Routes>
        <Footer />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
