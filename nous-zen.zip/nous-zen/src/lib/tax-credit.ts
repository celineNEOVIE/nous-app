const NBSP = "\u00A0";

/** "105 €" -> "soit 52,50 € après crédit d'impôt de 50 %" ; null si le prix n'est pas lisible. */
export function taxCreditLabel(price: string): string | null {
  const normalized = price.replace(/[\s\u00A0\u202F]/g, "");
  const match = normalized.match(/^(\d+(?:[.,]\d+)?)€(\/mois)?$/i);
  if (!match) return null;
  const half = parseFloat(match[1].replace(",", ".")) / 2;
  const isWhole = Number.isInteger(half);
  const amount = half
    .toLocaleString("fr-FR", { minimumFractionDigits: isWhole ? 0 : 2, maximumFractionDigits: isWhole ? 0 : 2 })
    .replace(/[\s\u202F]/g, NBSP);
  return `soit ${amount}${NBSP}€${match[2] ? "/mois" : ""} après crédit d'impôt de 50${NBSP}%`;
}
