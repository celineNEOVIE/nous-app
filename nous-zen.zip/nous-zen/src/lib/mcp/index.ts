import { defineMcp } from "@lovable.dev/mcp-js";
import { getPractitioner, listPractitioners } from "./tools/practitioners";
import { listArticles, listEvents } from "./tools/content";

export default defineMcp({
  name: "zen-app-connect",
  title: "zen-app-connect",
  version: "0.1.0",
  instructions:
    "Outils publics de Noûs (app-nous.fr), plateforme bien-être agréée Services à la Personne : praticiens certifiés avec 50 % de crédit d'impôt, tarifs, événements et articles du blog. Utilisez list_practitioners puis get_practitioner pour orienter vers une fiche de réservation.",
  tools: [listPractitioners, getPractitioner, listEvents, listArticles],
});
