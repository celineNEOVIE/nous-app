import { defineTool } from "@lovable.dev/mcp-js";
import { articles, events } from "../data";

export const listEvents = defineTool({
  name: "list_events",
  title: "Lister les événements",
  description: "Liste les retraites, stages et formations bien-être organisés par les praticiennes Noûs.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: () => {
    const list = events.map((e) => ({ ...e }));
    return { content: [{ type: "text", text: JSON.stringify(list) }], structuredContent: { events: list } };
  },
});

export const listArticles = defineTool({
  name: "list_articles",
  title: "Lister les articles du blog",
  description: "Liste les articles du blog Noûs (stress, sommeil, sophrologie, crédit d'impôt…) avec leur lien.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: () => {
    const list = articles.map((a) => ({ ...a }));
    return { content: [{ type: "text", text: JSON.stringify(list) }], structuredContent: { articles: list } };
  },
});
