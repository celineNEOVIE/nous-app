import { defineTool, ToolError } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { practitioners, practitionerUrl } from "../data";

const norm = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

export const listPractitioners = defineTool({
  name: "list_practitioners",
  title: "Lister les praticiens",
  description: "Liste les praticiens bien-être Noûs, filtrables par mot-clé (spécialité, thème ou nom).",
  inputSchema: { query: z.string().optional().describe("Mot-clé optionnel, ex. « stress », « sommeil », « sophrologue ».") },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ query }) => {
    const q = query ? norm(query) : "";
    const list = practitioners
      .filter((p) => !q || norm([p.name, ...p.specialties, ...p.tags].join(" ")).includes(q))
      .map((p) => ({
        slug: p.slug,
        name: p.name,
        specialties: p.specialties,
        tags: p.tags,
        googleRating: p.googleRating,
        googleReviews: p.googleReviews,
        url: practitionerUrl(p.slug),
      }));
    return {
      content: [{ type: "text", text: JSON.stringify(list) }],
      structuredContent: { practitioners: list, taxCredit: "50 % de crédit d'impôt sur toutes les séances" },
    };
  },
});

export const getPractitioner = defineTool({
  name: "get_practitioner",
  title: "Détails d'un praticien",
  description: "Donne les spécialités, avis Google, tarifs et lien de réservation d'un praticien Noûs.",
  inputSchema: { slug: z.string().describe("Identifiant du praticien, ex. « valerie-elineau » (voir list_practitioners).") },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ slug }) => {
    const p = practitioners.find((x) => x.slug === slug);
    if (!p) throw new ToolError(`Praticien inconnu : ${slug}`);
    const data = {
      slug: p.slug,
      name: p.name,
      specialties: p.specialties,
      tags: p.tags,
      googleRating: p.googleRating,
      googleReviews: p.googleReviews,
      formats: ["Visio", "Téléphone", "Présentiel"],
      offers: p.offers.map((o) => ({ title: o.title, detail: o.detail, price: o.price })),
      taxCredit: "50 % de crédit d'impôt (article 199 sexdecies du CGI)",
      bookingUrl: practitionerUrl(p.slug),
    };
    return { content: [{ type: "text", text: JSON.stringify(data) }], structuredContent: { practitioner: data } };
  },
});
