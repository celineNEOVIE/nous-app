// Public site data exposed by the MCP server (mirrors the website content).
const SITE = "https://app-nous.fr";

type Offer = { title: string; detail: string; price: string };
type Practitioner = {
  slug: string;
  name: string;
  specialties: string[];
  tags: string[];
  googleRating: number | null;
  googleReviews: number | null;
  offers: Offer[];
};

export const practitioners: Practitioner[] = [
  { slug: "camille-chopinot", name: "Camille Chopinot", specialties: ["Naturopathe certifié Fena", "Magnétiseur", "Thérapie psycho-corporelle", "Gestion des émotions", "Accompagnement mieux-être"], tags: ["Émotions", "Fatigue", "Équilibre"], googleRating: 5, googleReviews: 26, offers: [
    { title: "Accompagnement mieux-être", detail: "1h30", price: "90 €" },
    { title: "Thérapie brève équilibre durable", detail: "10 séances (425 € après 50% crédit d'impôts)", price: "850 €" },
    { title: "Soins énergétiques", detail: "1 heure", price: "60 €" },
    { title: "Soins énergétiques", detail: "3 séances", price: "140 €" },
  ] },
  { slug: "sophie-clouet", name: "Sophie Clouet", specialties: ["Coach santé certifiée RNCP"], tags: ["Gestion du stress", "Burn-out", "Coaching santé"], googleRating: 5, googleReviews: 26, offers: [
    { title: "Séance à l'unité", detail: "1 heure de coaching", price: "99 €" },
    { title: "Séance découverte", detail: "1h30 pour découvrir le coaching", price: "115 €" },
    { title: "Forfait mensuel", detail: "2 séances + programme en ligne", price: "250 €/mois" },
  ] },
  { slug: "valerie-elineau", name: "Valérie Elineau", specialties: ["Sophrologue RNCP", "Conseillère en huiles essentielles", "Psycho-corporel & émotionnel"], tags: ["Désir d'enfant", "Santé de la femme", "Bouleversements et passages de vie"], googleRating: 5, googleReviews: 100, offers: [
    { title: "Séance individuelle", detail: "Sophrologie & régulation émotionnelle — 1h", price: "75 €" },
    { title: "Séance Boussole — Revenir à mon axe", detail: "1h30", price: "110 €" },
    { title: "Parcours Revenir à mon axe", detail: "5 séances de 1h", price: "350 €" },
    { title: "Éveil à la Vie", detail: "Projet bébé au naturel & PMA — 4 mois", price: "890 €" },
  ] },
  { slug: "nathalie-garnier", name: "Nathalie Garnier", specialties: ["Accompagnante bien-être", "Méditation"], tags: ["Gestion du stress", "Sommeil", "Anxiété"], googleRating: null, googleReviews: null, offers: [
    { title: "Forfait 5 séances", detail: "Accompagnement holistique complet", price: "250 €" },
  ] },
  { slug: "laurence-giudicelli", name: "Laurence Giudicelli", specialties: ["Psychothérapeute (n° RPPS)", "formatrice"], tags: ["Art-thérapeute", "Relations/Couple", "Energéticienne", "Qi Cleansing"], googleRating: 4.8, googleReviews: 60, offers: [
    { title: "Séance adulte", detail: "Psychothérapie individuelle", price: "77 €" },
    { title: "Séance couple / famille", detail: "Accompagnement relationnel", price: "94 €" },
    { title: "Séance soin Qi cleansing", detail: "Soin énergétique", price: "121 €" },
  ] },
  { slug: "clara-regnier", name: "Clara Regnier", specialties: ["Therapeute holistique", "Formatrice"], tags: ["Gestion du stress", "Méditation", "Soins énergétiques"], googleRating: null, googleReviews: null, offers: [
    { title: "Boost Relaxation 30 min", detail: "Séance énergétique", price: "45 €" },
    { title: "Réharmonisation énergétique", detail: "Avec reprogrammation cellulaire et coaching", price: "110 €" },
    { title: "Séance de suivi", detail: "Coaching", price: "90 €" },
  ] },
  { slug: "oceane-danjon", name: "Océane Danjon", specialties: ["Accompagnement psycho-corporel, systémique et créatif"], tags: ["Régulation corporelle", "Dynamique relationnelle"], googleRating: 5, googleReviews: 32, offers: [
    { title: "Accompagnement psycho-corporel", detail: "Séance individuelle 1 heure", price: "77 €" },
  ] },
];

export const practitionerUrl = (slug: string) => `${SITE}/praticiens/${slug}`;

export const events = [
  { title: "Boot camp retour à soi", organizers: "Laurence Giudicelli et Océane Danjon", dates: "Du 16 au 19 octobre 2026", place: "Chem. des Anges Villa 4, 83470 Saint-Maximin-la-Sainte-Baume", price: "À partir de 759 € (hors hébergement et repas) — financement possible jusqu'à 50 %", contact: "terredelune08@gmail.com" },
  { title: "Formation Praticien·ne en accompagnement psycho-corporel et créatif (Session 2027)", organizers: "Laurence Giudicelli et Océane Danjon", dates: "Du 27 novembre 2026 au 4 juin 2027", place: "La source des Anges, 28 chemin de St Hubert, 83860 Nans les pins", price: "Voir https://www.terredelune.fr/formation-accompagnement-psycho-corporel", contact: "terredelune08@gmail.com" },
];

export const articles = [
  { slug: "fatigue-automne-changement-saison", title: "Fatigue d'automne : 7 rituels doux pour traverser le changement de saison" },
  { slug: "reflexologie-des-mains-apaisement", title: "La réflexologie des mains, un raccourci vers l'apaisement" },
  { slug: "credit-impot-consultations-bien-etre", title: "Crédit d'impôt de 50% sur vos consultations bien-être : comment ça marche vraiment ?" },
  { slug: "perte-concentration-clarte-mentale", title: "Pourquoi j'oublie tout et n'arrive plus à me concentrer ? 5 habitudes simples pour retrouver sa clarté mentale" },
  { slug: "sons-binauraux-cerveau-routine-bien-etre", title: "Sons binauraux : comment ils agissent sur le cerveau et pourquoi les intégrer à votre routine bien-être" },
  { slug: "stress-anxiete-difference", title: "Stress et anxiété : comprendre la différence pour mieux agir" },
  { slug: "sommeil-bien-etre", title: "Sommeil et bien-être : pourquoi bien dormir change tout" },
  { slug: "sophrologie-methode-douce", title: "La sophrologie : une méthode douce pour retrouver l'équilibre" },
  { slug: "coherence-cardiaque", title: "La cohérence cardiaque : respirez, votre cœur vous remerciera" },
  { slug: "bien-etre-global-approches-complementaires", title: "Bien-être global : quand plusieurs approches se complètent" },
].map((a) => ({ ...a, url: `${SITE}/blog/${a.slug}` }));
