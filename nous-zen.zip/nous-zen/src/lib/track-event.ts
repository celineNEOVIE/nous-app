/**
 * Minimal GA4 event helper with de-duplication so a rapid double-click
 * (or a re-render) never sends the same event twice.
 */
const lastSent = new Map<string, number>();

export function trackEventOnce(eventName: string, windowMs = 1500) {
  const now = Date.now();
  const previous = lastSent.get(eventName);
  if (previous && now - previous < windowMs) return;
  lastSent.set(eventName, now);
  if (typeof window !== "undefined" && typeof (window as any).gtag === "function") {
    (window as any).gtag("event", eventName);
  }
}
