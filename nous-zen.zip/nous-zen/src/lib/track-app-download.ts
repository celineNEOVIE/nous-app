type Plateforme = "ios" | "android";

declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void;
  }
}

/**
 * Envoie l'événement GA4 `click_telecharger_app` puis exécute la redirection.
 * Utilise `event_callback` (avec timeout de secours) pour laisser partir le hit.
 */
export function trackEvent(
  eventName: string,
  params: Record<string, unknown> = {},
  onDone?: () => void,
) {
  if (typeof window === "undefined" || typeof window.gtag !== "function") {
    onDone?.();
    return;
  }

  let done = false;
  const finish = () => {
    if (done) return;
    done = true;
    onDone?.();
  };

  window.gtag("event", eventName, {
    ...params,
    event_callback: finish,
    event_timeout: 500,
  });

  window.setTimeout(finish, 500);
}

export function trackAppDownload(plateforme: Plateforme, onDone?: () => void) {
  trackEvent("click_telecharger_app", { plateforme }, onDone);
}

/** Clic sur une fiche praticien (annuaire ou carte). */
export function trackPractitionerClick(
  praticienId: string,
  praticienCategorie?: string,
) {
  trackEvent("click_praticien", {
    praticien_id: praticienId,
    praticien_categorie: praticienCategorie,
  });
}
