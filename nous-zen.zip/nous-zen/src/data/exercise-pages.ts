export type ExercisePage = {
  slug: string;
  navLabel: string;
  targetView: "coherence" | "meditation" | "exercices" | "reflexologie" | "sons";
  metaTitle: string;
  metaDescription: string;
  h1: string;
  intro: string;
  duration: string;
  isoDuration: string;
  steps: string[];
  variants: { name: string; detail: string }[];
  outro: string;
  blog?: { slug: string; title: string };
};

export const exercisePages: ExercisePage[] = [
  {
    slug: "coherence-cardiaque",
    navLabel: "Cohérence cardiaque",
    targetView: "coherence",
    metaTitle: "Exercice de cohérence cardiaque gratuit | Noûs",
    metaDescription: "Respiration guidée en ligne : cohérence express 4-4-4-4, cohérence du soir 4-7-8 et cohérence profonde 5-5. Une pause de 5 minutes pour souffler.",
    h1: "Exercice de cohérence cardiaque gratuit",
    intro: "La cohérence cardiaque est une technique de respiration simple et rythmée qui invite le corps à ralentir. En quelques minutes, elle offre une vraie pause dans la journée : un moment pour relâcher les tensions, retrouver un souffle plus ample et revenir au calme. Elle convient à tout le monde, débutant ou non, que vous ayez besoin d'un instant de détente au bureau, avant un rendez-vous important ou au moment du coucher.",
    duration: "Durée conseillée : 5 minutes, jusqu'à 3 fois par jour",
    isoDuration: "PT5M",
    steps: [
      "Installez-vous assis, le dos droit, les pieds bien posés au sol.",
      "Choisissez une variante et laissez-vous guider par l'animation à l'écran.",
      "Inspirez par le nez au rythme indiqué, en gonflant doucement le ventre.",
      "Expirez lentement, sans forcer, en relâchant les épaules.",
      "Poursuivez environ 5 minutes, puis prenez quelques secondes pour observer vos sensations.",
    ],
    variants: [
      { name: "Cohérence express (4-4-4-4)", detail: "la respiration carrée : inspirer, retenir, expirer, retenir, 4 secondes chacun. Idéale pour une pause rapide." },
      { name: "Cohérence du soir (4-7-8)", detail: "une expiration longue qui accompagne la détente avant le coucher." },
      { name: "Cohérence profonde (5-5)", detail: "5 secondes d'inspiration, 5 secondes d'expiration : le rythme classique, environ 6 respirations par minute." },
    ],
    outro: "La régularité compte davantage que la durée : quelques minutes chaque jour suffisent pour en faire un rituel de bien-être. L'exercice est gratuit, sans inscription, sur le site comme dans l'application Noûs.",
    blog: { slug: "coherence-cardiaque", title: "La cohérence cardiaque : respirez, votre cœur vous remerciera" },
  },
  {
    slug: "meditation-guidee",
    navLabel: "Méditations guidées",
    targetView: "meditation",
    metaTitle: "Méditation guidée gratuite en ligne | Noûs",
    metaDescription: "Méditations guidées gratuites : méditation zen, rivière nettoyante, balade méditative, Bulle de douceur. Quelques minutes pour vous poser en douceur.",
    h1: "Méditation guidée gratuite en ligne",
    intro: "Prendre quelques minutes pour méditer, c'est s'offrir une parenthèse de calme au milieu d'une journée chargée. Les méditations guidées de Noûs vous accompagnent pas à pas, avec une voix douce et des images apaisantes, pour porter l'attention sur la respiration, le corps et l'instant présent. Elles s'adressent aussi bien aux personnes qui découvrent la méditation qu'à celles qui souhaitent installer une pratique régulière.",
    duration: "Durée conseillée : 5 à 10 minutes, idéalement chaque jour",
    isoDuration: "PT10M",
    steps: [
      "Trouvez un endroit calme et adoptez une position confortable, assise ou allongée.",
      "Choisissez une méditation et, si possible, utilisez un casque ou des écouteurs.",
      "Fermez les yeux ou posez le regard devant vous, et laissez la voix vous guider.",
      "Si des pensées surgissent, accueillez-les sans jugement et revenez à votre souffle.",
      "À la fin, prenez un moment avant de reprendre vos activités.",
    ],
    variants: [
      { name: "Méditation zen", detail: "une pratique simple, centrée sur la respiration et la présence." },
      { name: "Méditation de la rivière nettoyante", detail: "une visualisation pour laisser filer les tensions du quotidien." },
      { name: "Balade méditative", detail: "une promenade intérieure guidée pour s'aérer l'esprit." },
      { name: "Bulle de douceur (8 min 31)", detail: "un moment enveloppant pour se détendre et se recentrer." },
    ],
    outro: "Il n'y a pas de bonne ou de mauvaise méditation : l'essentiel est de vous accorder ce temps, avec bienveillance. Toutes les méditations sont accessibles gratuitement sur le site et dans l'application Noûs.",
    blog: { slug: "sophrologie-methode-douce", title: "La sophrologie : une méthode douce pour retrouver l'équilibre" },
  },
  {
    slug: "sons-binauraux",
    navLabel: "Sons binauraux",
    targetView: "sons",
    metaTitle: "Sons binauraux gratuits : Thêta, Delta, nature | Noûs",
    metaDescription: "Écoutez gratuitement des sons binauraux (8 Hz Thêta, 2 Hz Delta) et des ambiances nature : vagues, pluie, oiseaux. À écouter au casque pour se détendre.",
    h1: "Sons binauraux et ambiances nature gratuits",
    intro: "Les sons binauraux reposent sur un principe étonnant : chaque oreille reçoit une fréquence légèrement différente, et le cerveau perçoit une troisième pulsation, plus lente. Beaucoup de personnes les utilisent pour accompagner un moment de détente, de concentration ou la préparation au sommeil. Noûs propose aussi des ambiances nature, parfaites pour créer une bulle sonore apaisante, que vous soyez au travail, en transport ou chez vous.",
    duration: "Durée conseillée : 10 à 20 minutes, au casque",
    isoDuration: "PT15M",
    steps: [
      "Mettez un casque ou des écouteurs stéréo : c'est indispensable pour l'effet binaural.",
      "Réglez le volume à un niveau doux et confortable.",
      "Choisissez une fréquence selon votre intention : détente, ou préparation au sommeil.",
      "Installez-vous confortablement, fermez les yeux et respirez tranquillement.",
      "Écoutez au moins 10 minutes, sans conduire ni utiliser de machine.",
    ],
    variants: [
      { name: "8 Hz — ondes Thêta", detail: "associées à la relaxation profonde et à la rêverie." },
      { name: "2 Hz — ondes Delta", detail: "pour accompagner l'endormissement et les moments de repos." },
      { name: "Ambiances nature", detail: "vagues, pluie et chants d'oiseaux pour une pause sonore apaisante." },
    ],
    outro: "Les sons binauraux sont une aide à la détente et ne remplacent pas un avis médical. Par précaution, les personnes sujettes à l'épilepsie doivent s'abstenir. L'écoute est gratuite sur le site et dans l'application Noûs.",
    blog: { slug: "sons-binauraux-cerveau-routine-bien-etre", title: "Sons binauraux : comment ils agissent sur le cerveau et pourquoi les intégrer à votre routine bien-être" },
  },
  {
    slug: "reflexologie-des-mains",
    navLabel: "Réflexologie des mains",
    targetView: "reflexologie",
    metaTitle: "Réflexologie des mains : exercices guidés | Noûs",
    metaDescription: "4 exercices vidéo de réflexologie des mains de 2 minutes : digestion, mal de dos, stress, ruminations. Une pause de bien-être à faire partout.",
    h1: "Exercices de réflexologie des mains guidés",
    intro: "La réflexologie des mains propose de stimuler par de légères pressions certaines zones de la paume et des doigts. Simple et discrète, elle se pratique partout, sans matériel : au bureau, dans le train ou le soir sur le canapé. Les exercices vidéo de Noûs vous montrent les gestes pas à pas, en deux minutes, pour s'accorder une pause de bien-être et se reconnecter à son corps.",
    duration: "Durée conseillée : 2 minutes par exercice",
    isoDuration: "PT2M",
    steps: [
      "Installez-vous confortablement et frottez vos mains l'une contre l'autre pour les réchauffer.",
      "Choisissez l'exercice qui correspond à votre besoin du moment.",
      "Suivez les gestes de la vidéo en exerçant une pression douce, jamais douloureuse.",
      "Respirez calmement pendant toute la durée du chronomètre.",
      "Terminez en relâchant les mains et en observant vos sensations.",
    ],
    variants: [
      { name: "Réflexologie des mains — Digestion", detail: "des points associés à la digestion, pour un moment de confort." },
      { name: "Réflexologie des mains — Mal de dos", detail: "des gestes pour relâcher les tensions du dos." },
      { name: "Réflexologie des mains — Stress", detail: "une pause pour faire retomber la pression." },
      { name: "Réflexologie des mains — Ruminations", detail: "pour apaiser le flot des pensées." },
    ],
    outro: "Ces exercices sont une invitation à la détente et ne remplacent pas un avis médical. Ils sont gratuits sur le site et dans l'application Noûs.",
    blog: { slug: "reflexologie-des-mains-apaisement", title: "La réflexologie des mains, un raccourci vers l'apaisement" },
  },
  {
    slug: "jeux-de-relaxation",
    navLabel: "Jeux de relaxation",
    targetView: "exercices",
    metaTitle: "Jeux de relaxation gratuits en ligne | Noûs",
    metaDescription: "Mini-jeux de détente gratuits : Bulles Zen, mandala à colorier, jardin de sable, galets d'équilibre, memory zen. Une pause ludique pour souffler.",
    h1: "Jeux de relaxation gratuits pour se détendre",
    intro: "Parfois, le plus simple pour décrocher, c'est de jouer. Les mini-jeux de détente de Noûs ont été pensés comme de petites pauses douces : pas de score stressant, pas de chronomètre pressant, juste des gestes lents et des couleurs apaisantes pour occuper les mains et laisser l'esprit se poser. Ils conviennent aux adultes comme aux plus jeunes, à tout moment de la journée.",
    duration: "Durée conseillée : 3 à 10 minutes",
    isoDuration: "PT5M",
    steps: [
      "Choisissez un jeu selon votre envie du moment.",
      "Ralentissez volontairement vos gestes et respirez tranquillement.",
      "Concentrez-vous sur les formes, les couleurs et les sons.",
      "Arrêtez-vous quand vous vous sentez plus détendu, sans chercher la performance.",
    ],
    variants: [
      { name: "Bulles Zen", detail: "faites éclater des bulles en douceur, au rythme de votre souffle." },
      { name: "Mandala à colorier", detail: "un coloriage apaisant pour se concentrer sur l'instant." },
      { name: "Jardin zen", detail: "tracez des sillons dans le sable comme dans un jardin japonais." },
      { name: "Galets d'équilibre", detail: "empilez des galets avec patience et attention." },
      { name: "Memory zen", detail: "un jeu de mémoire tranquille aux images apaisantes." },
    ],
    outro: "Ces jeux sont gratuits, sans inscription, sur le site comme dans l'application Noûs.",
  },
];
