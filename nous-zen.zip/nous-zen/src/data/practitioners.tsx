import { useState } from "react";
import { resolveAssetUrl } from "@/lib/asset-url";
import valerieImg from "@/assets/valerie-elineau.jpg.asset.json";
import nathalieImg from "@/assets/nathalie-garnier.jpg.asset.json";
import claraImg from "@/assets/clara-regnier.jpg.asset.json";
import camilleImg from "@/assets/camille-chopinot.jpg.asset.json";
import laurenceImg from "@/assets/laurence-giudicelli.jpg.asset.json";
import sophieImg from "@/assets/sophie-clouet.jpg.asset.json";
import oceaneImg from "@/assets/oceane-danjon.jpg.asset.json";
import emilieImg from "@/assets/emilie-bechard.jpg.asset.json";
import jacquiImg from "@/assets/jacqui-syndercombe-seated.jpg.asset.json";
import margauxImg from "@/assets/margaux-derode.jpg.asset.json";
import charlotteImg from "@/assets/charlotte-cammarata.jpg.asset.json";
import qiCleansingImg from "@/assets/QI_Cleansing.jpg.asset.json";


const QiCleansingReveal = () => {
  const [open, setOpen] = useState(false);
  return (
    <div className="my-4">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between rounded-xl bg-sage-100 px-4 py-3 text-left font-medium text-[#8B4513] hover:bg-sage-200 transition-colors"
        aria-expanded={open}
      >
        <span>Qi cleansing</span>
        <span className={`transform transition-transform ${open ? "rotate-180" : ""}`}>▼</span>
      </button>
      {open && (
        <a
          href={resolveAssetUrl(qiCleansingImg.url)}
          target="_blank"
          rel="noopener noreferrer"
          className="block overflow-hidden rounded-b-xl shadow-md hover:shadow-lg transition-shadow mt-2"
          aria-label="Voir la fiche Qi Cleansing en grand"
        >
          <img
            src={resolveAssetUrl(qiCleansingImg.url)}
            alt="Qi Cleansing - Laurence Giudicelli"
            className="w-full h-auto object-cover"
            loading="lazy"
          />
        </a>
      )}
    </div>
  );
};


export const practitioners = [
  {
    slug: "emilie-bechard",
    name: "Émilie Béchard",
    ville: "Colombier-le-Jeune",
    region: "Auvergne-Rhône-Alpes",
    image: emilieImg.url,
    googleAvisUrl: "https://share.google/n1FwTy3BBnuMIlfbQ",
    googleNote: 5.0,
    googleNombreAvis: 59,
    specialties: ["Kinésiologue", "Accompagnante psycho-corporelle"],
    experience: "",
    availableFor: ["video", "phone"] as Array<"video" | "phone">,
    tags: ["Maternité & parentalité", "Enfance", "Reconnexion à soi"],
    bioTitle: "Émilie Béchard",
    bio: (
      <>
        <p className="font-medium text-[#8B4513]">J'accompagne celles et ceux qui portent trop</p>
        <p>
          J'accompagne celles et ceux qui portent trop, qui ressentent le besoin de se retrouver, de mieux se comprendre et de retrouver leur propre élan.
        </p>
        <p>
          Parce qu'on avance souvent dans la vie en faisant de notre mieux, en répondant aux attentes, en prenant soin des autres… parfois jusqu'à s'oublier soi-même. Et puis, il arrive un moment où l'on ressent le besoin de faire une pause. De comprendre ce qui se joue en soi. De retrouver de l'espace, de la douceur et de se reconnecter à ses propres besoins.
        </p>
        <p>
          Mon accompagnement est avant tout une rencontre. Un endroit où l'on peut déposer ce qui est là, mettre des mots sur ce que l'on traverse, mais aussi prendre le temps de ressentir, d'explorer et d'écouter ce qui se passe en soi.
        </p>
        <p>
          J'accompagne avec tout mon être et toutes mes expériences passées, à la fois professionnelles et privées. Avec la kinésiologie je me fais traductrice de votre corps, de vos maux.
        </p>
        <p>
          Mon rôle n'est pas de vous dire qui vous devez être, ni de vous apporter des réponses toutes faites, mais de vous accompagner avec écoute et bienveillance dans la découverte de vos propres ressources.
        </p>
        <p>
          J'accorde également une place particulière à l'accompagnement autour de la maternité, de la parentalité et de l'enfance. Parce que devenir parent, grandir ou traverser certaines étapes de vie peut venir bousculer nos repères et nos émotions. Je souhaite offrir aux enfants comme aux adultes un espace où chacun peut être accueilli tel qu'il est.
        </p>
        <p>
          Mon intention, au fond, est simple : vous offrir un espace pour vous déposer, vous reconnecter à vous-même et avancer à votre rythme, avec un peu plus de compréhension, de confiance et de douceur envers vous-même.
        </p>
        <p>
          Parce que prendre soin de soi n'est pas un luxe. Et qu'on n'a pas besoin d'attendre d'aller mal pour s'accorder du temps. 🤍
        </p>
        <p className="font-medium text-[#8B4513]">Tarifs et prestations</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Séance individuelle au cabinet ou en visio : 80 €</li>
          <li>
            Programme « Chemin vers moi » — 3 mois d'accompagnement : 550 €.
            Contenu : 3 séances de kinésiologie au cabinet ou en visio, un suivi par messagerie (WhatsApp) sur toute la durée de l'accompagnement, un tirage de carte par semaine pour rester connectée à votre chemin, des rituels et exercices personnalisés selon votre évolution (EFT, méditation, …) et un soin énergétique de clôture au cabinet ou en visio.
          </li>
        </ul>
        <p className="font-medium text-[#8B4513]">Liens utiles</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>
            Site internet :{" "}
            <a href="https://emiliebechardkinesiologue.fr/" target="_blank" rel="noopener noreferrer" className="text-sage-700 underline hover:text-sage-800">emiliebechardkinesiologue.fr</a>
          </li>
          <li>
            Instagram :{" "}
            <a href="https://www.instagram.com/emilie.bechard.kinesiologue/" target="_blank" rel="noopener noreferrer" className="text-sage-700 underline hover:text-sage-800">@emilie.bechard.kinesiologue</a>
          </li>
        </ul>
      </>
    ),
    pricing: [
      { title: "Séance individuelle", subtitle: "Au cabinet ou en visio", price: "80 €", priceId: "emilie_seance_80" },
      { title: "Programme « Chemin vers moi »", subtitle: "3 mois d'accompagnement", price: "550 €", priceId: "emilie_chemin_vers_moi_550" },
    ],
  },
  {
    slug: "charlotte-cammarata",
    name: "Charlotte Cammarata",
    ville: "Cannes",
    region: "Provence-Alpes-Côte d'Azur",
    image: charlotteImg.url,
    googleAvisUrl: "https://share.google/pHmCokaj4hOPHgiNU",
    googleNote: 5.0,
    googleNombreAvis: 9,
    website: "https://www.chamaste-yoga.com/",
    websiteLabel: "Chamaste Yoga — Site web",
    instagram: "https://www.instagram.com/chamaste.yoga/",
    instagramLabel: "@chamaste.yoga",
    specialties: ["Yoga Hatha", "Vinyasa", "Yoga bienveillant et accessible"],
    experience: "",
    availableFor: ["video"] as Array<"video" | "phone">,
    tags: ["Respiration", "Mobilité", "Renforcement"],
    bioTitle: "Charlotte Cammarata",
    bio: (
      <>
        <p>Pratiquante de yoga depuis 10 ans, je suis formée à l’enseignement du Hatha et du Vinyasa à travers une formation de 200 heures, complétée par 25 heures de formation en souplesse et ajustements. Ces formations m'ont permis d'approfondir mes connaissances autour des postures, de l'alignement, de la mobilité et de l'adaptation de la pratique aux différentes capacités physiques.</p>
        <p>Attachée aux fondements du yoga traditionnel, je développe une approche qui associe mouvement, respiration et conscience corporelle. J'accorde une attention particulière à la précision des postures, à la qualité des mouvements et aux ajustements, afin de proposer une pratique respectueuse du corps.</p>
        <p>À travers mes cours, je souhaite proposer une pratique qui permette à chacun de développer sa force et sa mobilité, en travaillant notamment le renforcement musculaire en profondeur, l'équilibre, la stabilité et l'ancrage. J'accorde également une place essentielle à la respiration, véritable outil pour mieux appréhender le stress, réguler ses émotions et favoriser un équilibre entre le corps et l'esprit.</p>
        <p>Chaque séance est une invitation à réveiller le corps, relâcher les tensions, développer ses capacités physiques et faire le plein d'énergie.</p>
        <p>Ma philosophie repose sur un yoga accessible, progressif et bienveillant, qui s'adapte à chacun, quel que soit son niveau ou son expérience. Pour moi, le tapis est avant tout un espace que l'on s'accorde, où il n'y a rien à réussir ni à prouver, mais simplement à explorer, ressentir et apprendre à mieux connaître son corps.</p>
        <p>Mon intention est de transmettre une pratique dans laquelle chacun peut évoluer à son rythme, dans le respect de ses sensations, de ses possibilités et de ses limites.</p>
        <p className="font-medium text-[#8B4513]">Tarifs et prestations</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Cours privé sur mesure en ligne : 50 €</li>
          <li>Cours privé sur mesure en extérieur : 66 €*</li>
          <li>Cours privé sur mesure à domicile : 88 €*</li>
        </ul>
        <p className="text-xs italic">*Des frais de déplacement peuvent être ajoutés selon la zone.</p>
      </>
    ),
    pricing: [
      // One-time Stripe payments; travel fees are agreed separately where applicable.
      { title: "Cours privé sur mesure", subtitle: "En ligne — Profitez d'une séance personnalisée dans le confort de votre espace, où que vous soyez", price: "50 €", priceId: "charlotte_cours_en_ligne_50" },
      { title: "Cours privé sur mesure", subtitle: "En extérieur — Des frais de déplacement peuvent être ajoutés selon la zone", price: "66 €", priceId: "charlotte_cours_exterieur_66" },
      { title: "Cours privé sur mesure", subtitle: "À domicile — Des frais de déplacement peuvent être ajoutés selon la zone", price: "88 €", priceId: "charlotte_cours_domicile_88" },
    ],
  },
  {
    slug: "camille-chopinot",
    name: "Camille Chopinot",
    ville: "Saint-Sulpice-la-Pointe",
    region: "Occitanie",
    image: camilleImg.url,
    googleAvisUrl: "https://share.google/wVeDBRRTO61hsaVG6",
    googleNote: 5.0,
    googleNombreAvis: 26,
    specialties: [
      "Naturopathe certifié Fena",
      "Magnétiseur",
      "Thérapie psycho-corporelle",
      "Gestion des émotions",
      "Accompagnement mieux-être",
    ],
    experience: "",
    availableFor: ["phone", "video"] as Array<"video" | "phone">,
    tags: ["Émotions", "Fatigue", "Équilibre"],
    bioTitle: "Camille Chopinot",
    bio: (
      <>
        <p className="font-medium text-[#8B4513]">Quelques mots sur mon approche</p>
        <p>
          Je suis convaincu que notre santé est en lien direct avec nos
          émotions. Des émotions négatives, en circulant dans notre corps,
          vont être à l'origine de nombreuses maladies.
        </p>
        <p>
          Je ne traite donc pas uniquement le symptôme, mais je t'accompagne
          dans le processus de réparation de la cause profonde de la maladie
          (« le mal a dit »).
        </p>
        <p>
          Soins énergétiques (magnétiseur, Maître Reiki, coupeur de feu),
          thérapie psycho-corporelle (réparation des mémoires cellulaires),
          Naturopathie : différentes techniques qui vont me permettre
          d'adapter mes soins à ta situation en fonction de tes besoins.
        </p>
        <p>
          De te replacer dans une circulation énergétique, émotionnelle,
          psychologique et physiologique plus fluide, réveiller et dynamiser
          « la force vitale auto-guérisseuse » qui est en toi.
        </p>
        <p>
          Pour te permettre de mieux gérer ton stress, tes émotions, avoir
          plus de confiance en toi et viser une guérison durable.
        </p>
        <p className="font-medium text-[#8B4513]">Prêt(e) à transformer ta vie ?</p>
        <p>
          Première séance de 30 minutes gratuite par téléphone ou en visio
          pour voir si je suis la bonne personne pour vous accompagner.
        </p>
        <p className="font-medium text-[#8B4513]">Tarifs et prestations</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Soins énergétiques : 140 € pour 3 séances.</li>
          <li>
            Soin holistique : 90 € pour 1h30 dédiée à ton mieux-être
            (émotionnel, physique et énergétique).
          </li>
          <li>
            Thérapie brève holistique « Libère ton Potentiel et Retrouve un
            Équilibre Émotionnel » : 850 € avec 50 % de crédit d'impôts, soit
            seulement 425 € pour 10 séances.
          </li>
        </ul>
        <p className="font-medium text-[#8B4513]">Liens utiles</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>
            Site internet :{" "}
            <a href="https://camille-chopinot.fr/" target="_blank" rel="noopener noreferrer" className="text-sage-700 underline hover:text-sage-800">camille-chopinot.fr</a>
          </li>
          <li>
            YouTube :{" "}
            <a href="https://youtube.com/shorts/7Z2UeZ6y35M?si=PxtssV3drVFYvSGs" target="_blank" rel="noopener noreferrer" className="text-sage-700 underline hover:text-sage-800">Voir la vidéo</a>
          </li>
        </ul>
      </>
    ),
    pricing: [
      { title: "Accompagnement mieux-être", subtitle: "1h30", price: "90 €", priceId: "camille_mieux_etre_90" },
      { title: "Thérapie brève équilibre durable", subtitle: "10 séances", price: "850 €", priceId: "camille_therapie_breve_850" },
      { title: "Soins énergétiques", subtitle: "1 heure", price: "60 €", priceId: "camille_soin_energetique_60" },
      { title: "Soins énergétiques", subtitle: "3 séances", price: "140 €", priceId: "camille_soins_energetiques_140" },
    ],
  },
  {
    slug: "sophie-clouet",
    name: "Sophie Clouet",
    ville: "Antibes",
    region: "Provence-Alpes-Côte d'Azur",
    image: sophieImg.url,
    imagePosition: "object-top",
    googleAvisUrl: "https://share.google/UhAQtJt0p08ci2GTC",
    googleNote: 5.0,
    googleNombreAvis: 26,
    specialties: ["Coach santé certifiée RNCP"],
    experience: "",
    availableFor: ["phone", "video"] as Array<"video" | "phone">,
    tags: ["Gestion du stress", "Burn-out", "Post cancer", "Retour emploi post maladie", "Gestion du temps"],
    bioTitle: "Sophie Clouet",
    bio: (
      <>
        <p className="font-medium text-[#8B4513]">Pourquoi je vous propose mon coaching</p>
        <p>
          J'ai eu un parcours riche et varié, avec plusieurs changements de
          carrière. J'ai d'abord été ingénieur en informatique pendant 10 ans
          avant d'effectuer une reconversion dans le monde médical.
        </p>
        <p>
          C'est en 2015 que j'ai donné une nouvelle direction à ma vie en
          choisissant d'accompagner l'humain à travers la maladie.
        </p>
        <p>
          En travaillant auprès de patients mais aussi en observant mes
          collègues à l'hôpital, j'ai vu comment les tensions émotionnelles et
          psychologiques pouvaient se transformer en maux physiques : insomnie,
          douleur, migraine, fatigue chronique…
        </p>
        <p>
          Je suis passée moi-même par ces difficultés, car à force de contenir,
          retenir, ne pas oser dire les choses et m'oublier, je suis arrivée à
          l'épuisement.
        </p>
        <p>
          C'est en comprenant ce lien intime entre stress, santé et affirmation
          de soi que j'ai choisi d'accompagner les personnes, et notamment les
          femmes, à retrouver leur énergie et leur équilibre.
        </p>
        <p>
          <a href="https://www.philo-sophie.fr" target="_blank" rel="noopener noreferrer" className="text-sage-700 underline hover:text-sage-800">www.philo-sophie.fr</a>
        </p>
      </>
    ),
    pricing: [
      { title: "Séance à l'unité", subtitle: "1 heure de coaching", price: "95 €", priceId: "sophie_seance_unite_99" },
      { title: "Séance découverte", subtitle: "1h30 pour découvrir le coaching", price: "115 €", priceId: "sophie_seance_decouverte_115" },
      { title: "Forfait mensuel", subtitle: "2 séances + programme en ligne", price: "250 €/mois", priceId: "sophie_forfait_mensuel_250" },
    ],
  },
  {
    slug: "margaux-derode",
    name: "Margaux Derode",
    ville: "",
    region: "",
    image: margauxImg.url,
    googleAvisUrl: "https://www.google.com/search?q=margaux+derode&ie=UTF-8&oe=UTF-8&hl=fr-ca&client=safari#mpd=~18150297896683651880/customers/reviews",
    googleNote: 5,
    googleNombreAvis: 31,
    instagram: "https://www.instagram.com/margauxderode.sophrologue?vrfl=MWt5a2lsYzZqNzVyZw%3D%3D&utm_source=qr",
    instagramLabel: "@margauxderode.sophrologue",
    specialties: ["Sophrologie & pratiques somatiques", "Anxiété & régulation du système nerveux", "Gestion du stress", "Accompagnement émotionnel", "Accompagnement de l'enfant à domicile"],
    experience: "",
    availableFor: ["video", "phone"] as Array<"video" | "phone">,
    tags: [] as string[],
    bioTitle: "Margaux Derode",
    bio: (
      <>
        <p>Sophrologue certifiée spécialisée dans l’accompagnement de l’anxiété et la régulation du système nerveux. Formée aux pratiques somatiques.</p>
        <p>J’aide les femmes à retrouver un apaisement durable en arrêtant de subir l’anxiété qu’elles ressentent.</p>
        <p>J’accompagne aussi les enfants à apprivoiser leurs émotions.</p>
        <p className="font-medium text-[#8B4513]">Tarifs et prestations</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Stop anxiété : 1 semaine pour souffler — 1 séance d’1h30 + un suivi WhatsApp quotidien sur 1 semaine avec un rendez-vous de 30 min à la fin de l’accompagnement et une routine personnalisée pour continuer après l’accompagnement : 175 €</li>
          <li>Ma sérénité — accompagnement complet de 4 mois (11 séances) pour retrouver un apaisement durable en arrêtant de subir l’anxiété : 1 050 €</li>
          <li>Séance adulte individuelle : 1h30 — 99 €</li>
          <li>Séance enfant individuelle : 1h — 75 €</li>
        </ul>
      </>
    ),
    pricing: [
      { title: "Stop anxiété : 1 semaine pour souffler", subtitle: "1 séance d’1h30 + suivi WhatsApp quotidien + rendez-vous de 30 min", price: "175 €", priceId: "margaux_stop_anxiete_175" },
      { title: "Ma sérénité", subtitle: "Accompagnement complet de 4 mois (11 séances)", price: "1 050 €", priceId: "margaux_ma_serenite_1150" },
      { title: "Séance adulte", subtitle: "Séance individuelle d’1h30", price: "99 €", priceId: "margaux_seance_adulte_105" },
      { title: "Séance enfant", subtitle: "Séance individuelle d’1h", price: "75 €", priceId: "margaux_seance_enfant_75" },
    ],
  },
  {
    slug: "valerie-elineau",
    name: "Valérie Elineau",
    ville: "Saint-Laurent-du-Var",
    region: "Provence-Alpes-Côte d'Azur",
    image: valerieImg.url,
    googleAvisUrl: "https://share.google/Cn0429CnpCeTdwsFa",
    googleNote: 5.0,
    googleNombreAvis: 100,
    specialties: [
      "Sophrologue RNCP",
      "Conseillère en huiles essentielles",
      "Psycho-corporel & émotionnel",
    ],
    experience: "",
    availableFor: ["phone", "video"] as Array<"video" | "phone">,
    tags: ["Désir d'enfant", "Santé de la femme", "Bouleversements et passages de vie"],
    bioTitle: "Valérie Elineau",
    bio: (
      <>
        <p className="font-medium text-[#8B4513]">Retrouver son axe quand la vie nous bouleverse</p>
        <p>
          Il y a des moments où la vie vient bousculer nos repères : séparation,
          deuil, désir d'enfant ou parcours PMA, maternité, changement
          professionnel, épuisement, difficultés relationnelles, perte de sens,
          décision importante…
        </p>
        <p>
          Et parfois, il n'y a même pas d'événement précis. Simplement cette
          sensation que quelque chose ne va plus : le mental tourne en boucle,
          les émotions débordent ou s'éteignent, le corps se tend, l'énergie
          diminue et l'élan de vie s'essouffle.
        </p>
        <p>
          Scientifique de formation et forte d'un parcours de vie qui m'a
          moi-même confrontée à certains de ces bouleversements, j'ai appris que
          nous ne choisissons pas toujours ce qui nous arrive, mais que nous
          pouvons transformer notre manière de le traverser.
        </p>
        <p>
          Depuis 10 ans, j'accompagne ces passages de vie et ces périodes de
          bouleversement à travers une approche globale qui remet en lien la
          tête, le corps, le cœur et l'énergie.
        </p>
        <p>
          Ensemble, nous ne cherchons pas seulement à analyser encore et encore
          le problème. Nous allons aussi créer un espace de solution : comprendre
          ce qui se joue, apaiser et réguler le système nerveux, écouter ce que
          le corps et les émotions expriment, mobiliser vos ressources et
          retrouver progressivement votre axe.
        </p>
        <p>
          Lorsqu'un nouvel alignement se crée intérieurement, il se ressent :
          dans le corps, dans les émotions, dans les choix que l'on pose, dans
          les relations et dans l'élan avec lequel on avance.
        </p>
        <p>
          La sophrologie, la régulation émotionnelle, l'aromathérapie et mes
          différents outils psycho-corporels me permettent d'adapter chaque
          accompagnement à la personne et au moment qu'elle traverse.
        </p>
        <p>
          <span className="font-medium text-[#8B4513]">Ma conviction :</span> ce
          n'est pas que l'absence de problèmes qui fait une vie meilleure. C'est
          aussi la personne que vous devenez pour les traverser.
        </p>
        <p>
          <span className="font-medium text-[#8B4513]">Mon intention :</span>{" "}
          vous aider à ne plus rester enfermé(e) dans ce qui vous arrive, mais à
          retrouver suffisamment de sécurité intérieure, de clarté et de
          mouvement pour redevenir acteur ou actrice de la suite.
        </p>
        <p className="font-medium text-[#8B4513]">Mes tarifs</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>
            Séance individuelle — 1h — 75 € : sophrologie & régulation
            émotionnelle.
          </li>
          <li>
            Séance Boussole « Revenir à mon axe » — 1h30 — 110 € : faire le
            point, comprendre ce qui se joue et retrouver son axe.
          </li>
          <li>
            Parcours Revenir à mon axe — 5 séances de 1h — 350 € : traverser un
            bouleversement et retrouver équilibre & élan.
          </li>
          <li>
            Éveil à la Vie — Projet bébé au naturel & PMA — 4 mois — 890 € :
            accompagnement global du désir d'enfant, naturel ou PMA.
          </li>
        </ul>
      </>
    ),
    pricing: [
      {
        title: "Séance individuelle",
        subtitle: "Sophrologie & régulation émotionnelle — 1h",
        price: "75 €",
        priceId: "valerie_seance_1h_75",
      },
      {
        title: "Séance Boussole — Revenir à mon axe",
        subtitle: "Faire le point, comprendre ce qui se joue et retrouver son axe — 1h30",
        price: "110 €",
        priceId: "valerie_boussole_110",
      },
      {
        title: "Parcours Revenir à mon axe",
        subtitle: "5 séances de 1h — traverser un bouleversement et retrouver équilibre & élan",
        price: "350 €",
        priceId: "valerie_parcours_350",
      },
      {
        title: "Éveil à la Vie",
        subtitle: "Projet bébé au naturel & PMA — accompagnement global sur 4 mois",
        price: "890 €",
        priceId: "valerie_eveil_vie_890",
      },
    ],
  },
  {
    slug: "nathalie-garnier",
    name: "Nathalie Garnier",
    ville: "Saint-Georges-de-Didonne",
    region: "Nouvelle-Aquitaine",
    image: nathalieImg.url,
    specialties: ["Accompagnante bien-être", "Méditation"],
    experience: "",
    availableFor: ["video", "phone"] as Array<"video" | "phone">,
    tags: ["Gestion du stress", "Sommeil", "Anxiété"],
    bioTitle: "Nathalie Garnier",
    bio: (
      <>
        <p className="font-medium text-[#8B4513]">Trouvez l'Harmonie et l'Équilibre Intérieur</p>
        <p>
          Parce que vous traversez un moment particulier de votre vie, vous
          ressentez le besoin d'un accompagnement bienveillant et revitalisant.
          Nos séances holistiques sont conçues pour vous aider à avancer avec
          conscience et sérénité, et à recevoir l'énergie nécessaire pour
          surmonter les passages difficiles ou importants.
        </p>
        <p className="font-medium text-[#8B4513]">Détails du service</p>
        <p>
          Durée : 5 séances hebdomadaires, chacune d'environ 1h (parfois plus
          selon les besoins).
        </p>
        <p>Contenu de chaque séance :</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>
            Soin holistique à distance pour apaiser et harmoniser vos corps
            énergétiques, physiques et émotionnels.
          </li>
          <li>Guidance holistique avec informations et directions concrètes.</li>
          <li>Moment de relaxation et/ou méditation guidée.</li>
          <li>Outils concrets à intégrer dans votre vie quotidienne.</li>
          <li>
            Accès gratuit au groupe de méditation du dimanche matin en direct
            pendant toute la durée de l'accompagnement.
          </li>
          <li>Support téléphonique entre les séances, en cas de besoin.</li>
        </ul>
        <p className="font-medium text-[#8B4513]">Avantages</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Bien-être et sérénité : apaisement profond et harmonie intérieure.</li>
          <li>Guidance personnalisée adaptée à votre situation.</li>
          <li>Support continu tout au long de l'accompagnement.</li>
        </ul>
        <p className="font-medium text-[#8B4513]">Tarification</p>
        <p>5 séances : 250 € (50 € par séance).</p>
        <p>
          <a
            href="https://www.champasak-spa.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sage-700 underline hover:text-sage-800"
          >
            ESPACE BIEN-ÊTRE - CHAMPASAK SPA
          </a>
        </p>
        <p className="font-medium text-[#8B4513]">Réservez votre séance</p>
        <p>
          Je vous propose une première rencontre gratuite, afin d'évaluer
          ensemble si ces séances peuvent vous être bénéfiques.
        </p>
      </>
    ),
    pricing: [
      { title: "Forfait 5 séances", subtitle: "Accompagnement holistique complet", price: "250 €", priceId: "nathalie_forfait_5_250" },
    ],
  },
  {
    slug: "laurence-giudicelli",
    name: "Laurence Giudicelli",
    ville: "Le Cannet",
    region: "Provence-Alpes-Côte d'Azur",
    image: laurenceImg.url,
    imagePosition: "object-top",
    specialties: ["Psychothérapeute (n° RPPS)", "formatrice"],
    experience: "",
    availableFor: ["phone", "video"] as Array<"video" | "phone">,
    tags: ["Art-thérapeute", "Relations/Couple", "Energéticienne", "Qi Cleansing"],
    googleAvisUrl: "https://share.google/W48GgIXCemAX8Yc4O",
    googleNote: 4.8,
    googleNombreAvis: 60,
    bioTitle: "Laurence Giudicelli",
    bio: (
      <>
        <p className="font-medium text-[#8B4513]">Co-fondatrice de Terre de Lune</p>
        <p className="italic">Psychothérapeute – Art-Thérapeute – Formatrice, Membre RPPS (Répertoire Partagé des Professionnels de Santé)</p>
        <p>
          Laurence Giudicelli s'engage pleinement à créer des ponts entre le
          professionnalisme et l'humanité, en veillant à ce que chaque démarche
          soit marquée par une authenticité profonde.
        </p>
        <p>
          Son approche repose sur la conviction que chaque personne mérite une
          attention personnalisée, et elle s'efforce d'apporter un soutien
          continu, empreint de bienveillance et de respect.
        </p>
        <p>
          Elle propose des rendez-vous individuels de psychothérapie analytique et humaniste.
        </p>
        <p>
          Ainsi que des soins énergétiques, afin de débloquer les nœuds émotionnels et d'aider à faire circuler l'énergie vitale à l'intérieur du corps et des organes.
        </p>
        <QiCleansingReveal />
        <p>

          Psychothérapeute psychocorporelle, analytique et énergéticienne pour enfants, adultes, couples et familles.
        </p>
        <p className="font-medium text-[#8B4513]">Tarifs</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Séance adulte : 77 €</li>
          <li>Séance couple / famille : 94 €</li>
          <li>Séance soin Qi cleansing : 121 €</li>
        </ul>
        <p className="font-medium text-[#8B4513]">Sites web</p>
        <p>
          <a href="http://cabinetlg-psy.fr" target="_blank" rel="noopener noreferrer" className="text-sage-700 underline hover:text-sage-800">cabinetlg-psy.fr</a>
          {" — "}
          <a href="https://terredelune.fr" target="_blank" rel="noopener noreferrer" className="text-sage-700 underline hover:text-sage-800">terredelune.fr</a>
        </p>
      </>
    ),
    pricing: [
      { title: "Séance adulte", subtitle: "Psychothérapie individuelle", price: "77 €", priceId: "laurence_seance_adulte_77" },
      { title: "Séance couple / famille", subtitle: "Accompagnement relationnel", price: "94 €", priceId: "laurence_seance_couple_94" },
      { title: "Séance soin Qi cleansing", subtitle: "Soin énergétique", price: "121 €", priceId: "laurence_seance_qi_121" },
    ],
  },
  {
    slug: "clara-regnier",
    name: "Clara Regnier",
    ville: "Menton",
    region: "Provence-Alpes-Côte d'Azur",
    image: claraImg.url,
    imagePosition: "object-top",
    specialties: ["Therapeute holistique", "Formatrice"],
    experience: "",
    availableFor: ["phone", "video"] as Array<"video" | "phone">,
    tags: ["Gestion du stress", "Méditation", "Soins énergétiques"],
    bioTitle: "Clara Regnier",
    bio: (
      <>
        <p className="font-medium text-[#8B4513]">Juste un Instant pour Soi — Clara Regnier</p>
        <p>Envie de Paix, de Joie ? Je vous souhaite la Bienvenue !</p>
        <p>
          On dit que la Vie est faite de rencontres et qu'il n'y a pas de hasard, nous y sommes ! Ce petit clin d'œil de la Vie pour ouvrir le champ des possibles de cette transformation profonde, de se redécouvrir autrement.
        </p>
        <p className="italic">« Et, si j'osais être Heureux ?! »</p>
        <p>
          Comment m'y prendre, étape par étape : En Réharmonisant mes Energies et en Reprogrammant mon système.
        </p>
        <p>
          Les séances, qui vous sont proposées, vont permettre d'effectuer ce rééquilibrage, cette reprogrammation nécessaire afin que l'Energie de Vie puisse circuler de nouveau, là où les lots de souffrances personnelles, transgenerationnelles, les émotions et traumatismes ont été cristallisés.
        </p>
        <p>Ces thérapies sont dites courtes.</p>
        <p>
          Le but étant que vous retrouviez rapidement vos ressources et votre Joie, qui vous attend !
        </p>
        <p>
          Je vous accompagne — C'est juste un instant pour soi, Clara Regnier, Thérapeute Holistique et Enseignante de Méditation.
        </p>
        <p className="italic text-sm">
          Cet accompagnement ne remplace en aucun cas un suivi médical.
        </p>
        <p className="font-medium text-[#8B4513]">Tarifs</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>30 minutes Boost Relaxation séance énergétique : 45 €</li>
          <li>Réharmonisation énergétique avec reprogrammation cellulaire, coaching : 110 €</li>
          <li>Séance de suivi, coaching : 90 €</li>
        </ul>
        <p className="font-medium text-[#8B4513]">Formation</p>
        <p>Sur devis</p>
      </>
    ),
    pricing: [
      { title: "Boost Relaxation 30 min", subtitle: "Séance énergétique", price: "45 €", priceId: "clara_boost_relaxation_45" },
      { title: "Réharmonisation énergétique", subtitle: "Avec reprogrammation cellulaire et coaching", price: "110 €", priceId: "clara_reharmonisation_110" },
      { title: "Séance de suivi", subtitle: "Coaching", price: "90 €", priceId: "clara_suivi_90" },
    ],
  },
  {
    slug: "oceane-danjon",
    name: "Océane Danjon",
    ville: "Le Cannet",
    region: "Provence-Alpes-Côte d'Azur",
    image: oceaneImg.url,
    imagePosition: "object-top",
    googleAvisUrl: "https://share.google/GRDNWSMcHjsju4dr3",
    googleNote: 5.0,
    googleNombreAvis: 32,
    specialties: ["Accompagnement psycho-corporel, systémique et créatif"],
    experience: "",
    availableFor: ["phone", "video"] as Array<"video" | "phone">,
    tags: ["Régulation corporelle", "Dynamique relationnelle"],
    bioTitle: "Océane Danjon – Odyssée",
    bio: (
      <>
        <p className="font-medium text-[#8B4513]">Co-fondatrice de Terre de Lune – Odyssée</p>
        <p className="italic">
          Accompagnement psycho-corporel, systémique et créatif
        </p>
        <p>
          Depuis plus de 10 ans, j'accompagne les personnes en quête de transformation personnelle à travers une approche globale qui relie le corps, les émotions, les relations et l'histoire de vie.
        </p>
        <p>
          Je propose des séances individuelles, des parcours d'accompagnement approfondis, des ateliers de groupe et des retraites immersives, destinés aux adultes souhaitant retrouver du sens, dépasser des schémas limitants et développer un meilleur alignement avec eux-mêmes.
        </p>
        <p>
          Mon approche est systémique, incarnée et expérientielle : elle prend en compte la personne dans sa globalité afin de favoriser des changements concrets, durables et profondément intégrés.
        </p>
        <p className="font-medium text-[#8B4513]">Contact</p>
        <p>Villa Serena – Le Cannet</p>
        <p>06 09 28 90 95</p>
      </>
    ),
    pricing: [
      { title: "Accompagnement psycho-corporel", subtitle: "Séance individuelle 1 heure", price: "77 €", priceId: "oceane_psycho_corporel_77" },
    ],
  },
  {
    slug: "jacqui-syndercombe",
    name: "Jacqui Syndercombe",
    ville: "",
    region: "",
    image: jacquiImg.url,
    specialties: ["Coach systémique", "Leadership", "RSE", "Conseil organisationnel", "Coaching d'équipe", "Ateliers et formations"],
    experience: "",
    availableFor: ["video", "phone"] as Array<"video" | "phone">,
    tags: ["Leadership", "Transformation", "Alignement"],
    bioTitle: "Jacqui Syndercombe",
    website: "https://www.syndercombe.com",
    websiteLabel: "Cabinet de coaching à Nice | Contactez-moi dès à présent",
    linkedin: "https://www.linkedin.com/in/jacqui-syndercombe",
    linkedinLabel: "Jacqueline Syndercombe | LinkedIn",
    certification: "Professional Certified Leadership, Organisational & Team Coach PCC, ITCA",
    bio: (
      <>
        <p>
          Jacqui est coach systémique auprès des dirigeants, des équipes et des organisations. Elle accompagne des personnes et des équipes qui souhaitent évoluer ou progresser dans des environnements multinationaux complexes.
        </p>
        <p>
          Forte de plus de 25 ans d'expérience en entreprise, dans des fonctions financières et administratives, elle connaît bien les pressions auxquelles les salariés sont confrontés aujourd'hui : concilier performance et attentes des parties prenantes, tout en faisant face à des changements permanents et à des restructurations qui n'en finissent pas.
        </p>
        <p>
          Jacqui a constaté que développer ses propres compétences, ou celles de ses équipes, ne suffit pas toujours. On peut malgré tout se heurter à un mur, car personne n'évolue en vase clos. La manière dont nous interagissons avec nous-mêmes, avec les autres et avec les systèmes dans lesquels nous évoluons a un impact sur nous, tout comme nous avons un impact sur eux.
        </p>
        <p>
          C'est pourquoi elle s'appuie sur l'approche systémique, qui permet à ses clients de comprendre leur écosystème : les relations et les connexions qui facilitent ou freinent ce qu'ils cherchent à accomplir. Lorsqu'ils voient clairement ce qui relève de leur contrôle et où concentrer leur attention, ils gagnent du temps, de l'énergie et s'épargnent des efforts inutiles. Ils peuvent ainsi s'épanouir dans leur vie personnelle et professionnelle sans aller jusqu'au burn-out.
        </p>
        <p className="font-medium text-[#8B4513]">Cet accompagnement est-il fait pour vous ?</p>
        <p>
          Vous êtes salarié(e) et souhaitez investir dans votre avenir en développant vos compétences à titre personnel, sans passer par votre organisation, afin de :
        </p>
        <ul className="list-disc pl-5 space-y-1">
          <li>mieux gérer votre charge de travail et améliorer votre qualité de vie ;</li>
          <li>franchir la prochaine étape de votre carrière ou accéder à un poste de leadership ;</li>
          <li>identifier vos leviers de changement ;</li>
          <li>mieux gérer la complexité et l'incertitude en entreprise ;</li>
          <li>passer du contrôle à l'influence ;</li>
          <li>renforcer votre présence et votre impact en tant que leader ;</li>
          <li>gérer les conflits efficacement ;</li>
          <li>construire des relations solides et efficaces ;</li>
          <li>composer avec les enjeux de RSE ;</li>
          <li>mobiliser et fédérer vos collègues et vos pairs.</li>
        </ul>
        <p>
          Prenez contact avec Jacqui pour un premier échange sans engagement.
        </p>
        <p>
          Elle travaille en français et en anglais.
        </p>
        <p className="font-medium text-[#8B4513]">Tarifs et prestations</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Séance individuelle : 150 € TTC l'heure</li>
        </ul>
      </>
    ),
    pricing: [
      { title: "Séance individuelle", subtitle: "1 heure", price: "150 €", priceId: "jacqui_seance_individuelle_150" },
    ],
  },
];
