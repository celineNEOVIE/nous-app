export const Footer = () => {
  return (
    <footer className="w-full border-t border-[#E3E9E3] bg-[#F5F0E6]/90 py-6 px-4 mt-12">
      <p className="text-center text-xs text-[#A0522D]">
        © 2026 Noûs™ est une marque déposée à l'INPI (n° 26 5269449).
      </p>
    </footer>
  );
};