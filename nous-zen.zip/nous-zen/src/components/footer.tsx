export const Footer = () => {
  return (
    <footer className="w-full border-t border-[#E3E9E3] bg-[#F5F0E6]/90 py-6 px-4 mt-12">
      <div className="max-w-3xl mx-auto">
        <p className="text-center text-xs text-[#A0522D]">
          *Crédit d'impôt de 50 % des sommes versées au titre des services à la personne (art. 199 sexdecies du CGI), dans les conditions et limites prévues par la loi.
        </p>
        <p className="text-center text-xs text-[#A0522D] mt-1.5">
          © 2026 Noûs® — marque enregistrée à l'INPI (n° 26 5269449).
        </p>
      </div>
    </footer>
  );
};
