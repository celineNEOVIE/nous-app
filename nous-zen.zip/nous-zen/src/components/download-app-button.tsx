import { useEffect, useState } from "react";
import { trackAppDownload } from "@/lib/track-app-download";

const APP_STORE_URL = "https://apps.apple.com/app/id6785034254";
const PLAY_STORE_URL = "https://play.google.com/store/apps/details?id=fr.app.nous";

type Platform = "ios" | "android" | "desktop";

function detectPlatform(): Platform {
  if (typeof window === "undefined" || !navigator?.userAgent) return "desktop";
  const ua = navigator.userAgent;
  if (/iPad|iPhone|iPod/.test(ua)) return "ios";
  if (/Android/.test(ua)) return "android";
  return "desktop";
}

function AppleIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      className={className}
      aria-hidden="true"
    >
      <path d="M17.3 8.5c-.1 0-.2 0-.3.1-.6.3-1.3.5-2 .5-1 0-1.9-.4-2.6-1-.1-.1-.2-.1-.3 0-.7.6-1.6 1-2.6 1-.7 0-1.4-.2-2-.5-.1 0-.2-.1-.3-.1-.8 0-1.5.3-2.1.8-.6.5-1 1.2-1.1 2-.1.8.1 1.6.6 2.2.5.7 1.2 1.1 2 1.2.2 0 .3 0 .4-.1.5-.3 1.1-.4 1.7-.4 1 0 1.9.4 2.6 1 .1.1.2.1.3 0 .7-.6 1.6-1 2.6-1 .6 0 1.2.1 1.7.4.1.1.3.1.4.1.8-.1 1.5-.5 2-1.2.5-.7.7-1.4.6-2.2-.1-.8-.5-1.5-1.1-2-.6-.5-1.3-.8-2.1-.8zM12.5 6.5c.1-1.2-.4-2.3-1.3-3.1-.9-.8-2.1-1.1-3.3-.8-.1 1.2.4 2.3 1.3 3.1.9.8 2.1 1.1 3.3.8z" />
    </svg>
  );
}

function PlayIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      className={className}
      aria-hidden="true"
    >
      <path d="M4 2.5v19l15.5-9.5L4 2.5z" />
    </svg>
  );
}

export const DownloadAppButton = () => {
  const [platform, setPlatform] = useState<Platform>("desktop");

  useEffect(() => {
    setPlatform(detectPlatform());
  }, []);

  const baseClasses =
    "inline-flex items-center justify-center rounded-lg border border-sage-300 bg-sage-200 text-sage-700 transition-colors hover:bg-sage-300 active:bg-sage-300";

  if (platform === "ios") {
    return (
      <a
        href={APP_STORE_URL}
        target="_blank"
        rel="noopener noreferrer"
        onClick={() => trackAppDownload("ios")}
        className={`${baseClasses} px-3 py-1.5 text-xs font-medium whitespace-nowrap`}
      >
        Télécharger l'appli
      </a>
    );
  }

  if (platform === "android") {
    return (
      <a
        href={PLAY_STORE_URL}
        target="_blank"
        rel="noopener noreferrer"
        onClick={() => trackAppDownload("android")}
        className={`${baseClasses} px-3 py-1.5 text-xs font-medium whitespace-nowrap`}
      >
        Télécharger l'appli
      </a>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <a
        href={APP_STORE_URL}
        target="_blank"
        rel="noopener noreferrer"
        onClick={() => trackAppDownload("ios")}
        className={`${baseClasses} h-9 w-9`}
        aria-label="Télécharger sur l'App Store"
      >
        <AppleIcon className="h-4 w-4" />
      </a>
      <a
        href={PLAY_STORE_URL}
        target="_blank"
        rel="noopener noreferrer"
        onClick={() => trackAppDownload("android")}
        className={`${baseClasses} h-9 w-9`}
        aria-label="Télécharger sur Google Play"
      >
        <PlayIcon className="h-4 w-4" />
      </a>
    </div>
  );
};
