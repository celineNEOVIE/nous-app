export const PlaneBanner = () => {
  return null;
};
