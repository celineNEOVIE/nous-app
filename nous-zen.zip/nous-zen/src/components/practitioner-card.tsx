import { useEffect, useId, useState, type FormEvent, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { trackEventOnce } from "@/lib/track-event";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "@/components/ui/use-toast";
import { PhoneCall, PhoneCallIcon, Video, Euro, CreditCard, Eye, Percent, X, Building2 } from "lucide-react";
import { StripeEmbeddedCheckout } from "@/components/stripe-embedded-checkout";
import { ImageWithFallback } from "@/components/image-with-fallback";
import { supabase } from "@/integrations/supabase/client";
import { trackPractitionerClick } from "@/lib/track-app-download";

interface PricingItem {
  title: string;
  subtitle: string;
  price: string;
  priceId?: string;
}

interface PractitionerCardProps {
  name: string;
  image: string;
  specialties: string[];
  experience: string;
  availableFor: Array<"video" | "phone">;
  tags?: string[];
  bio?: ReactNode;
  bioTitle?: string;
  pricing?: PricingItem[];
  imagePosition?: string;
  googleAvisUrl?: string;
  googleNote?: number;
  googleNombreAvis?: number;
}

const MOMENTS = [
  { id: "morning", label: "Matin" },
  { id: "afternoon", label: "Après-midi" },
  { id: "evening", label: "Soir" },
] as const;

const DAYS = [
  { id: "mon", label: "Lundi" },
  { id: "tue", label: "Mardi" },
  { id: "wed", label: "Mercredi" },
  { id: "thu", label: "Jeudi" },
  { id: "fri", label: "Vendredi" },
  { id: "sat", label: "Samedi" },
  { id: "sun", label: "Dimanche" },
] as const;

interface PractitionerModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
  children: ReactNode;
  className?: string;
}

const PractitionerModal = ({
  open,
  onOpenChange,
  title,
  description,
  children,
  className = "",
}: PractitionerModalProps) => {
  const titleId = useId();
  const descriptionId = useId();
  const [openCycle, setOpenCycle] = useState(0);

  useEffect(() => {
    if (!open) return;
    setOpenCycle((cycle) => cycle + 1);
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onOpenChange(false);
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [open, onOpenChange]);

  if (!open || typeof document === "undefined") return null;

  return createPortal(
    <div
      key={openCycle}
      className="fixed inset-0 z-50 overflow-y-scroll bg-black/80 px-2 py-2 sm:px-4 sm:py-8"
      style={{
        height: "100dvh",
        minHeight: "100vh",
        WebkitOverflowScrolling: "touch",
        overscrollBehaviorY: "contain",
        touchAction: "pan-y",
      }}
      onClick={() => onOpenChange(false)}
    >
      <div
        role="dialog"
        aria-modal="false"
        aria-labelledby={titleId}
        aria-describedby={description ? descriptionId : undefined}
        className={`relative z-50 mx-auto grid w-full max-w-lg gap-4 border bg-background p-6 shadow-lg sm:rounded-lg ${className}`}
        style={{ touchAction: "pan-y" }}
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex flex-col space-y-1.5 text-center sm:text-left">
          <h2 id={titleId} className="text-lg font-semibold leading-none tracking-tight">
            {title}
          </h2>
          {description && (
            <p id={descriptionId} className="text-sm text-muted-foreground">
              {description}
            </p>
          )}
        </div>
        {children}
        <button
          type="button"
          onClick={() => onOpenChange(false)}
          className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
          aria-label="Fermer"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>,
    document.body,
  );
};

export const PractitionerCard = ({
  name,
  image,
  specialties,
  experience,
  availableFor,
  tags = [],
  bio,
  bioTitle,
  pricing,
  imagePosition = "object-top",
  googleAvisUrl,
  googleNote,
  googleNombreAvis,
}: PractitionerCardProps) => {
  const [open, setOpen] = useState(false);
  const [bioOpen, setBioOpen] = useState(false);
  const [pricingOpen, setPricingOpen] = useState(false);
  const [checkoutPriceId, setCheckoutPriceId] = useState<string | null>(null);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [moments, setMoments] = useState<string[]>([]);
  const [days, setDays] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const openBio = () => {
    if (!bio) return;
    trackPractitionerClick(name, specialties[0]);
    setBioOpen(true);
  };

  const openGoogleReviews = () => {
    if (!googleAvisUrl) return;
    trackEventOnce("clic_avis_google");
    const capBrowser = (window as any)?.Capacitor?.Plugins?.Browser;
    if (capBrowser?.open) {
      capBrowser.open({ url: googleAvisUrl });
      return;
    }
    window.open(googleAvisUrl, "_blank", "noopener,noreferrer");
  };

  const toggle = (
    value: string,
    list: string[],
    setList: (v: string[]) => void,
  ) => {
    setList(list.includes(value) ? list.filter((v) => v !== value) : [...list, value]);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const { error } = await supabase.functions.invoke("request-callback", {
        body: {
          praticienName: name,
          firstName,
          lastName,
          phone,
          email,
          moments,
          days,
        },
      });
      if (error) throw error;
      toast({
        title: "Demande envoyée",
        description: `Merci ${firstName}, nous vous recontacterons rapidement.`,
      });
      setOpen(false);
      setFirstName("");
      setLastName("");
      setPhone("");
      setEmail("");
      setMoments([]);
      setDays([]);
    } catch (err) {
      console.error(err);
      toast({
        title: "Erreur",
        description: "Impossible d'envoyer la demande. Réessayez plus tard.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card className="overflow-hidden" style={{ boxShadow: "0 8px 24px rgba(60, 40, 25, 0.18)" }}>
      <CardHeader className="border-b border-[#E3E9E3] p-0">
        <div
          role={bio ? "button" : undefined}
          tabIndex={bio ? 0 : undefined}
          onClick={openBio}
          onKeyDown={(event) => {
            if (bio && (event.key === "Enter" || event.key === " ")) {
              event.preventDefault();
              openBio();
            }
          }}
          className={`relative w-full aspect-[4/3] overflow-hidden block group ${bio ? "cursor-pointer" : "cursor-default"}`}
          aria-label={bio ? `Voir la fiche de ${name}` : name}
        >
          <ImageWithFallback
            alt={name}
            className={`absolute inset-0 object-cover w-full h-full ${imagePosition} transition-transform duration-500 group-hover:scale-105`}
            src={image}
            loading="eager"
          />
          <div className="absolute top-2 left-2 bg-[#5C4033]/80 text-[#F5F0E6] text-xs font-medium px-2.5 py-1 rounded-full flex items-center gap-1.5 backdrop-blur-sm pointer-events-none z-10 shadow-sm">
            <Percent className="w-3.5 h-3.5" />
            Crédit d'impôt 50%
          </div>
          {googleAvisUrl && typeof googleNombreAvis === "number" && (
            <button
              type="button"
              onClick={(event) => {
                event.stopPropagation();
                openGoogleReviews();
              }}
              className="absolute bottom-2 left-2 z-10 flex items-center gap-1.5 rounded-full bg-[#3D2C21]/75 px-2.5 py-1 text-xs font-semibold text-[#F5F0E6] shadow-sm hover:underline"
              aria-label={
                typeof googleNote === "number"
                  ? `Voir les ${googleNombreAvis} avis Google, note ${googleNote.toFixed(1).replace(".", ",")}`
                  : `Voir les ${googleNombreAvis} avis Google`
              }
            >
              {typeof googleNote === "number" ? (
                <>
                  <span className="text-[#F59E0B]">★</span>
                  <span>{googleNote.toFixed(1).replace(".", ",")}</span>
                  <span>· {googleNombreAvis} avis Google</span>
                </>
              ) : (
                <span>{googleNombreAvis} avis Google</span>
              )}
            </button>
          )}
          {bio && (
            <>
              <div className="absolute bottom-2 right-2 bg-[#5C4033]/80 text-[#F5F0E6] text-xs font-medium px-2.5 py-1 rounded-full flex items-center gap-1.5 backdrop-blur-sm pointer-events-none z-10 transition-opacity duration-300 group-hover:opacity-0 shadow-sm">
                <Eye className="w-3.5 h-3.5" />
                Voir le profil
              </div>
              <div className="absolute inset-0 bg-[#5C4033]/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center pointer-events-none">
                <span className="text-[#F5F0E6] font-medium flex items-center gap-2 drop-shadow-md">
                  <Eye className="w-5 h-5" />
                  Voir le profil
                </span>
              </div>
            </>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <h3
          className={`mb-2 text-xl font-semibold text-[#8B4513] ${bio ? "cursor-pointer hover:underline" : ""}`}
          onClick={openBio}
        >
          {name}
        </h3>
        {experience && <p className="mb-4 text-sm text-[#A0522D]">{experience}</p>}
        <div className="flex flex-wrap gap-2 mb-4">
          {specialties.map((specialty) => (
            <Badge
              key={specialty}
              variant="outline"
              className="bg-sage-200 text-sage-700 border-sage-300 hover:bg-sage-300"
            >
              {specialty}
            </Badge>
          ))}
        </div>
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {tags.map((tag) => (
              <Badge
                key={tag}
                variant="outline"
                className="bg-sage-200 text-sage-700 border-sage-300 hover:bg-sage-300"
              >
                {tag}
              </Badge>
            ))}
          </div>
        )}
        <div className="flex gap-2">
          {availableFor.includes("video") && (
            <Badge variant="outline" className="bg-sage-50 text-sage-700 border-sage-200">
              <Video className="w-3 h-3 mr-1" />
              Visio
            </Badge>
          )}
          {availableFor.includes("phone") && (
            <Badge variant="outline" className="bg-sage-50 text-sage-700 border-sage-200">
              <PhoneCall className="w-3 h-3 mr-1" />
              Téléphone
            </Badge>
          )}
          <Badge variant="outline" className="bg-sage-50 text-sage-700 border-sage-200">
            <Building2 className="w-3 h-3 mr-1" />
            Cabinet
          </Badge>
        </div>
        <Button
          type="button"
          onClick={() => setOpen(true)}
          className="w-full mt-4 bg-sage-600 hover:bg-sage-700 text-white"
        >
          <PhoneCallIcon className="w-4 h-4 mr-2" />
          Être rappelé
        </Button>
        <PractitionerModal
          open={open}
          onOpenChange={setOpen}
          title={<>Être rappelé par {name}</>}
          description="Indiquez vos coordonnées et vos préférences de créneaux."
          className="mobile-scroll-dialog sm:max-w-md"
        >
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor={`firstName-${name}`}>Prénom</Label>
                  <Input
                    id={`firstName-${name}`}
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    maxLength={60}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor={`lastName-${name}`}>Nom</Label>
                  <Input
                    id={`lastName-${name}`}
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    maxLength={60}
                    required
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor={`phone-${name}`}>Numéro de téléphone</Label>
                <Input
                  id={`phone-${name}`}
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  pattern="[0-9 +().-]{6,20}"
                  maxLength={20}
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor={`email-${name}`}>Adresse email</Label>
                <Input
                  id={`email-${name}`}
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  maxLength={255}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Moments préférés</Label>
                <div className="flex flex-wrap gap-3">
                  {MOMENTS.map((m) => (
                    <label key={m.id} className="flex items-center gap-2 text-sm">
                      <Checkbox
                        checked={moments.includes(m.id)}
                        onCheckedChange={() => toggle(m.id, moments, setMoments)}
                      />
                      {m.label}
                    </label>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Jours préférés</Label>
                <div className="flex flex-wrap gap-3">
                  {DAYS.map((d) => (
                    <label key={d.id} className="flex items-center gap-2 text-sm">
                      <Checkbox
                        checked={days.includes(d.id)}
                        onCheckedChange={() => toggle(d.id, days, setDays)}
                      />
                      {d.label}
                    </label>
                  ))}
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                Nous vous recontacterons dans les meilleurs délais pour convenir
                d'un rendez-vous avec ce praticien.
              </p>
              <div className="flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2">
                <Button type="submit" disabled={submitting} className="bg-sage-600 hover:bg-sage-700 text-white">
                  {submitting ? "Envoi…" : "Envoyer ma demande"}
                </Button>
              </div>
            </form>
        </PractitionerModal>
        <Button
          type="button"
          variant="outline"
          onClick={() => setPricingOpen(true)}
          className="w-full mt-2 border-sage-300 text-sage-700 hover:bg-sage-50"
        >
          <Euro className="w-4 h-4 mr-2" />
          Tarifs
        </Button>
        <PractitionerModal
          open={pricingOpen}
          onOpenChange={setPricingOpen}
          title={<>Tarifs — {name}</>}
          description="Séances d'accompagnements en visio, par téléphone ou en présentiel."
          className="mobile-scroll-dialog sm:max-w-md"
        >
            <div className="space-y-3">
              {pricing ? (
                pricing.map((item) => (
                  <button
                    key={item.title}
                    type="button"
                    onClick={() => {
                      if (item.priceId) {
                        setCheckoutPriceId(item.priceId);
                        setPricingOpen(false);
                      } else {
                        toast({
                          title: "Paiement bientôt disponible",
                          description: "Le paiement Stripe sera activé prochainement.",
                        });
                      }
                    }}
                    className="w-full flex items-center justify-between rounded-lg border border-sage-200 bg-sage-50/50 p-4 text-left hover:bg-sage-50 transition-colors"
                  >
                    <div className="min-w-0 pr-3">
                      <p className="font-medium text-[#5C4033]">{item.title}</p>
                      <p className="text-xs text-[#A0522D]">{item.subtitle}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-lg font-semibold text-sage-700 whitespace-nowrap">{item.price}</span>
                      <CreditCard className="w-4 h-4 text-sage-600 shrink-0" />
                    </div>
                  </button>
                ))
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      toast({
                        title: "Paiement bientôt disponible",
                        description: "Le paiement Stripe sera activé prochainement.",
                      });
                    }}
                    className="w-full flex items-center justify-between rounded-lg border border-sage-200 bg-sage-50/50 p-4 text-left hover:bg-sage-50 transition-colors"
                  >
                    <div className="min-w-0 pr-3">
                      <p className="font-medium text-[#5C4033]">Séance 30 minutes</p>
                      <p className="text-xs text-[#A0522D]">Idéale pour une pause ressourçante</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-lg font-semibold text-sage-700 whitespace-nowrap">45 €</span>
                      <CreditCard className="w-4 h-4 text-sage-600 shrink-0" />
                    </div>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      toast({
                        title: "Paiement bientôt disponible",
                        description: "Le paiement Stripe sera activé prochainement.",
                      });
                    }}
                    className="w-full flex items-center justify-between rounded-lg border border-sage-200 bg-sage-50/50 p-4 text-left hover:bg-sage-50 transition-colors"
                  >
                    <div className="min-w-0 pr-3">
                      <p className="font-medium text-[#5C4033]">Séance 60 minutes</p>
                      <p className="text-xs text-[#A0522D]">Accompagnement complet</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-lg font-semibold text-sage-700 whitespace-nowrap">75 €</span>
                      <CreditCard className="w-4 h-4 text-sage-600 shrink-0" />
                    </div>
                  </button>
                </>
              )}
              <p className="text-xs text-muted-foreground pt-2">
                Paiement sécurisé par Stripe. 50% de crédit d'impôt selon l'article 199 sexdecies du CGI. Vérifiez votre éligibilité.
              </p>
            </div>
        </PractitionerModal>
        {bio && (
          <PractitionerModal
            open={bioOpen}
            onOpenChange={setBioOpen}
            title={bioTitle ?? name}
            className="mobile-scroll-dialog sm:max-w-lg"
          >
              <div className="text-sm text-[#5C4033] space-y-3 leading-relaxed">
                {bio}
              </div>
          </PractitionerModal>
        )}
        <PractitionerModal
          open={!!checkoutPriceId}
          onOpenChange={(nextOpen) => {
            if (!nextOpen) setCheckoutPriceId(null);
          }}
          title="Paiement sécurisé"
          description="Paiement traité par Stripe. Aucune donnée bancaire ne transite par notre site."
          className="mobile-scroll-dialog sm:max-w-2xl"
        >
            {checkoutPriceId && <StripeEmbeddedCheckout priceId={checkoutPriceId} />}
        </PractitionerModal>
      </CardContent>
    </Card>
  );
};
