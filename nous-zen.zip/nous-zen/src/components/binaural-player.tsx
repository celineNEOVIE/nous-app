import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Play, Pause, Loader2 } from "lucide-react";
import { trackEventOnce } from "@/lib/track-event";

/**
 * Robust cross-platform audio player for binaural tracks.
 *
 * Native iOS/Android WKWebView often ignores <audio controls preload="metadata">
 * when the source is a cross-origin CDN (silent Range-request failure inside a
 * modal, controls stay inert). We drive playback with `new Audio()` created on
 * the user's tap, which satisfies the user-gesture requirement and gives
 * explicit loading / error feedback.
 */
export function BinauralPlayer({ src, title }: { src: string; title: string }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [state, setState] = useState<"idle" | "loading" | "playing" | "error">("idle");
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const wantsPlayRef = useRef(false);

  useEffect(() => {
    return () => {
      audioRef.current?.pause();
      audioRef.current = null;
    };
  }, []);

  const formatTime = (s: number) => {
    if (!isFinite(s)) return "0:00";
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60).toString().padStart(2, "0");
    return `${m}:${sec}`;
  };

  const handleToggle = async () => {
    const isStarting = !audioRef.current || audioRef.current.paused;
    if (isStarting) trackEventOnce("lecture_son_binaural");
    if (audioRef.current) {
      if (audioRef.current.paused) {
        // Already-created element: if buffer isn't ready yet, wait for canplay.
        wantsPlayRef.current = true;
        if (audioRef.current.readyState < 3) {
          setState("loading");
          return;
        }
        try {
          await audioRef.current.play();
          setState("playing");
        } catch {
          // Rejected because not ready — wait for canplay to retry.
          setState("loading");
        }
      } else {
        wantsPlayRef.current = false;
        audioRef.current.pause();
        setState("idle");
      }
      return;
    }

    setState("loading");
    wantsPlayRef.current = true;
    const audio = new Audio();
    audio.preload = "auto";
    // iOS WKWebView requires playsInline for programmatic playback in modals
    audio.setAttribute("playsinline", "");
    audio.setAttribute("webkit-playsinline", "");
    audio.src = src;
    audioRef.current = audio;

    audio.addEventListener("loadedmetadata", () => setDuration(audio.duration));
    audio.addEventListener("timeupdate", () => setCurrent(audio.currentTime));
    audio.addEventListener("ended", () => {
      wantsPlayRef.current = false;
      setState("idle");
      setCurrent(0);
    });
    audio.addEventListener("error", () => setState("error"));
    const tryPlay = async () => {
      if (!wantsPlayRef.current || !audioRef.current) return;
      try {
        await audioRef.current.play();
        setState("playing");
      } catch {
        // Will retry on the next canplay/canplaythrough tick.
      }
    };
    audio.addEventListener("canplay", tryPlay);
    audio.addEventListener("canplaythrough", tryPlay);
    // Kick the network on platforms that defer preload="auto".
    try { audio.load(); } catch { /* noop */ }

    // Optimistic first attempt; if the buffer isn't ready the promise rejects
    // and the canplay listener above will retry automatically.
    try {
      await audio.play();
      setState("playing");
    } catch {
      // Stay in "loading" — retry will happen on canplay.
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = Number(e.target.value);
    if (audioRef.current && isFinite(v)) {
      audioRef.current.currentTime = v;
      setCurrent(v);
    }
  };

  const progressMax = duration || 1;

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <Button
          type="button"
          onClick={handleToggle}
          disabled={state === "loading"}
          aria-label={state === "playing" ? `Mettre en pause ${title}` : `Lire ${title}`}
          className="h-12 w-12 rounded-full bg-sage-500 hover:bg-sage-600 text-white flex items-center justify-center shrink-0 p-0"
        >
          {state === "loading" ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : state === "playing" ? (
            <Pause className="h-5 w-5" fill="currentColor" />
          ) : (
            <Play className="h-5 w-5 ml-0.5" fill="currentColor" />
          )}
        </Button>
        <div className="flex-1 min-w-0">
          <input
            type="range"
            min={0}
            max={progressMax}
            step={0.1}
            value={Math.min(current, progressMax)}
            onChange={handleSeek}
            aria-label="Position de lecture"
            className="w-full accent-sage-600"
          />
          <div className="flex justify-between text-xs text-[#8B4513] mt-1">
            <span>{formatTime(current)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>
      </div>
      {state === "error" && (
        <p className="text-xs text-red-600">
          Impossible de lire l'audio. Vérifie ta connexion et réessaie.
        </p>
      )}
    </div>
  );
}
