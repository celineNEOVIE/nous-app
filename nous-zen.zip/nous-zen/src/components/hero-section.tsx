import { useEffect, useRef, useState } from "react";
import { ImageWithFallback } from "@/components/image-with-fallback";
import logoAsset from "@/assets/logo-nous-simple.png.asset.json";
import mascotteVideo from "@/assets/mascotte_pastille_carree.mp4.asset.json";
import { resolveAssetUrl } from "@/lib/asset-url";

const MASCOT_GREETING_KEY = "nous_mascot_greeting_seen";

export const HeroSection = ({ greetingEnabled = true }: { greetingEnabled?: boolean }) => {
  const [showGreeting, setShowGreeting] = useState(false);
  const greetingRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!greetingEnabled) return;

    try {
      if (localStorage.getItem(MASCOT_GREETING_KEY) === "1") return;
      localStorage.setItem(MASCOT_GREETING_KEY, "1");
    } catch {
      // Continue to show the greeting when storage is unavailable.
    }

    setShowGreeting(true);

    const hideTimer = window.setTimeout(() => {
      setShowGreeting(false);
    }, 5500);

    const handleOutsideClick = (event: PointerEvent) => {
      const target = event.target;
      if (target instanceof Node && !greetingRef.current?.contains(target)) {
        setShowGreeting(false);
      }
    };

    document.addEventListener("pointerdown", handleOutsideClick);

    return () => {
      window.clearTimeout(hideTimer);
      document.removeEventListener("pointerdown", handleOutsideClick);
    };
  }, [greetingEnabled]);

  return (
    <section className="relative overflow-hidden bg-[#F5F0E6]">
      <div className="container px-4 pt-4 pb-7 mx-auto sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="sr-only">
            Noûs — Votre accompagnement bien-être et santé holistique
          </h1>
          <div className="-my-8 text-center sm:-my-10">
            <div className="relative inline-block">
              <ImageWithFallback
                src={logoAsset.url}
                alt="Noûs Logo et Tagline"
                className="h-40 w-auto sm:h-48"
                loading="eager"
                fetchPriority="high"
                width={192}
                height={192}
              />
              <div
                className="absolute right-full top-1/2 mr-3 h-[88px] w-[88px] -translate-y-1/2 overflow-visible rounded-full sm:h-24 sm:w-24"
              >
                <div
                  className="h-full w-full rounded-full"
                  aria-hidden="true"
                  style={{
                    background: "radial-gradient(circle, #F5F0E6 40%, transparent 100%)",
                    WebkitMaskImage:
                      "radial-gradient(circle, rgba(0,0,0,1) 52%, rgba(0,0,0,0) 78%)",
                    maskImage:
                      "radial-gradient(circle, rgba(0,0,0,1) 52%, rgba(0,0,0,0) 78%)",
                  }}
                >
                  <video
                    src={resolveAssetUrl(mascotteVideo.url)}
                    autoPlay
                    muted
                    loop
                    playsInline
                    className="h-full w-full object-cover"
                  />
                </div>
                {showGreeting && (
                  <div
                    ref={greetingRef}
                    role="status"
                    aria-live="polite"
                    className="absolute left-[calc(188px-50vw)] top-[calc(100%+0.75rem)] z-20 box-border min-w-[200px] w-max max-w-[85vw] animate-fade-in rounded-xl border border-sage-300 bg-card px-4 py-3 text-center text-sm leading-5 text-card-foreground shadow-lg sm:left-[calc(100%+0.75rem)] sm:top-1/2 sm:-translate-y-1/2 sm:text-left"
                  >
                    <span className="block whitespace-nowrap">Bonjour, comment allez-vous ?</span>
                    <span
                      aria-hidden="true"
                      className="absolute -top-1.5 left-6 h-3 w-3 rotate-45 border-l border-t border-sage-300 bg-card sm:left-[-0.4rem] sm:top-1/2 sm:-translate-y-1/2 sm:border-l-0 sm:border-t-0 sm:border-b sm:border-r"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
          <p className="font-alice text-2xl sm:text-3xl text-[#8B4513]">
            Le zen pour vous
          </p>
          <p className="font-alice mt-1 text-[#8B4513]" style={{ fontSize: "17px" }}>
            Réseau de praticiens avec crédit d'impôt applicable
          </p>
          <p
            className="font-alice italic text-[#C97A44]"
            style={{ fontSize: "13px", marginTop: "4px" }}
          >
            <span style={{ fontWeight: 600 }}>+</span> Espace ressources offert
          </p>
        </div>
      </div>
    </section>
  );
};
