import { useEffect, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { StressAssessment } from "@/components/stress-assessment";
import { AiSupportDialog } from "@/components/ai-support-dialog";
import cloudVideo from "@/assets/cloud-cropped-tight-2.mp4.asset.json";
import cloudPoster from "@/assets/cloud_bubble_poster.png.asset.json";
import { resolveAssetUrl } from "@/lib/asset-url";

const STORAGE_KEY = "cloud_pop_seen";
const AUTO_DELAY_MS = 9000;
const CORE_RATIO = 0.7; // rayon du nuage (cercle intérieur) relatif au rayon de la bulle, utilisé pour la zone de départ des particules

// vert sauge, or, brun doré, sauge foncé, rose poudré — pas de bleu.
// Volontairement plus saturées/foncées qu'un premier essai pastel : sur le fond
// crème clair de la page, des teintes trop pâles rendues en mode additif
// disparaissaient quasiment (peu de contraste avec un fond déjà clair).
const GLINT_COLORS = ["96,128,80", "196,140,68", "168,120,58", "132,148,92", "205,120,140"];

type Particle = {
  glint?: boolean;
  shape?: "diamond" | "dot";
  flare?: boolean;
  patch?: HTMLCanvasElement;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  life: number;
  decay: number;
  grav: number;
  rot: number;
  vrot: number;
  hue?: string;
  twinkle?: number;
  phase?: number;
};

export const HomeActions = () => {
  const [open, setOpen] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [exerciseTarget, setExerciseTarget] = useState<"coherence" | "meditation" | "meditation-zen" | "exercices" | null>(null);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const burstingRef = useRef(false);
  // Lazy initializer : évite tout re-render post-mount qui peut être détecté à tort
  // comme un mismatch d'hydratation par les outils qui inspectent le DOM initial.
  const [popped, setPopped] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    try {
      return window.localStorage.getItem(STORAGE_KEY) === "1";
    } catch {
      return false;
    }
  });
  const SIZE = 320; // résolution interne du canvas de particules (indépendante de la taille CSS affichée)

  useEffect(() => {
    if (searchParams.get("open") === "plan-perso") {
      setAiOpen(true);
    }
  }, [searchParams]);

  // Autoplay + boucle forcée (fix WKWebView : l'attribut loop natif n'est pas fiable sur iOS)
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = true;
    video.play().catch(() => {
      // Autoplay bloqué ou déjà géré par le navigateur ; on reste silencieux.
    });

    const handleEnded = () => {
      video.currentTime = 0;
      video.play().catch(() => {
        // Relecture bloquée ; on reste silencieux.
      });
    };

    video.addEventListener("ended", handleEnded);
    return () => video.removeEventListener("ended", handleEnded);
  }, []);

  // Effet de particules à la première visite uniquement
  useEffect(() => {
    if (popped) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      try { localStorage.setItem(STORAGE_KEY, "1"); } catch { /* noop */ }
      setPopped(true);
      return;
    }
    const timer = setTimeout(triggerPop, AUTO_DELAY_MS);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function triggerPop() {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || burstingRef.current || popped) return;

    // Sur mobile, la vidéo peut ne pas encore avoir décodé de frame après le délai.
    // On attend une frame exploitable avant de peindre le canvas de particules,
    // sinon drawImage(video,...) échoue silencieusement et l'effet ne part jamais.
    if (video.readyState < 2) {
      const onReady = () => {
        video.removeEventListener("loadeddata", onReady);
        video.removeEventListener("canplay", onReady);
        triggerPop();
      };
      video.addEventListener("loadeddata", onReady, { once: true });
      video.addEventListener("canplay", onReady, { once: true });
      return;
    }

    burstingRef.current = true;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = SIZE * dpr;
    canvas.height = SIZE * dpr;
    const ctx = canvas.getContext("2d")!;
    ctx.scale(dpr, dpr);

    const cx = SIZE / 2;
    const cy = SIZE / 2;
    const R = SIZE / 2;
    const coreR = R * CORE_RATIO;
    const rand = (a: number, b: number) => a + Math.random() * (b - a);

    // capture la frame vidéo affichée pour que les éclats correspondent exactement à l'écran
    const snap = document.createElement("canvas");
    snap.width = SIZE;
    snap.height = SIZE;
    const sctx = snap.getContext("2d")!;
    try {
      sctx.drawImage(video, 0, 0, SIZE, SIZE);
    } catch {
      burstingRef.current = false;
      return;
    }

    // Une vidéo cross-origin sans en-têtes CORS corrects contamine le canvas :
    // drawImage ci-dessus ne lève pas forcément d'erreur, mais relire les pixels
    // avec getImageData échoue. On le vérifie tout de suite pour échouer proprement
    // plutôt que silencieusement plus loin.
    try {
      sctx.getImageData(0, 0, 1, 1);
    } catch (err) {
      console.error(
        "[HomeActions] Canvas contaminé par une vidéo cross-origin — l'effet de particules est ignoré. " +
          "Vérifier avec :\n  curl -I -H \"Origin: https://app-nous.fr\" <url-de-la-video>\n" +
          "et chercher 'access-control-allow-origin' dans la réponse.",
        err,
      );
      burstingRef.current = false;
      setPopped(true);
      try { localStorage.setItem(STORAGE_KEY, "1"); } catch { /* noop */ }
      return;
    }

    const particles: Particle[] = [];

    // éclats de verre découpés sur l'anneau extérieur de la bulle
    for (let i = 0; i < 40; i++) {
      const angle = rand(0, Math.PI * 2);
      const ringR = rand(coreR * 0.92, R * 0.98);
      const sx = cx + Math.cos(angle) * ringR;
      const sy = cy + Math.sin(angle) * ringR;
      const pSize = rand(20, 52);

      const patch = document.createElement("canvas");
      patch.width = pSize;
      patch.height = pSize;
      const pctx = patch.getContext("2d")!;
      pctx.save();
      pctx.beginPath();
      pctx.arc(pSize / 2, pSize / 2, pSize / 2, 0, Math.PI * 2);
      pctx.clip();
      pctx.drawImage(snap, -(sx - pSize / 2), -(sy - pSize / 2));
      pctx.restore();

      const outAngle = angle + rand(-0.35, 0.35);
      const speed = rand(1.6, 4.4);
      particles.push({
        patch,
        x: sx,
        y: sy,
        vx: Math.cos(outAngle) * speed,
        vy: Math.sin(outAngle) * speed - rand(0.3, 1.1),
        size: pSize,
        rot: rand(0, Math.PI * 2),
        vrot: rand(-0.18, 0.18),
        life: 1,
        decay: rand(0.006, 0.01),
        grav: rand(0.015, 0.035),
      });
    }

    // paillettes
    for (let j = 0; j < 210; j++) {
      const a2 = rand(0, Math.PI * 2);
      const r2 = rand(coreR * 0.8, R * 1.15);
      const big = Math.random() < 0.16;
      const lingering = Math.random() < 0.35;
      const isStar = Math.random() < 0.7;
      particles.push({
        glint: true,
        shape: isStar ? "diamond" : "dot",
        flare: isStar ? Math.random() < 0.55 : Math.random() < 0.15,
        x: cx + Math.cos(a2) * r2,
        y: cy + Math.sin(a2) * r2,
        vx: Math.cos(a2) * rand(1.2, 4.6) * (lingering ? 0.45 : 1),
        vy: Math.sin(a2) * rand(1.2, 4.6) * (lingering ? 0.45 : 1) - rand(0.5, 1.4),
        size: big ? rand(14, 24) : rand(3, 10),
        hue: `rgba(${GLINT_COLORS[Math.floor(Math.random() * GLINT_COLORS.length)]},`,
        life: 1,
        decay: lingering ? rand(0.002, 0.004) : rand(0.0055, 0.011),
        grav: lingering ? rand(0.001, 0.004) : rand(0.0025, 0.011),
        twinkle: rand(0.15, 0.45),
        phase: rand(0, Math.PI * 2),
        rot: rand(0, Math.PI * 2),
        vrot: rand(-0.12, 0.12),
      });
    }

    const start = performance.now();

    function drawGlint(p: Particle, alpha: number) {
      ctx.save();
      // Fusion normale plutôt qu'additive "lighter" : sur le fond clair de la page,
      // ajouter de la lumière ne change quasiment rien (le fond est déjà presque
      // blanc), donc la couleur de la particule doit vraiment se peindre par-dessus
      // pour être visible.
      ctx.globalCompositeOperation = "source-over";
      ctx.globalAlpha = alpha;
      ctx.shadowColor = "rgba(50,38,26,0.4)";
      ctx.shadowBlur = 2.5;
      const hue = p.hue ?? "rgba(255,255,255,";
      if (p.shape === "diamond") {
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        const s = p.size * (0.6 + 0.4 * Math.abs(Math.cos(p.rot * 2)));
        const g = ctx.createLinearGradient(-s, -s, s, s);
        g.addColorStop(0, hue + "0)");
        g.addColorStop(0.5, hue + "1)");
        g.addColorStop(1, hue + "0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.moveTo(0, -s);
        ctx.lineTo(s * 0.55, 0);
        ctx.lineTo(0, s);
        ctx.lineTo(-s * 0.55, 0);
        ctx.closePath();
        ctx.fill();
      } else {
        const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size);
        g.addColorStop(0, hue + "1)");
        g.addColorStop(0.4, hue + "0.55)");
        g.addColorStop(1, hue + "0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
      if (p.flare) {
        ctx.strokeStyle = hue + alpha * 0.7 + ")";
        ctx.lineWidth = 0.8;
        const len = p.size * 2.6;
        ctx.beginPath();
        ctx.moveTo(p.x - len, p.y);
        ctx.lineTo(p.x + len, p.y);
        ctx.moveTo(p.x, p.y - len);
        ctx.lineTo(p.x, p.y + len);
        ctx.stroke();
      }
      ctx.restore();
    }

    function step() {
      ctx.clearRect(0, 0, SIZE, SIZE);
      const elapsed = performance.now() - start;

      let alive = false;
      for (const p of particles) {
        if (p.life <= 0) continue;
        alive = true;
        p.x += p.vx;
        p.y += p.vy;
        p.vy += p.grav;
        p.vx *= 0.985;
        p.life -= p.decay;

        if (p.glint) {
          const t = p.twinkle ?? 0;
          const twinkle = 1 - t + t * Math.sin(elapsed * 0.02 + (p.phase ?? 0));
          drawGlint(p, Math.max(p.life, 0) * twinkle);
        } else {
          ctx.save();
          ctx.globalAlpha = Math.max(p.life, 0);
          p.rot += p.vrot;
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.drawImage(p.patch!, -p.size / 2, -p.size / 2, p.size, p.size);
          ctx.restore();
        }
      }

      if (alive) {
        requestAnimationFrame(step);
      } else {
        burstingRef.current = false;
        // On ne marque "déjà vu" qu'une fois l'animation réellement jouée jusqu'au bout.
        try { localStorage.setItem(STORAGE_KEY, "1"); } catch { /* noop */ }
        setPopped(true);
      }
    }

    requestAnimationFrame(step);
  }

  return (
    <section className="relative bg-[#F5F0E6] px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-3xl text-center">
        <div className="mb-14 flex justify-center">
          <div className="relative w-72 sm:w-80 lg:w-96 aspect-square rounded-full overflow-hidden bg-[#F5F0E6] shadow-none ring-0">
            <video
              ref={videoRef}
              src={resolveAssetUrl(cloudVideo.url)}
              poster={resolveAssetUrl(cloudPoster.url)}
              disablePictureInPicture
              controlsList="nodownload nofullscreen noremoteplayback"
              className="absolute inset-0 w-full h-full object-cover animate-[float_3s_ease-in-out_infinite] shadow-none"
              style={{
                WebkitMaskImage: "radial-gradient(circle, rgba(0,0,0,1) 55%, rgba(0,0,0,0) 75%)",
                maskImage: "radial-gradient(circle, rgba(0,0,0,1) 55%, rgba(0,0,0,0) 75%)",
                WebkitFilter: "saturate(0.7)",
                filter: "saturate(0.7)",
              }}
              autoPlay
              muted
              loop
              playsInline
              preload="auto"
              aria-label="Noûs Services Logo"
            />
            <canvas
              ref={canvasRef}
              width={SIZE}
              height={SIZE}
              style={{
                position: "absolute",
                inset: 0,
                width: "100%",
                height: "100%",
                pointerEvents: "none",
              }}
            />
          </div>
        </div>
        <div className="flex flex-wrap justify-center gap-4">
          <button
            onClick={() => setOpen(true)}
            className="px-6 py-3 text-sm font-medium transition-colors rounded-lg bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300"
            style={{ boxShadow: "0 8px 24px rgba(60, 40, 25, 0.18)" }}
          >
            Évaluer mon stress
          </button>
          <button
            onClick={() => navigate("/exercices")}
            className="px-6 py-3 text-sm font-medium transition-colors rounded-lg bg-sage-200 text-sage-700 hover:bg-sage-300 border border-sage-300"
            style={{ boxShadow: "0 8px 24px rgba(60, 40, 25, 0.18)" }}
          >
            Exercices
          </button>
        </div>
      </div>
      <StressAssessment
        open={open}
        onOpenChange={(o) => {
          setOpen(o);
          if (!o) setExerciseTarget(null);
        }}
        targetView={exerciseTarget}
      />
      <AiSupportDialog
        open={aiOpen}
        onOpenChange={setAiOpen}
        onSelectExercise={(ex) => {
          setExerciseTarget(ex);
          setOpen(true);
        }}
      />
    </section>
  );
};
