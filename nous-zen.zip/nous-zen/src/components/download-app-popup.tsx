import { useEffect, useState } from "react";
import { Capacitor } from "@capacitor/core";
import { X, Smartphone } from "lucide-react";
import { trackAppDownload } from "@/lib/track-app-download";

const APP_STORE_URL = "https://apps.apple.com/app/id6785034254";
const PLAY_STORE_URL = "https://play.google.com/store/apps/details?id=fr.app.nous";
const STORAGE_KEY = "nous_download_popup_state";
const DISMISS_MS = 30 * 24 * 60 * 60 * 1000;

type Platform = "ios" | "android" | "desktop";

function detectPlatform(): Platform {
  if (typeof window === "undefined" || !navigator?.userAgent) return "desktop";
  const ua = navigator.userAgent;
  if (/iPad|iPhone|iPod/.test(ua)) return "ios";
  if (/Android/.test(ua)) return "android";
  return "desktop";
}

function shouldShow(): boolean {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return true;
    const parsed = JSON.parse(raw) as { status?: string; at?: number };
    if (parsed.status === "accepted") return false;
    if (parsed.status === "dismissed" && parsed.at) {
      return Date.now() - parsed.at > DISMISS_MS;
    }
    return true;
  } catch {
    return true;
  }
}

export const DownloadAppPopup = () => {
  const [open, setOpen] = useState(false);
  const [platform, setPlatform] = useState<Platform>("desktop");

  useEffect(() => {
    if (Capacitor.isNativePlatform()) return;
    if (!shouldShow()) return;
    setPlatform(detectPlatform());
    const t = setTimeout(() => setOpen(true), 1500);
    return () => clearTimeout(t);
  }, []);

  const persist = (status: "accepted" | "dismissed") => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ status, at: Date.now() })
      );
    } catch {
      /* ignore */
    }
  };

  const close = () => {
    persist("dismissed");
    setOpen(false);
  };

  const accept = (url: string, plateforme: "ios" | "android") => {
    persist("accepted");
    trackAppDownload(plateforme);
    window.open(url, "_blank", "noopener,noreferrer");
    setOpen(false);
  };

  const acceptDesktop = (plateforme: "ios" | "android") => {
    persist("accepted");
    trackAppDownload(plateforme);
    setOpen(false);
  };

  if (!open) return null;

  const primaryBtn =
    "inline-flex items-center justify-center rounded-lg bg-sage-600 px-4 py-2.5 text-sm font-medium text-white shadow-sm transition-colors hover:bg-sage-700";
  const secondaryBtn =
    "inline-flex items-center justify-center rounded-lg border border-sage-300 bg-transparent px-4 py-2.5 text-sm font-medium text-sage-700 transition-colors hover:bg-sage-100";

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 px-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="download-popup-title"
      onClick={close}
    >
      <div
        className="relative w-full max-w-sm rounded-2xl bg-[#F5F0E6] p-6 shadow-xl border border-[#E3E9E3]"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={close}
          aria-label="Fermer"
          className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full text-[#A0522D] hover:bg-sage-100 transition-colors"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="flex flex-col items-center text-center">
          <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-sage-200 text-sage-700">
            <Smartphone className="h-7 w-7" />
          </div>
          <h2
            id="download-popup-title"
            className="mb-2 text-xl font-alice text-[#8B4513]"
          >
            Découvrez Noûs sur votre mobile
          </h2>
          <p className="mb-5 text-sm text-[#A0522D]">
            Retrouvez le zen pour vous, partout.
          </p>

          {platform === "ios" && (
            <div className="flex w-full flex-col gap-2">
              <button
                type="button"
                className={primaryBtn}
                onClick={() => accept(APP_STORE_URL, "ios")}
              >
                Oui, télécharger
              </button>
              <button type="button" className={secondaryBtn} onClick={close}>
                Non merci
              </button>
            </div>
          )}

          {platform === "android" && (
            <div className="flex w-full flex-col gap-2">
              <button
                type="button"
                className={primaryBtn}
                onClick={() => accept(PLAY_STORE_URL, "android")}
              >
                Oui, télécharger
              </button>
              <button type="button" className={secondaryBtn} onClick={close}>
                Non merci
              </button>
            </div>
          )}

          {platform === "desktop" && (
            <div className="flex w-full flex-col gap-2">
              <div className="flex flex-col gap-2 sm:flex-row">
                <a
                  href={APP_STORE_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => acceptDesktop("ios")}
                  className={`${primaryBtn} flex-1`}
                >
                  App Store
                </a>
                <a
                  href={PLAY_STORE_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => acceptDesktop("android")}
                  className={`${primaryBtn} flex-1`}
                >
                  Google Play
                </a>
              </div>
              <button type="button" className={secondaryBtn} onClick={close}>
                Non merci
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};