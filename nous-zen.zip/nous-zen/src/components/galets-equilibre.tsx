import { useCallback, useEffect, useRef, useState } from "react";
import { Sparkles } from "lucide-react";

// ---------------------------------------------------------------------------
// GaletsEquilibre — mini-jeu "empile les galets au bon moment"
// Aucun échec brutal : si la pile devient trop instable elle s'effondre en
// douceur et on repart à zéro. Session libre, sans timer.
// ---------------------------------------------------------------------------

type Stone = {
  id: number;
  width: number; // px
  height: number; // px
  color: string;
  offset: number; // px, décalage horizontal cumulé par rapport au centre
  shape: string; // border-radius organique
  tilt: number; // légère rotation naturelle (deg)
};

const BEST_KEY = "galets-equilibre-best";

const PALETTE = [
  "#D9C9A8", // beige
  "#C9C2B4", // gris clair chaud
  "#B3C2A6", // sauge clair
  "#89A189", // sauge
  "#C97A5A", // terracotta
  "#A8998A", // taupe
  "#E5D9C3", // sable
];

const BASE_WIDTH = 150;
const MIN_WIDTH = 60;
const BASE_HEIGHT = 34;
const MIN_HEIGHT = 22;
const BASE_FALL_MS = 3000; // temps pour traverser la zone (1er galet)
const FALL_STEP_MS = 350;  // ralentissement à chaque galet supplémentaire
const MAX_FALL_MS = 5200;
const PERFECT_WINDOW = 18; // px
const GOOD_WINDOW = 60; // px
const MAX_INSTABILITY = 70; // décalage cumulé toléré (px)

const SHAPES = [
  "58% 42% 55% 45% / 55% 60% 40% 45%",
  "62% 38% 48% 52% / 50% 55% 45% 50%",
  "55% 45% 60% 40% / 60% 45% 55% 40%",
  "50% 50% 55% 45% / 45% 55% 50% 50%",
  "60% 40% 50% 50% / 52% 48% 55% 45%",
];

const pick = <T,>(arr: T[]) => arr[Math.floor(Math.random() * arr.length)];

let stoneIdCounter = 0;
const nextStoneId = () => ++stoneIdCounter;

const stoneWidthAt = (index: number) =>
  Math.max(MIN_WIDTH, Math.round(BASE_WIDTH - index * 8));

const stoneHeightAt = (index: number) =>
  Math.max(MIN_HEIGHT, Math.round(BASE_HEIGHT - index * 1.5));

const fallDurationFor = (stackLen: number) =>
  Math.min(MAX_FALL_MS, BASE_FALL_MS + stackLen * FALL_STEP_MS);

export const GaletsEquilibre = () => {
  const [stack, setStack] = useState<Stone[]>([]);
  const [best, setBest] = useState<number>(() => {
    if (typeof window === "undefined") return 0;
    const raw = window.localStorage.getItem(BEST_KEY);
    const n = raw ? parseInt(raw, 10) : 0;
    return Number.isFinite(n) ? n : 0;
  });
  const [collapsing, setCollapsing] = useState(false);

  // Galet courant qui descend
  const [current, setCurrent] = useState<{
    id: number;
    width: number;
    height: number;
    color: string;
    shape: string;
    startedAt: number;
    fallDuration: number;
    direction: 1 | -1; // sens de balancement horizontal
  } | null>(null);

  // Feedback visuel au moment du tap
  const [tapFlash, setTapFlash] = useState<{
    id: number;
    kind: "perfect" | "good" | "off";
  } | null>(null);

  const areaRef = useRef<HTMLDivElement | null>(null);
  const [areaWidth, setAreaWidth] = useState(320);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const el = areaRef.current;
    if (!el) return;
    const update = () => setAreaWidth(el.clientWidth);
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // rAF pour la position du galet en chute
  useEffect(() => {
    let raf = 0;
    const tick = () => {
      setNow(Date.now());
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  const spawnNext = useCallback(
    (indexOverride?: number) => {
      const index = indexOverride ?? stack.length;
      const width = stoneWidthAt(index);
      const height = stoneHeightAt(index);
      const color = PALETTE[index % PALETTE.length];
      setCurrent({
        id: nextStoneId(),
        width,
        height,
        color,
        shape: pick(SHAPES),
        startedAt: Date.now(),
        fallDuration: fallDurationFor(index),
        direction: Math.random() < 0.5 ? 1 : -1,
      });
    },
    [stack.length],
  );

  // Démarrer un galet dès qu'aucun n'est en cours et pas en effondrement
  useEffect(() => {
    if (collapsing) return;
    if (current) return;
    const t = setTimeout(() => spawnNext(), 350);
    return () => clearTimeout(t);
  }, [current, collapsing, spawnNext]);

  // Auto-relance après effondrement
  useEffect(() => {
    if (!collapsing) return;
    const t = setTimeout(() => {
      setStack([]);
      setCollapsing(false);
    }, 1400);
    return () => clearTimeout(t);
  }, [collapsing]);

  const currentX = (() => {
    if (!current) return 0;
    const elapsed = now - current.startedAt;
    const t = (elapsed % current.fallDuration) / current.fallDuration; // 0..1
    // balancement gauche-droite en sinus
    const amplitude = Math.max(40, areaWidth / 2 - current.width / 2 - 12);
    return current.direction * Math.sin(t * Math.PI * 2) * amplitude;
  })();

  const dropStone = useCallback(() => {
    if (!current || collapsing) return;
    // Cible = centre du dernier galet posé (offset cumulé)
    const targetOffset = stack.length ? stack[stack.length - 1].offset : 0;
    const rawDelta = currentX - targetOffset;
    const absDelta = Math.abs(rawDelta);
    let placedDelta = rawDelta;
    if (absDelta <= PERFECT_WINDOW) placedDelta = 0; // parfait -> centré
    else if (absDelta <= GOOD_WINDOW) placedDelta = rawDelta * 0.5; // atténué
    // sinon on garde le décalage complet

    const newOffset = targetOffset + placedDelta;
    const stone: Stone = {
      id: current.id,
      width: current.width,
      height: current.height,
      color: current.color,
      offset: newOffset,
      shape: current.shape,
      tilt: (Math.random() - 0.5) * 4,
    };

    const nextStack = [...stack, stone];
    setStack(nextStack);
    setCurrent(null);

    // Feedback visuel : flash de couleur selon la qualité du placement
    const kind: "perfect" | "good" | "off" =
      absDelta <= PERFECT_WINDOW
        ? "perfect"
        : absDelta <= GOOD_WINDOW
          ? "good"
          : "off";
    setTapFlash({ id: stone.id, kind });
    window.setTimeout(() => {
      setTapFlash((f) => (f && f.id === stone.id ? null : f));
    }, 320);

    // Score
    if (nextStack.length > best) {
      setBest(nextStack.length);
      try {
        window.localStorage.setItem(BEST_KEY, String(nextStack.length));
      } catch {
        // ignore
      }
    }

    // Vérifier stabilité : décalage max par rapport au galet du dessous
    let unstable = false;
    for (let i = 1; i < nextStack.length; i++) {
      const diff = Math.abs(nextStack[i].offset - nextStack[i - 1].offset);
      const halfBase = nextStack[i - 1].width / 2;
      if (diff > MAX_INSTABILITY || diff > halfBase) {
        unstable = true;
        break;
      }
    }
    if (unstable) setCollapsing(true);
  }, [current, collapsing, stack, currentX, best]);

  const handleReset = () => {
    setStack([]);
    setCurrent(null);
    setCollapsing(false);
    setTapFlash(null);
  };

  return (
    <div className="w-full">
      <div className="text-center mb-3">
        <h3 className="font-['Alice'] text-2xl text-[#8B4513]">
          Galets d&apos;équilibre
        </h3>
        <p className="text-sm text-[#5C3A1E] mt-1">
          Touchez au bon moment pour poser le galet sur la pile.
        </p>
      </div>

      <div className="flex items-center justify-between mb-2 px-1">
        <div className="inline-flex items-center gap-2 text-sm text-sage-700 bg-sage-100 border border-sage-200 rounded-full px-3 py-1">
          <Sparkles className="w-4 h-4" />
          <span>Galets empilés : {stack.length}</span>
        </div>
        <div className="text-xs text-[#8B4513]/70">Meilleur : {best}</div>
        <button
          onClick={handleReset}
          className="text-xs px-3 py-1 rounded-full border border-sage-300 text-[#8B4513] hover:bg-sage-50 transition-colors"
        >
          Réinitialiser
        </button>
      </div>

      <div
        ref={areaRef}
        onPointerDown={(e) => {
          e.preventDefault();
          dropStone();
        }}
        className="relative w-full rounded-2xl overflow-hidden border border-sage-200 select-none"
        style={{
          height: "min(70vh, 460px)",
          background:
            "linear-gradient(180deg,#DCEBF0 0%,#EAF3E8 55%,#E9DFCB 100%)",
          touchAction: "manipulation",
          WebkitTapHighlightColor: "transparent",
          cursor: "pointer",
        }}
        role="button"
        aria-label="Zone de jeu — touchez pour poser le galet"
      >
        {/* Base / sol */}
        <div
          style={{
            position: "absolute",
            left: 0,
            right: 0,
            bottom: 0,
            height: 26,
            background:
              "linear-gradient(180deg, rgba(168,153,138,0.35), rgba(120,100,80,0.55))",
          }}
        />

        {/* Pile de galets */}
        <div
          style={{
            position: "absolute",
            left: "50%",
            bottom: 26,
            transform: "translateX(0)",
            transition: collapsing ? "transform 900ms ease-in" : undefined,
          }}
        >
          {stack.map((s, i) => {
            // hauteur cumulée : somme des hauteurs précédentes
            let bottom = 0;
            for (let k = 0; k < i; k++) bottom += stack[k].height - 4;
            const collapseTilt = collapsing ? (i + 1) * 3 : 0;
            const collapseShift = collapsing ? (i + 1) * 6 : 0;
            const flash = tapFlash && tapFlash.id === s.id ? tapFlash.kind : null;
            const flashColor =
              flash === "perfect"
                ? "rgba(179,214,174,0.85)"
                : flash === "good"
                  ? "rgba(255,255,255,0.75)"
                  : flash === "off"
                    ? "rgba(201,122,90,0.55)"
                    : null;
            return (
              <div
                key={s.id}
                style={{
                  position: "absolute",
                  left: s.offset - s.width / 2 + collapseShift,
                  bottom,
                  width: s.width,
                  height: s.height,
                  borderRadius: s.shape,
                  background: `radial-gradient(ellipse at 32% 28%, rgba(255,255,255,0.7), ${s.color} 55%, rgba(0,0,0,0.22) 100%)`,
                  boxShadow:
                    "0 6px 10px -4px rgba(60,45,30,0.35), inset 0 -3px 6px rgba(0,0,0,0.18), inset 0 2px 4px rgba(255,255,255,0.35)",
                  border: "1px solid rgba(255,255,255,0.35)",
                  transform: `rotate(${s.tilt + collapseTilt}deg)`,
                  transition:
                    "transform 800ms ease-in, left 800ms ease-in, opacity 800ms",
                  opacity: collapsing ? 0.6 : 1,
                }}
              >
                {flashColor && (
                  <span
                    aria-hidden
                    style={{
                      position: "absolute",
                      inset: 0,
                      borderRadius: s.shape,
                      background: flashColor,
                      mixBlendMode: "screen",
                      opacity: 0,
                      animation: "galetFlash 320ms ease-out forwards",
                      pointerEvents: "none",
                    }}
                  />
                )}
              </div>
            );
          })}
        </div>

        {/* Galet en chute */}
        {current && !collapsing && (
          <div
            style={{
              position: "absolute",
              left: "50%",
              top: 20,
              width: current.width,
              height: current.height,
              marginLeft: -current.width / 2,
              transform: `translateX(${currentX}px)`,
              borderRadius: current.shape,
              background: `radial-gradient(ellipse at 32% 28%, rgba(255,255,255,0.75), ${current.color} 55%, rgba(0,0,0,0.22) 100%)`,
              boxShadow:
                "0 8px 14px -4px rgba(60,45,30,0.4), inset 0 -3px 6px rgba(0,0,0,0.18), inset 0 2px 4px rgba(255,255,255,0.4)",
              border: "1px solid rgba(255,255,255,0.4)",
              pointerEvents: "none",
            }}
          />
        )}

        {stack.length === 0 && !current && !collapsing && (
          <div className="absolute inset-x-0 top-3 text-center text-xs text-[#5C3A1E]/70 pointer-events-none">
            Respirez… touchez l&apos;écran quand le galet est bien centré.
          </div>
        )}

        {collapsing && (
          <div className="absolute inset-x-0 top-3 text-center text-xs text-[#5C3A1E]/70 pointer-events-none">
            La pile se repose… on recommence en douceur.
          </div>
        )}
      </div>
      <style>{`
        @keyframes galetFlash {
          0% { opacity: 0.85; transform: scale(1.04); }
          100% { opacity: 0; transform: scale(1); }
        }
      `}</style>
    </div>
  );
};

export default GaletsEquilibre;