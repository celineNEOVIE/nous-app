import tribucaLogo from "@/assets/logo-tribuca.png.asset.json";
import { resolveAssetUrl } from "@/lib/asset-url";

export const PressSection = () => {
  return (
    <section className="py-12 bg-[#F5F0E6]">
      <div className="container px-4 mx-auto sm:px-6 lg:px-8">
        <h2 className="mb-6 text-3xl font-bold text-center text-[#8B4513]">Presse</h2>
        <article
          className="max-w-2xl p-6 mx-auto bg-[#FDFAF3] border border-[#E4D7BE] rounded-2xl"
          style={{ boxShadow: "0 8px 24px rgba(60, 40, 25, 0.18)" }}
        >
          <img
            src={resolveAssetUrl(tribucaLogo.url)}
            alt="Logo Tribuca — Tribune Côte d'Azur"
            className="h-10 w-auto mb-4"
            loading="lazy"
          />
          <h3 className="font-alice text-xl sm:text-2xl text-[#8B4513]">
            Noûs facilite l'accès aux thérapies avec crédit d'impôt applicable
          </h3>
          <p className="mt-3 text-[#A0522D]">
            Une nouvelle app française de bien-être : méditation guidée, cohérence
            cardiaque, services de praticiens certifiés éligibles au crédit d'impôt.
          </p>
          <a
            href="https://tribuca.net/comment-cette-plateforme-cannoise-veut-rendre-les-therapies-plus-accessibles/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center mt-5 rounded-xl bg-sage-600 px-5 py-2.5 font-medium text-white transition-colors hover:bg-sage-700"
          >
            Lire l'article complet
          </a>
        </article>
      </div>
    </section>
  );
};