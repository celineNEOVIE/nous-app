import tribucaLogo from "@/assets/logo-tribuca.png.asset.json";
import cannesSoleilLogo from "@/assets/cannes-soleil.png.asset.json";
import { resolveAssetUrl } from "@/lib/asset-url";

const cardStyle = { boxShadow: "0 8px 24px rgba(60, 40, 25, 0.18)" } as const;

export const PressSection = () => {
  return (
    <section className="py-12 bg-[#F5F0E6]">
      <div className="container px-4 mx-auto sm:px-6 lg:px-8">
        <h2 className="mb-6 text-3xl font-bold text-center text-[#8B4513]">Presse</h2>
        <div className="mx-auto max-w-2xl space-y-6">
          <article
            className="p-6 bg-[#FDFAF3] border border-[#E4D7BE] rounded-2xl"
            style={cardStyle}
          >
            <img
              src={resolveAssetUrl(cannesSoleilLogo.url)}
              alt="Logo Cannes Soleil — Le magazine de la Ville de Cannes"
              className="h-10 w-auto mb-4 rounded"
              loading="lazy"
            />
            <p className="text-xs text-[#A0522D] mb-2">
              Octobre 2026 (n°274) — Rubrique « Tranches de vi(ll)es »
            </p>
            <h3 className="font-alice text-xl sm:text-2xl text-[#8B4513]">
              Le bien-être en application
            </h3>
            <p className="mt-3 text-[#A0522D]">
              Le magazine de la Ville de Cannes présente Noûs, l'application
              bien-être créée par Céline Chauchet, qui réunit outils de
              relaxation et réseau de praticiens certifiés avec 50 % de crédit
              d'impôt.
            </p>
            <a
              href="https://issuu.com/cannes/docs/octobre_2026_-_cannes_soleil/13"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center mt-5 rounded-xl bg-sage-600 px-5 py-2.5 font-medium text-white transition-colors hover:bg-sage-700"
            >
              Lire l'article
            </a>
          </article>

          <article
            className="p-6 bg-[#FDFAF3] border border-[#E4D7BE] rounded-2xl"
            style={cardStyle}
          >
            <img
              src={resolveAssetUrl(tribucaLogo.url)}
              alt="Logo Tribuca — Tribune Côte d'Azur"
              className="h-10 w-auto mb-4"
              loading="lazy"
            />
            <h3 className="font-alice text-xl sm:text-2xl text-[#8B4513]">
              Noûs facilite l'accès aux thérapies avec crédit d'impôt applicable
            </h3>
            <p className="mt-3 text-[#A0522D]">
              Une nouvelle app française de bien-être : méditation guidée, cohérence
              cardiaque, services de praticiens certifiés éligibles au crédit d'impôt.
            </p>
            <a
              href="https://tribuca.net/comment-cette-plateforme-cannoise-veut-rendre-les-therapies-plus-accessibles/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center mt-5 rounded-xl bg-sage-600 px-5 py-2.5 font-medium text-white transition-colors hover:bg-sage-700"
            >
              Lire l'article complet
            </a>
          </article>
        </div>
      </div>
    </section>
  );
};
