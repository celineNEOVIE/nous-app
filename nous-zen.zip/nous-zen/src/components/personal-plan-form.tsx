import { useEffect, useState } from "react";
import { Mic, MicOff, Send } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export const PersonalPlanForm = () => {
  const [text, setText] = useState("");
  const [email, setEmail] = useState("");
  const [listening, setListening] = useState(false);
  const [supported, setSupported] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);
  // Web Speech API instance (browser only)
  // Stored on a ref-like closure via useState to avoid re-instantiation.
  const [webRecognition, setWebRecognition] = useState<any>(null);

  const isNativeRuntime = async (): Promise<boolean> => {
    try {
      const { Capacitor } = await import("@capacitor/core");
      return Capacitor.isNativePlatform();
    } catch {
      return false;
    }
  };

  const getWebSpeechCtor = (): any | null => {
    if (typeof window === "undefined") return null;
    return (
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition ||
      null
    );
  };

  // Cleanup on unmount: ensure any active listening is stopped.
  useEffect(() => {
    return () => {
      (async () => {
        try {
          if (webRecognition) {
            try { webRecognition.stop(); } catch {}
          }
          if (!(await isNativeRuntime())) return;
          const { SpeechRecognition } = await import(
            "@capacitor-community/speech-recognition"
          );
          await SpeechRecognition.stop();
          await SpeechRecognition.removeAllListeners();
        } catch {}
      })();
    };
  }, [webRecognition]);

  const toggleMic = async () => {
    try {
      const native = await isNativeRuntime();

      // ---------- WEB BROWSER PATH (Web Speech API) ----------
      if (!native) {
        const Ctor = getWebSpeechCtor();
        if (!Ctor) {
          setSupported(false);
          return;
        }

        if (listening && webRecognition) {
          try { webRecognition.stop(); } catch {}
          setListening(false);
          return;
        }

        const recognition = new Ctor();
        recognition.lang = "fr-FR";
        recognition.continuous = true;
        recognition.interimResults = true;

        let lastFinalIndex = 0;
        recognition.onresult = (event: any) => {
          let finalChunk = "";
          for (let i = lastFinalIndex; i < event.results.length; i++) {
            const res = event.results[i];
            if (res.isFinal) {
              finalChunk += res[0].transcript;
              lastFinalIndex = i + 1;
            }
          }
          const trimmed = finalChunk.trim();
          if (trimmed) {
            setText((prev) => (prev ? prev + " " : "") + trimmed);
          }
        };
        recognition.onerror = () => {
          setListening(false);
        };
        recognition.onend = () => {
          setListening(false);
        };

        try {
          recognition.start();
          setWebRecognition(recognition);
          setListening(true);
        } catch (e) {
          console.error("Web SpeechRecognition start error", e);
          setSupported(false);
          setListening(false);
        }
        return;
      }

      // ---------- NATIVE PATH (Capacitor plugin) ----------
      const { SpeechRecognition } = await import(
        "@capacitor-community/speech-recognition"
      );

      const available = await SpeechRecognition.available();
      if (!available?.available) {
        setSupported(false);
        return;
      }

      if (listening) {
        try {
          await SpeechRecognition.stop();
        } catch {}
        try {
          await SpeechRecognition.removeAllListeners();
        } catch {}
        setListening(false);
        return;
      }

      const perm = await SpeechRecognition.checkPermissions();
      if (perm.speechRecognition !== "granted") {
        const req = await SpeechRecognition.requestPermissions();
        if (req.speechRecognition !== "granted") {
          setSupported(false);
          return;
        }
      }

      await SpeechRecognition.removeAllListeners();
      await SpeechRecognition.addListener("partialResults", (data: any) => {
        const chunk = Array.isArray(data?.matches) ? data.matches[0] : "";
        if (!chunk) return;
        setText((prev) => (prev ? prev + " " : "") + String(chunk).trim());
      });
      await SpeechRecognition.addListener("listeningState", (data: any) => {
        if (data?.status === "stopped") setListening(false);
      });

      await SpeechRecognition.start({
        language: "fr-FR",
        partialResults: true,
        popup: false,
      });
      setListening(true);
    } catch (err) {
      console.error("SpeechRecognition error", err);
      setSupported(false);
      setListening(false);
    }
  };

  const submit = async () => {
    if (typeof (window as any).gtag === "function") {
      (window as any).gtag("event", "soumission_plan_perso");
    }
    const problematique = text.trim();
    const e = email.trim();
    if (!problematique || !e) {
      toast({
        title: "Champs requis",
        description: "Merci de remplir votre ressenti et votre email.",
        variant: "destructive",
      });
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) {
      toast({
        title: "Email invalide",
        description: "Merci de vérifier votre adresse email.",
        variant: "destructive",
      });
      return;
    }
    setSubmitting(true);
    try {
      const { error } = await supabase.functions.invoke("request-program", {
        body: { problematique, email: e },
      });
      if (error) throw error;
      setSent(true);
    } catch (err) {
      console.error(err);
      toast({
        title: "Envoi impossible",
        description: "Veuillez réessayer dans un instant.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const reset = () => {
    setText("");
    setEmail("");
    setSent(false);
    (async () => {
      try {
        if (webRecognition) {
          try { webRecognition.stop(); } catch {}
        }
        if (!(await isNativeRuntime())) {
          setListening(false);
          return;
        }
        const { SpeechRecognition } = await import(
          "@capacitor-community/speech-recognition"
        );
        await SpeechRecognition.stop();
      } catch {}
    })();
    setListening(false);
  };

  const showEmail = text.trim().length > 0;

  return (
    <section className="relative bg-[#F5F0E6] px-4 pt-2 pb-8 sm:px-6 lg:px-8">
      <div
        className="mx-auto max-w-2xl rounded-2xl border border-sage-200 bg-white/60 p-6 sm:p-8"
        style={{ boxShadow: "0 8px 24px rgba(60, 40, 25, 0.18)" }}
      >
        <div className="mb-6 text-center">
          <p className="text-[#A0522D]">
            Vous pouvez exprimer ce que vous ressentez, nous vous offrons des outils personnalisés.
          </p>
        </div>

        {sent ? (
          <div className="space-y-4">
            <div className="rounded-lg border border-sage-300 bg-sage-50 p-4 text-[#5C2E0E]">
              <p className="mb-1 font-medium text-sage-700">Demande bien reçue 🌿</p>
              <p className="text-sm">Nous reviendrons vers vous sous 48h.</p>
            </div>
            <div className="flex justify-end">
              <button
                type="button"
                onClick={reset}
                className="rounded-lg border border-sage-300 bg-sage-200 px-4 py-2 text-sm text-sage-700 hover:bg-sage-300 transition-colors"
              >
                Nouvelle demande
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="relative">
              <Textarea
                value={text}
                onChange={(ev) => setText(ev.target.value)}
                placeholder="Je me sens stressé(e), j'ai du mal à dormir…"
                className="min-h-[120px] bg-white/70 border-sage-300 pr-14 text-[#5C2E0E] placeholder:text-[#A0522D]/50"
                maxLength={3000}
              />
              {supported && (
                <button
                  type="button"
                  onClick={toggleMic}
                  aria-label={listening ? "Arrêter le micro" : "Activer le micro"}
                  className={cn(
                    "absolute top-2 right-2 rounded-full border p-2.5 transition-colors",
                    listening
                      ? "animate-pulse border-sage-400 bg-sage-300 text-sage-800"
                      : "border-sage-300 bg-sage-100 text-sage-700 hover:bg-sage-200"
                  )}
                >
                  {listening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                </button>
              )}
            </div>
            {!supported && (
              <p className="text-xs text-[#A0522D]/70">
                La saisie vocale n'est pas disponible sur ce navigateur. Vous pouvez écrire votre ressenti.
              </p>
            )}

            <p className="text-center text-xs text-[#A0522D]/80">
              Ne remplace pas un avis médical — rien n'est enregistré.
            </p>

            <div
              className={cn(
                "grid transition-all duration-500 ease-out",
                showEmail ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
              )}
            >
              <div className="overflow-hidden">
                <label className="mb-1 block text-sm font-medium text-[#8B4513]">Votre email</label>
                <Input
                  type="email"
                  value={email}
                  onChange={(ev) => setEmail(ev.target.value)}
                  placeholder="vous@exemple.com"
                  className="bg-white/70 border-sage-300 text-[#5C2E0E]"
                  maxLength={255}
                />
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={submit}
                disabled={submitting}
                className="inline-flex items-center gap-2 rounded-lg border border-sage-400 bg-sage-300 px-5 py-2.5 text-sm font-medium text-sage-800 transition-colors hover:bg-sage-400 disabled:opacity-60"
              >
                <Send className="h-4 w-4" />
                {submitting ? "Envoi…" : "Envoyer ma demande"}
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
