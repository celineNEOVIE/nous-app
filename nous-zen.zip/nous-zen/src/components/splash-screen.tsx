import { useEffect, useRef, useState } from "react";
import mascotteVideo from "@/assets/mascotte_fond_correct.mp4.asset.json";
import { resolveAssetUrl } from "@/lib/asset-url";

export const SplashScreen = ({ onFinish }: { onFinish: () => void }) => {
  const [leaving, setLeaving] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = true;
    v.defaultMuted = true;
    v.playsInline = true;
    v.controls = false;
    const tryPlay = () => {
      const p = v.play();
      if (p && typeof p.catch === "function") p.catch(() => {});
    };
    tryPlay();
    v.addEventListener("canplay", tryPlay);
    v.addEventListener("loadeddata", tryPlay);
    document.addEventListener("touchstart", tryPlay, { once: true });
    return () => {
      v.removeEventListener("canplay", tryPlay);
      v.removeEventListener("loadeddata", tryPlay);
      document.removeEventListener("touchstart", tryPlay);
    };
  }, []);

  useEffect(() => {
    const t1 = setTimeout(() => setLeaving(true), 5000);
    const t2 = setTimeout(() => onFinish(), 5800);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [onFinish]);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#F5F0E6] transition-opacity duration-700 ${
        leaving ? "opacity-0" : "opacity-100"
      }`}
    >
      <video
        ref={videoRef}
        src={resolveAssetUrl(mascotteVideo.url)}
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
        controls={false}
        disablePictureInPicture
        controlsList="nodownload nofullscreen noremoteplayback"
        className="object-contain"
        style={{
          width: "min(600px, 100vw)",
          height: "min(600px, 100vw)",
          pointerEvents: "none",
          maskImage:
            "radial-gradient(circle at center, #000 48%, rgba(0,0,0,0.75) 62%, rgba(0,0,0,0.25) 72%, transparent 80%)",
          WebkitMaskImage:
            "radial-gradient(circle at center, #000 48%, rgba(0,0,0,0.75) 62%, rgba(0,0,0,0.25) 72%, transparent 80%)",
        }}
      />
      <div className="relative mt-10 h-8 w-64 text-center">
        <span className="absolute inset-0 text-lg tracking-widest text-sage-700 animate-[inhaleText_5s_ease-in-out_infinite]">
          Inspirez...
        </span>
        <span className="absolute inset-0 text-lg tracking-widest text-sage-700 animate-[exhaleText_5s_ease-in-out_infinite]">
          Expirez...
        </span>
      </div>
    </div>
  );
};
