import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";

const APropos = () => {
  return (
    <div className="min-h-screen bg-[#F5F0E6]">
      <Helmet>
        <title>
          À propos de Noûs : réseau de praticiens certifiés, crédit d'impôt -50 %
        </title>
        <meta
          name="description"
          content="Découvrez l'histoire de Noûs, né en 2021 pendant le COVID-19 : un réseau de praticiens du bien-être certifiés, en visio partout en France, avec 50 % de crédit d'impôt."
        />
        <link rel="canonical" href="https://app-nous.fr/a-propos" />
        <meta
          property="og:title"
          content="À propos de Noûs : réseau de praticiens certifiés, crédit d'impôt -50 %"
        />
        <meta
          property="og:description"
          content="Découvrez l'histoire de Noûs, né en 2021 pendant le COVID-19 : un réseau de praticiens du bien-être certifiés, en visio partout en France, avec 50 % de crédit d'impôt."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://app-nous.fr/a-propos" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "AboutPage",
            name: "À propos de Noûs",
            url: "https://app-nous.fr/a-propos",
            publisher: {
              "@type": "Organization",
              name: "Noûs",
              url: "https://app-nous.fr",
            },
          })}
        </script>
      </Helmet>

      <div className="max-w-3xl mx-auto pt-12 pb-8 px-4 text-center">
        <h1 className="mb-4 text-3xl font-bold text-[#8B4513]">À propos de Noûs</h1>
      </div>

      <section className="py-8">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="mb-4 text-2xl font-bold text-[#8B4513]">
            Pourquoi Noûs existe
          </h2>
          <p className="text-[#A0522D] leading-relaxed">
            Pendant la pandémie de COVID-19, j'ai constaté une vraie souffrance
            psychologique autour de moi. C'est ce qui m'a donné envie d'agir&nbsp;: en
            2021, j'ai créé un réseau de praticiens du bien-être sur une plateforme
            dédiée.
          </p>
        </div>
      </section>

      <section className="py-8">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="mb-4 text-2xl font-bold text-[#8B4513]">Notre histoire</h2>
          <ul className="list-disc pl-6 space-y-2 text-[#A0522D]">
            <li>
              <strong>2021</strong>&nbsp;: naissance du réseau de praticiens.
            </li>
            <li>
              <strong>2023</strong>&nbsp;: obtention de l'agrément Services à la
              Personne, qui donne droit à un crédit d'impôt de 50&nbsp;% sur chaque
              séance du réseau.
            </li>
            <li>
              <strong>2026</strong>&nbsp;: lancement de Noûs, l'application mobile
              dédiée au bien-être, avec des thérapeutes que j'ai sélectionnés, un test
              d'évaluation du stress et des exercices.
            </li>
          </ul>
        </div>
      </section>

      <section className="py-8">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="mb-4 text-2xl font-bold text-[#8B4513]">
            Un réseau de confiance
          </h2>
          <p className="text-[#A0522D] leading-relaxed">
            Les praticiens de Noûs sont choisis un par un et justifient de leurs
            qualifications&nbsp;:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-[#A0522D] mt-4">
            <li>Psychothérapie&nbsp;: praticiens inscrits avec un numéro RPPS</li>
            <li>Sophrologie&nbsp;: certification RNCP</li>
            <li>Naturopathie&nbsp;: formation reconnue FENA</li>
            <li>Coachings et accompagnements&nbsp;: coachs certifiés RNCP</li>
          </ul>
          <p className="text-[#A0522D] leading-relaxed mt-4">
            Les séances se font en visio partout en France, ou en cabinet selon les
            praticiens.
          </p>
        </div>
      </section>

      <section className="py-8">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="mb-4 text-2xl font-bold text-[#8B4513]">Qui suis-je&nbsp;?</h2>
          <p className="text-[#A0522D] leading-relaxed">
            Je suis Céline Chauchet, fondatrice de Noûs. J'ai un parcours atypique,
            entre reconversion et pluriactivité (esthétique, assistance juridique…).
            Ces expériences de vie m'ont appris à ressentir, à écouter et à orienter
            chaque personne vers le bon accompagnement.
          </p>
        </div>
      </section>

      <section className="py-12">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <Link
            to="/praticiens"
            className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
          >
            Découvrir nos praticiens
          </Link>
        </div>
      </section>
    </div>
  );
};

export default APropos;
