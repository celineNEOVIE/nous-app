import { Helmet } from "react-helmet-async";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  CalendarDays,
  MapPin,
  Users,
  Euro,
  Globe,
  Sparkles,
  FileText,
} from "lucide-react";

type Evenement = {
  id: string;
  title: string;
  session?: string;
  method?: { name: string; text: string };
  organizers: string;
  description: string;
  dates: string;
  place: string;
  price?: string;
  bookingHref: string;
  pricingHref?: string;
  pricingLabel?: string;
  websiteHref?: string;
  websiteLabel?: string;
};

const evenements: Evenement[] = [
  {
    id: "boot-camp-retour-a-soi",
    title: "Boot camp retour à soi",
    organizers: "Laurence Giudicelli et Océane Danjon",
    description:
      "Une immersion de 3 jours pour :\nRevenir à soi.\nHabiter pleinement son corps\nSe reconnecter à son essence\nRalentir pour mieux se retrouver\nQuitter le mode survie, choisir le mode vie.\nÀ travers le corps, la respiration et la créativité.",
    dates: "Du 16 au 19 octobre 2026",
    place: "Chem. des Anges Villa 4, 83470 Saint-Maximin-la-Sainte-Baume",
    price:
      "À partir de 759 € (hors hébergement et repas) — financement de prise en charge possible jusqu'à 50 %",
    bookingHref: "mailto:terredelune08@gmail.com",
    websiteHref: "https://www.terredelune.fr/",
    websiteLabel: "Espaces de Retour à Soi & Incarnation | Le Cannet Cannes",
  },
  {
    id: "formation-praticien-ne-psycho-corporel-2027",
    title:
      "Formation Praticien·ne en accompagnement psycho-corporel et créatif",
    session: "Session 2027 — Niveau 1",
    method: {
      name: "Méthode Architecte de l'Être®",
      text: "Évolution naturelle de la méthode Art-Thérapie en mouvement® transmise depuis plus de 20 ans. Ouverte en 2025 à tous les professionnels de l'accompagnement humain.",
    },
    organizers: "Laurence Giudicelli et Océane Danjon",
    description:
      "Un parcours complet pour devenir praticien·ne : 3 modules théoriques en ligne à suivre à votre rythme, 3 séminaires pratiques en présentiel, 9 visioconférences, 3 rendez-vous de supervision individuelle et une production écrite finale.",
    dates: "Action de formation du 27 novembre 2026 au 04 juin 2027",
    place: "La source des Anges, 28 chemin de St Hubert, 83860 Nans les pins",
    bookingHref: "mailto:terredelune08@gmail.com",
    pricingHref:
      "https://www.terredelune.fr/formation-accompagnement-psycho-corporel",
    pricingLabel: "Tarifs et modalités de règlement",
    websiteHref: "https://www.terredelune.fr/",
    websiteLabel: "Espaces de Retour à Soi & Incarnation | Le Cannet Cannes",
  },
];

const Evenements = () => {
  return (
    <div className="min-h-screen bg-[#F5F0E6] py-12 px-4">
      <Helmet>
        <title>Événements Noûs — Retraites, stages et formations bien-être</title>
        <meta
          name="description"
          content="Retraites, stages, immersions et formations bien-être organisés par les praticiennes Noûs : dates, lieux, tarifs et réservation."
        />
        <link rel="canonical" href="https://app-nous.fr/evenements" />
        <meta
          property="og:title"
          content="Événements Noûs — Retraites, stages et formations bien-être"
        />
        <meta
          property="og:description"
          content="Retraites, stages, immersions et formations bien-être organisés par les praticiennes Noûs : dates, lieux, tarifs et réservation."
        />
        <meta property="og:url" content="https://app-nous.fr/evenements" />
        <meta property="og:type" content="website" />
      </Helmet>

      <div className="container max-w-4xl mx-auto">
        <header className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-alice text-[#8B4513] mb-4">
            Événements
          </h1>
          <p className="text-[#A0522D] text-lg">
            Retraites, stages, immersions et formations proposés par nos
            praticiennes.
          </p>
        </header>

        <div className="grid gap-6">
          {evenements.map((ev) => (
            <Card
              key={ev.id}
              className="p-6 bg-white/60 border-sage-200"
              style={{ boxShadow: "0 8px 24px rgba(60, 40, 25, 0.18)" }}
            >
              <h2 className="text-2xl font-alice text-[#8B4513] mb-2">{ev.title}</h2>

              {ev.session && (
                <span className="inline-block text-xs font-semibold uppercase tracking-wide text-white bg-sage-600 rounded-full px-3 py-1 mb-4">
                  {ev.session}
                </span>
              )}

              {ev.method && (
                <div className="rounded-xl border border-sage-200 bg-sage-50 p-4 mb-4">
                  <p className="flex items-start gap-2 text-sm font-semibold text-[#8B4513] mb-1">
                    <Sparkles className="w-4 h-4 mt-0.5 shrink-0 text-sage-600" />
                    <span>{ev.method.name}</span>
                  </p>
                  <p className="text-sm text-[#5C3A1E] leading-relaxed">
                    {ev.method.text}
                  </p>
                </div>
              )}

              <p className="flex items-start gap-2 text-sm text-sage-700 mb-4">
                <Users className="w-4 h-4 mt-0.5 shrink-0" />
                <span>Organisé par {ev.organizers}</span>
              </p>

              <p className="text-warm-700 text-sm leading-relaxed mb-4 whitespace-pre-line">
                {ev.description}
              </p>

              <ul className="space-y-2 text-sm text-[#5C3A1E] mb-6">
                <li className="flex items-start gap-2">
                  <CalendarDays className="w-4 h-4 mt-0.5 shrink-0 text-sage-700" />
                  <span>{ev.dates}</span>
                </li>
                <li className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 mt-0.5 shrink-0 text-sage-700" />
                  <span>{ev.place}</span>
                </li>
                {ev.price && (
                  <li className="flex items-start gap-2">
                    <Euro className="w-4 h-4 mt-0.5 shrink-0 text-sage-700" />
                    <span>{ev.price}</span>
                  </li>
                )}
                {ev.pricingHref && (
                  <li className="flex items-start gap-2">
                    <FileText className="w-4 h-4 mt-0.5 shrink-0 text-sage-700" />
                    <a
                      href={ev.pricingHref}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="underline underline-offset-2 hover:text-sage-700"
                    >
                      {ev.pricingLabel ?? "Tarifs et modalités de règlement"}
                    </a>
                  </li>
                )}
                {ev.websiteHref && (
                  <li className="flex items-start gap-2">
                    <Globe className="w-4 h-4 mt-0.5 shrink-0 text-sage-700" />
                    <a
                      href={ev.websiteHref}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="underline underline-offset-2 hover:text-sage-700"
                    >
                      {ev.websiteLabel ?? ev.websiteHref}
                    </a>
                  </li>
                )}
              </ul>

              <Button
                asChild
                className="bg-sage-600 hover:bg-sage-700 text-white rounded-xl"
              >
                <a href={ev.bookingHref}>Réserver ma place</a>
              </Button>
            </Card>
          ))}
        </div>

        <p className="text-center text-sm mt-12 italic" style={{ color: "#C97A44" }}>
          D'autres événements arrivent bientôt…
        </p>
      </div>
    </div>
  );
};

export default Evenements;
