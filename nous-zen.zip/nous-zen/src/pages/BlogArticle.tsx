import { useEffect } from "react";
import { Link, useParams, Navigate } from "react-router-dom";
import { trackEventOnce } from "@/lib/track-event";
import { Helmet } from "react-helmet-async";
import { ArrowLeft } from "lucide-react";
import { articles } from "./Blog";

const RELATED_EXERCISE: Record<string, { to: string; label: string }> = {
  "stress-des-fetes-fin-annee-noel": { to: "/exercices/coherence-cardiaque", label: "Cohérence cardiaque" },
  "coherence-cardiaque": { to: "/exercices/coherence-cardiaque", label: "Cohérence cardiaque" },
  "sons-binauraux-cerveau-routine-bien-etre": { to: "/exercices/sons-binauraux", label: "Sons binauraux" },
  "reflexologie-des-mains-apaisement": { to: "/exercices/reflexologie-des-mains", label: "Réflexologie des mains" },
  "sophrologie-methode-douce": { to: "/exercices/meditation-guidee", label: "Méditations guidées" },
};

const articleContents: Record<string, JSX.Element> = {
  "stress-des-fetes-fin-annee-noel": (
    <>
      <p className="lead">
        Décembre approche, et avec lui les guirlandes, les listes de cadeaux, les repas qui s'enchaînent… et parfois une boule au ventre. Si l'idée des fêtes vous réjouit autant qu'elle vous épuise d'avance, rassurez-vous&nbsp;: vous n'êtes pas seul(e). La fin d'année concentre en quelques semaines la fatigue de l'hiver, la pression du « tout doit être parfait », les dépenses et les retrouvailles familiales, pas toujours simples. Plutôt qu'une liste de règles, voici un accompagnement en trois temps — avant, pendant et après les fêtes — pour vivre cette période avec un peu plus de douceur.
      </p>

      <h2>Pourquoi les fêtes sont-elles si stressantes&nbsp;?</h2>
      <p>
        Les fêtes sont un moment à part&nbsp;: on attend d'elles de la joie, de la chaleur, de la complicité. Cet idéal crée souvent un écart avec la réalité — un agenda surchargé, un budget serré, des sujets sensibles autour de la table, ou au contraire un sentiment de solitude. Ajoutez des journées courtes et un sommeil déjà fragilisé par l'hiver, et le corps reste en état d'alerte.
      </p>
      <p>
        Ce stress est le plus souvent passager. Il est utile de savoir le distinguer d'une anxiété plus diffuse et durable&nbsp;: notre article <Link to="/blog/stress-anxiete-difference">Stress et anxiété&nbsp;: comprendre la différence pour mieux agir</Link> vous aide à y voir plus clair.
      </p>

      <h2>Avant les fêtes&nbsp;: alléger la charge plutôt que tout porter</h2>
      <h3>Faire le tri dans les attentes</h3>
      <p>
        Prenez cinq minutes, une feuille et un stylo. Notez ce qui compte vraiment pour vous cette année&nbsp;: un repas en particulier, du temps avec une personne, du repos. Puis notez ce que vous faites « parce qu'il le faut ». Ce qui n'est ni important pour vous ni indispensable peut être simplifié, délégué ou laissé de côté.
      </p>
      <h3>Partager la charge mentale</h3>
      <p>
        Cadeaux, menus, décorations, organisation des trajets&nbsp;: la fin d'année repose souvent sur une ou deux personnes. Osez répartir les tâches à voix haute (« qui s'occupe du dessert&nbsp;? »), proposer un repas où chacun apporte un plat, ou un tirage au sort pour n'offrir qu'un cadeau par personne.
      </p>
      <h3>Protéger quelques créneaux pour vous</h3>
      <p>
        Inscrivez dans votre agenda, comme un rendez-vous, deux ou trois moments sans obligation par semaine. Même 10 minutes suffisent&nbsp;: une marche à la lumière du jour, une méditation guidée ou une séance de sons binauraux Alpha dans l'app Noûs pour relâcher la pression du jour.
      </p>

      <h2>Pendant les fêtes&nbsp;: rester ancré(e) au milieu de l'agitation</h2>
      <h3>Une respiration discrète avant de passer à table</h3>
      <p>
        Avant d'arriver chez vos proches, ou en vous isolant un instant dans la salle de bain, essayez la respiration carrée&nbsp;: inspirez 4 secondes, retenez 4 secondes, expirez 4 secondes, restez poumons vides 4 secondes. Trois ou quatre cycles suffisent pour retrouver un peu de calme. Si vous avez davantage de temps, la cohérence cardiaque 5-5 fonctionne très bien aussi — tout est expliqué dans <Link to="/blog/coherence-cardiaque">La cohérence cardiaque&nbsp;: respirez, votre cœur vous remerciera</Link>. Les deux exercices sont guidés dans l'app.
      </p>
      <h3>Préparer ses phrases-refuges</h3>
      <p>
        Une remarque sur votre vie, un débat qui s'enflamme&nbsp;? Gardez en tête une ou deux phrases simples et bienveillantes&nbsp;: « Je préfère qu'on parle d'autre chose ce soir », « On en reparlera au calme ». Vous n'avez pas à gagner la discussion&nbsp;: vous avez le droit de la quitter.
      </p>
      <h3>S'accorder des micro-pauses</h3>
      <p>
        Proposer de faire la vaisselle, sortir prendre l'air avec le chien, aller chercher le pain&nbsp;: ces petites parenthèses ne sont pas une fuite, mais une façon de recharger vos batteries. Pendant ce temps, massez doucement le creux de votre main entre le pouce et l'index&nbsp;: la réflexologie des mains proposée dans l'app Noûs se pratique en deux minutes, n'importe où.
      </p>
      <h3>Si vous passez les fêtes seul(e)</h3>
      <p>
        La solitude peut peser plus lourd à cette période. Prévoyez à l'avance un petit programme qui vous fait du bien&nbsp;: un appel à un ami, un film réconfortant, une balade, un repas que vous aimez. Les associations locales cherchent souvent des bénévoles pour les fêtes, une belle façon de créer du lien.
      </p>

      <h2>Après les fêtes&nbsp;: récupérer en douceur</h2>
      <h3>Retrouver son rythme de sommeil</h3>
      <p>
        Couchers tardifs et repas copieux bousculent souvent nos nuits. Revenez progressivement à vos horaires habituels et gardez un rituel calme le soir. Si vous vous réveillez en pleine nuit, l'esprit qui tourne, notre article <Link to="/blog/reveil-nocturne-3h-du-matin-se-rendormir">Réveil à 3 h du matin&nbsp;: pourquoi on se réveille la nuit et comment se rendormir</Link> propose des gestes doux. Les sons binauraux Delta de l'app peuvent aussi accompagner l'endormissement.
      </p>
      <h3>Faire le point sans vous juger</h3>
      <p>
        Une fois le calme revenu, demandez-vous ce qui vous a fait du bien et ce qui vous a pesé. Ces notes seront précieuses l'an prochain. Pour mesurer où vous en êtes, vous pouvez aussi faire le <a href="/?open=test-stress">test d'évaluation du stress</a> de l'app Noûs&nbsp;: quelques minutes suffisent.
      </p>
      <h3>Se faire accompagner si besoin</h3>
      <p>
        Si les fêtes ravivent des tensions familiales, un deuil ou une fatigue qui s'installe, parler à un professionnel peut vraiment aider. Les <Link to="/praticiens">praticiens certifiés Noûs</Link> — sophrologues, naturopathes, psychothérapeutes — vous reçoivent en cabinet, en visio ou par téléphone, même pendant les vacances. Grâce à l'agrément Services à la Personne, vos consultations ouvrent droit à un crédit d'impôt de 50 %&nbsp;: par exemple, une séance facturée 60 € vous revient à 30 € après crédit d'impôt (montant donné à titre d'exemple, chaque praticien fixe ses tarifs). Tous les détails sont dans <Link to="/blog/credit-impot-consultations-bien-etre">Crédit d'impôt de 50 % sur vos consultations bien-être&nbsp;: comment ça marche vraiment&nbsp;?</Link>.
      </p>
      <p>
        Et si des symptômes persistent après les fêtes — troubles du sommeil durables, tristesse qui ne passe pas, épuisement — n'hésitez pas à consulter votre médecin.
      </p>

      <h2>Pour conclure&nbsp;: des fêtes à votre mesure</h2>
      <p>
        Il n'existe pas de « bonnes » fêtes parfaites, seulement des fêtes qui vous ressemblent. En allégeant ce qui pèse avant, en vous ménageant des respirations pendant, et en prenant soin de vous après, décembre peut redevenir un temps de lien et de repos plutôt qu'une course.
      </p>
      <p>
        Téléchargez l'app Noûs pour garder vos exercices de respiration, méditations et sons binauraux à portée de main tout le mois, et si vous ressentez le besoin d'être accompagné(e), prenez rendez-vous avec un <Link to="/praticiens">praticien Noûs</Link>, avec 50 % de crédit d'impôt.
      </p>
      <p className="signature"><em>Noûs, le zen pour vous.</em></p>
    </>
  ),
  "reveil-nocturne-3h-du-matin-se-rendormir": (
    <>
      <p className="lead">
        Il est 3 h 12. Vous ouvrez les yeux, la maison est silencieuse, et votre esprit, lui, s'est déjà mis en route&nbsp;: la réunion de lundi, les cadeaux de Noël à prévoir, ce message auquel vous n'avez pas répondu. Une heure plus tard, vous êtes toujours éveillé(e). Si ce scénario vous parle, vous êtes loin d'être seul(e). En novembre, avec des nuits plus longues et une fin d'année qui se remplit, les réveils nocturnes font partie des plaintes les plus fréquentes. Bonne nouvelle&nbsp;: il existe des gestes simples pour mieux comprendre ces réveils et, surtout, pour se rendormir plus sereinement.
      </p>

      <h2>Pourquoi se réveille-t-on à 3 h du matin&nbsp;?</h2>
      <h3>Des micro-réveils tout à fait normaux</h3>
      <p>
        Le sommeil n'est pas une ligne droite. Il s'organise en cycles d'environ 90 minutes, et entre deux cycles, nous nous réveillons tous brièvement, plusieurs fois par nuit. La plupart du temps, nous ne nous en souvenons pas. Le problème n'est donc pas tant de se réveiller que de ne pas réussir à replonger.
      </p>
      <h3>Le milieu de nuit, un moment plus fragile</h3>
      <p>
        Vers 3 ou 4 h du matin, le sommeil devient naturellement plus léger&nbsp;: nous avons déjà « récupéré » une bonne partie du sommeil profond, et l'organisme commence doucement à se préparer au matin. À ce moment-là, la moindre source d'alerte suffit à nous garder éveillés&nbsp;: un bruit, une envie d'aller aux toilettes, une chambre trop chaude… ou une pensée.
      </p>
      <h3>Le stress qui se réveille avec vous</h3>
      <p>
        C'est souvent là que tout se joue. Les préoccupations de la journée, mises de côté pendant qu'on s'active, refont surface dans le calme de la nuit. Le cœur accélère un peu, le corps se met en vigilance, et les ruminations s'enchaînent. Si vous avez du mal à savoir si c'est plutôt du stress passager ou une inquiétude plus diffuse, notre article <Link to="/blog/stress-anxiete-difference">Stress et anxiété&nbsp;: comprendre la différence pour mieux agir</Link> peut vous aider à y voir plus clair.
      </p>
      <p>
        D'autres facteurs peuvent jouer&nbsp;: un café pris tard, un verre de vin le soir (qui aide à s'endormir mais fragilise la deuxième partie de nuit), un dîner copieux ou des écrans jusqu'au coucher.
      </p>

      <h2>Sur le moment&nbsp;: que faire pour se rendormir&nbsp;?</h2>
      <h3>Ne pas regarder l'heure</h3>
      <p>
        C'est le réflexe le plus courant… et le moins utile. Voir « 3 h 12 » s'afficher déclenche aussitôt le calcul (« il me reste 4 heures ») et une petite pression supplémentaire. Retournez votre réveil, laissez votre téléphone hors de portée et faites confiance à la nuit.
      </p>
      <h3>Respirer plutôt que lutter</h3>
      <p>
        Plus on « essaie » de dormir, plus le sommeil s'éloigne. Mieux vaut donner au corps un signal de calme. La respiration 4-7-8 est particulièrement adaptée&nbsp;: inspirez par le nez pendant 4 secondes, retenez doucement l'air pendant 7 secondes, puis expirez lentement par la bouche pendant 8 secondes. Répétez quatre à six fois, sans forcer. L'expiration longue aide à relâcher la vigilance. Dans l'app Noûs, vous pouvez suivre ce rythme guidé, ainsi que la respiration carrée (4-4-4-4) ou la cohérence cardiaque 5-5, détaillée dans notre article <Link to="/blog/coherence-cardiaque">La cohérence cardiaque&nbsp;: respirez, votre cœur vous remerciera</Link>.
      </p>
      <h3>Poser ses pensées quelque part</h3>
      <p>
        Si une liste de choses à faire tourne en boucle, gardez un carnet et un crayon près du lit. Notez-les en quelques mots, sans allumer la grande lumière. Le simple fait de les écrire envoie au cerveau un message rassurant&nbsp;: « c'est noté, on s'en occupe demain ».
      </p>
      <h3>Se laisser porter par un son doux</h3>
      <p>
        Certaines personnes se rendorment plus facilement avec un fond sonore apaisant. Les sons binauraux Delta, associés au sommeil profond, ou Theta, liés à la détente, peuvent accompagner ce moment, avec des écouteurs confortables et un volume très bas.
      </p>
      <h3>Sortir du lit si ça ne vient pas</h3>
      <p>
        Au bout d'une vingtaine de minutes éveillé(e), il vaut mieux se lever plutôt que de se retourner sans fin. Allez dans une autre pièce, en lumière tamisée, et faites quelque chose de calme&nbsp;: une méditation guidée, quelques pages d'un livre papier, un massage des points réflexes des mains. Revenez vous coucher dès que les paupières s'alourdissent. Ainsi, le lit reste associé au sommeil, et non à l'agitation.
      </p>

      <h2>En journée et le soir&nbsp;: préparer des nuits plus continues</h2>
      <p>Les réveils nocturnes se travaillent aussi en amont. Quelques habitudes peuvent faire une vraie différence&nbsp;:</p>
      <ul>
        <li><strong>Un « sas » de décompression avant le coucher.</strong> Dix minutes pour faire le point sur la journée et noter ce qui reste en suspens, afin de ne pas l'emporter sous la couette.</li>
        <li><strong>La lumière du matin.</strong> En novembre, une sortie de 15 à 20 minutes en matinée aide l'horloge interne à garder le bon rythme.</li>
        <li><strong>Des horaires réguliers.</strong> Se coucher et se lever à heures proches, même le week-end, stabilise les cycles de sommeil.</li>
        <li><strong>Une chambre fraîche et sombre.</strong> Autour de 18 °C, sans voyant lumineux ni téléphone sur la table de nuit.</li>
        <li><strong>Caféine et alcool avec modération.</strong> Idéalement pas de café après 14 h, et un dîner léger.</li>
        <li><strong>Un rituel apaisant.</strong> Une courte méditation guidée ou cinq minutes de cohérence cardiaque dans l'app Noûs, pour signaler au corps que la journée se termine.</li>
      </ul>
      <p>
        Pour aller plus loin sur ce qui se passe pendant la nuit et pourquoi le sommeil est si précieux, retrouvez notre article <Link to="/blog/sommeil-bien-etre">Sommeil et bien-être&nbsp;: pourquoi bien dormir change tout</Link>.
      </p>

      <h2>Quand se faire accompagner&nbsp;?</h2>
      <p>
        Un réveil nocturne de temps en temps n'a rien d'inquiétant. En revanche, si vos nuits sont hachées plusieurs fois par semaine depuis plus d'un mois, si la fatigue pèse sur vos journées, ou si vous ressentez des symptômes physiques (ronflements importants, palpitations, essoufflement, sueurs nocturnes), parlez-en d'abord à votre médecin. Il pourra rechercher une cause médicale et vous orienter.
      </p>
      <p>
        En parallèle, un accompagnement bien-être peut vous aider à apaiser le terrain qui entretient ces réveils&nbsp;: stress, ruminations, rythme de vie déséquilibré. Un ou une sophrologue vous apprendra des techniques de relâchement à utiliser en pleine nuit. Un ou une naturopathe regardera votre hygiène de vie globale (alimentation, rythme, énergie). Et si les pensées nocturnes sont lourdes, un psychothérapeute peut vous aider à dénouer ce qui se cache derrière.
      </p>
      <p>
        Sur Noûs, vous trouvez des <Link to="/praticiens">praticiens bien-être certifiés</Link> en cabinet, en visio ou par téléphone, ce qui est pratique quand on manque d'énergie pour se déplacer. Noûs étant agréé Services à la Personne, vos consultations ouvrent droit à un crédit d'impôt de 50 %&nbsp;: par exemple, une séance facturée 60 € vous reviendrait en réalité à 30 € (montant donné à titre d'exemple, chaque praticien fixe ses tarifs). Tout est expliqué dans notre article <Link to="/blog/credit-impot-consultations-bien-etre">Crédit d'impôt de 50 % sur vos consultations bien-être</Link>.
      </p>

      <h2>En résumé</h2>
      <p>
        Se réveiller à 3 h du matin n'est pas une fatalité. Ne pas regarder l'heure, respirer lentement, poser ses pensées sur papier et se lever si le sommeil tarde&nbsp;: ces gestes simples aident à traverser ces moments avec plus de douceur. Et dans la journée, quelques habitudes préparent des nuits plus continues.
      </p>
      <p>
        Envie de savoir si le stress joue un rôle dans vos nuits agitées&nbsp;? Faites notre <Link to="/?open=test-stress">test d'évaluation du stress</Link> en quelques minutes, puis essayez ce soir la respiration 4-7-8 ou une méditation guidée dans l'app Noûs. Et si vous souhaitez être accompagné(e), nos <Link to="/praticiens">praticiens certifiés</Link> sont là pour vous.
      </p>
      <p className="signature"><em>Noûs, le zen pour vous.</em></p>
    </>
  ),
  "meditation-debutant-comment-commencer": (
    <>
      <p className="lead">
        Novembre s'installe. Les vacances de la Toussaint sont derrière nous, la nuit tombe avant 18 h et l'on rentre souvent chez soi la tête encore pleine de la journée. C'est justement le bon moment pour essayer quelque chose de nouveau, de tout simple&nbsp;: quelques minutes de méditation.
      </p>
      <p>
        Vous avez peut-être déjà essayé, assis·e en tailleur, en attendant que « le vide se fasse »… et vous avez surtout pensé à vos courses, à un mail en retard ou à la machine à lancer. Rassurez-vous&nbsp;: c'est exactement ce qui arrive à tout le monde. Méditer, ce n'est pas arrêter de penser. Voici un guide pas à pas pour commencer en douceur, sans matériel, sans performance et sans culpabilité.
      </p>

      <h2>Méditer, ce n'est pas « faire le vide »</h2>
      <p>
        C'est l'idée reçue qui décourage le plus de débutants. En réalité, la plupart des pratiques de méditation consistent à <strong>poser son attention</strong> sur un point d'ancrage (la respiration, une voix, un son, une sensation) et à <strong>revenir</strong> vers lui chaque fois que l'esprit s'échappe.
      </p>
      <p>
        Ce retour est l'exercice lui-même. Si vous vous égarez vingt fois en cinq minutes et que vous revenez vingt fois, vous avez médité vingt fois. Il n'y a rien à réussir, seulement à remarquer.
      </p>

      <h2>Combien de temps méditer par jour quand on débute&nbsp;?</h2>
      <p>
        Moins que vous ne le pensez. Pour démarrer, <strong>3 à 5 minutes par jour</strong> suffisent largement. La régularité compte bien plus que la durée&nbsp;: cinq minutes chaque soir valent mieux qu'une heure une fois par mois.
      </p>
      <p>Une progression douce peut ressembler à ceci&nbsp;:</p>
      <ol>
        <li>Semaine 1&nbsp;: 3 minutes, une fois par jour.</li>
        <li>Semaine 2&nbsp;: 5 minutes.</li>
        <li>Semaine 3&nbsp;: 5 à 10 minutes, ou deux courtes pauses dans la journée.</li>
        <li>Ensuite&nbsp;: la durée qui vous fait du bien, sans objectif chiffré.</li>
      </ol>

      <h2>Votre première séance, pas à pas</h2>
      <p>Voici une pratique de 5 minutes que vous pouvez faire ce soir, sur une chaise ou au bord du lit.</p>
      <ol>
        <li><strong>Installez-vous</strong> le dos droit mais sans raideur, les pieds à plat, les mains posées sur les cuisses. Fermez les yeux ou laissez le regard tomber vers le sol.</li>
        <li><strong>Prenez trois respirations un peu plus amples</strong> que d'habitude, en laissant l'expiration s'allonger.</li>
        <li><strong>Laissez ensuite la respiration se faire seule.</strong> Observez simplement l'air qui entre et qui sort, au niveau des narines ou du ventre.</li>
        <li><strong>Quand une pensée arrive</strong>, notez-la mentalement d'un mot (« travail », « souvenir », « inquiétude »), puis revenez à la respiration, sans vous juger.</li>
        <li><strong>Terminez</strong> en reprenant conscience des bruits autour de vous, bougez doucement les doigts, puis ouvrez les yeux.</li>
      </ol>
      <p>
        Si le silence vous met mal à l'aise, commencez plutôt par une <strong>méditation guidée</strong>&nbsp;: une voix vous accompagne, ce qui aide beaucoup les premières semaines. C'est l'une des façons les plus simples d'utiliser l'app Noûs le soir.
      </p>

      <h2>« Je n'arrive pas à méditer »&nbsp;: les blocages les plus fréquents</h2>
      <h3>Mon esprit ne s'arrête jamais</h3>
      <p>
        C'est normal, et ce n'est pas un obstacle. Vous pouvez donner à votre attention un support plus « concret »&nbsp;: compter les respirations de 1 à 10, puis recommencer. Si votre concentration est déjà fragile au quotidien, notre article <Link to="/blog/perte-concentration-clarte-mentale">Pourquoi j'oublie tout et n'arrive plus à me concentrer&nbsp;?</Link> propose d'autres habitudes complémentaires.
      </p>
      <h3>Je m'endors</h3>
      <p>
        Signe que vous êtes fatigué·e, surtout en ce début d'hiver où la lumière baisse. Si vous souhaitez rester éveillé·e, méditez assis·e plutôt qu'allongé·e, ou en fin d'après-midi. Si au contraire vous cherchez à vous endormir, la méditation du soir peut devenir un joli rituel de coucher. Pour aller plus loin sur ce terrain, voyez nos <Link to="/blog/fatigue-automne-changement-saison">rituels contre la fatigue d'automne</Link>.
      </p>
      <h3>Je suis plus agité·e qu'avant</h3>
      <p>
        Prendre le temps de s'arrêter rend parfois plus visibles des tensions déjà présentes. Raccourcissez la séance, gardez les yeux ouverts, ou choisissez une pratique plus active comme la respiration rythmée. Si une agitation, une anxiété ou des troubles du sommeil persistent, parlez-en à votre médecin.
      </p>
      <h3>Je n'ai pas le temps</h3>
      <p>
        Accrochez la méditation à une habitude existante&nbsp;: après le café du matin, dans le bus (sans conduire&nbsp;!), ou juste avant de vous brosser les dents. Trois minutes suffisent.
      </p>

      <h2>Trois portes d'entrée quand le silence ne vous convient pas</h2>
      <p>
        La méditation assise n'est pas la seule voie. Selon votre tempérament, d'autres supports peuvent vous aider à vous poser, et ils sont tous dans l'app Noûs&nbsp;:
      </p>
      <ul>
        <li><strong>La respiration rythmée.</strong> La <Link to="/blog/coherence-cardiaque">cohérence cardiaque</Link> (5-5), la respiration carrée (4-4-4-4) ou la respiration 4-7-8 donnent un rythme à suivre. Parfait pour les esprits qui ont besoin d'une consigne précise.</li>
        <li><strong>Le son.</strong> Écouter des <Link to="/blog/sons-binauraux-cerveau-routine-bien-etre">sons binauraux</Link> au casque (Alpha, Theta, Delta ou 963 Hz) offre un fond sonore enveloppant sur lequel poser son attention.</li>
        <li><strong>Le toucher.</strong> Quelques minutes de réflexologie des mains ou un mini-jeu zen peuvent servir de « sas » avant de méditer, quand on est encore très tendu·e.</li>
      </ul>
      <p>
        Vous ne savez pas par où commencer&nbsp;? Le <Link to="/?open=test-stress">test d'évaluation du stress</Link> vous aide à faire le point en quelques questions.
      </p>

      <h2>Et si vous étiez accompagné·e&nbsp;?</h2>
      <p>
        Apprendre seul·e fonctionne très bien pour beaucoup de personnes. Mais un accompagnement peut faire gagner du temps, surtout si vous traversez une période de stress ou si vous ne savez pas quelle pratique vous correspond. Sur Noûs, des <Link to="/praticiens">praticiennes et praticiens certifiés</Link>, dont certains spécialisés en méditation ou en sophrologie, vous reçoivent en cabinet, en visio ou par téléphone.
      </p>
      <p>
        Grâce à l'agrément Services à la Personne de Noûs, vos consultations ouvrent droit à <strong>50&nbsp;% de crédit d'impôt</strong>. À titre d'exemple seulement&nbsp;: pour une séance facturée 60&nbsp;€, le coût réel après crédit d'impôt serait de 30&nbsp;€ (les tarifs varient selon chaque praticien·ne, à consulter sur sa fiche).
      </p>

      <h2>En résumé&nbsp;: commencez petit, commencez ce soir</h2>
      <p>
        Méditer quand on débute, ce n'est ni « faire le vide », ni réussir une performance. C'est s'accorder quelques minutes pour revenir à soi, encore et encore, avec bienveillance. Les longues soirées de novembre sont une belle occasion d'installer ce petit rituel avant l'agitation des fêtes.
      </p>
      <p>
        Ce soir, essayez simplement une méditation guidée de 5 minutes dans l'app Noûs. Et si vous avez envie d'être accompagné·e, découvrez les <Link to="/praticiens">praticiens certifiés Noûs</Link>, avec 50&nbsp;% de crédit d'impôt sur vos séances.
      </p>
      <p><em>Cet article est proposé à titre informatif et ne remplace pas un avis médical.</em></p>
      <p className="signature"><strong>Noûs, le zen pour vous.</strong></p>
    </>
  ),
  "naturopathie-hiver-conseils": (
    <>
      <p className="lead">
        L'heure d'hiver est arrivée, la lumière se fait rare et les premiers rhumes circulent au bureau comme à l'école. Beaucoup d'entre nous ressentent alors une baisse d'énergie, une envie de sucre ou de rester sous la couette. C'est normal&nbsp;: notre organisme s'adapte, lui aussi, au changement de saison.
      </p>
      <p>
        La naturopathie propose une approche douce et globale pour accompagner ce passage. Pas de recette miracle, mais des gestes simples, ancrés dans l'hygiène de vie, pour soutenir votre vitalité jusqu'au printemps.
      </p>

      <h2>La naturopathie, c'est quoi&nbsp;?</h2>
      <p>
        La naturopathie est une approche de bien-être qui s'appuie sur l'hygiène de vie&nbsp;: alimentation, sommeil, mouvement, gestion du stress et respiration. Le naturopathe ne pose pas de diagnostic et ne remplace pas votre médecin. Son rôle est de vous aider à retrouver des habitudes qui soutiennent votre équilibre, en tenant compte de votre rythme et de votre mode de vie.
      </p>
      <p>
        En hiver, l'idée est simple&nbsp;: ralentir un peu, nourrir le corps avec des aliments de saison, protéger son sommeil et prendre soin de son moral. Une logique proche de celle que nous développions dans <Link to="/blog/bien-etre-global-approches-complementaires">Bien-être global&nbsp;: quand plusieurs approches se complètent</Link>.
      </p>

      <h2>6 gestes de naturopathie pour traverser l'hiver</h2>
      <h3>1. Remplissez votre assiette de couleurs de saison</h3>
      <p>
        Courges, choux, poireaux, carottes, betteraves, agrumes, kiwis&nbsp;: l'hiver offre une belle variété de fruits et légumes. Privilégiez les plats chauds et mijotés (soupes, potages, légumes rôtis), plus réconfortants et faciles à digérer quand il fait froid. Pensez aussi aux oléagineux (noix, amandes) pour une collation rassasiante.
      </p>
      <h3>2. Allez chercher la lumière</h3>
      <p>
        Le manque de lumière influence notre horloge interne, notre énergie et notre humeur. Essayez de sortir au moins 20 à 30 minutes en journée, idéalement le matin, même par temps gris. Une marche à l'heure du déjeuner est un excellent réflexe. Nous en parlions dans <Link to="/blog/fatigue-automne-changement-saison">Fatigue d'automne&nbsp;: 7 rituels doux pour traverser le changement de saison</Link>.
      </p>
      <h3>3. Respectez le besoin de repos</h3>
      <p>
        En naturopathie, l'hiver est vu comme une saison de ressourcement. Se coucher un peu plus tôt, à heure régulière, n'est pas de la paresse&nbsp;: c'est écouter son corps. Une séance de respiration 4-7-8 ou des sons binauraux Delta dans l'app Noûs peuvent vous aider à glisser vers le sommeil. Pour aller plus loin&nbsp;: <Link to="/blog/sommeil-bien-etre">Sommeil et bien-être&nbsp;: pourquoi bien dormir change tout</Link>.
      </p>
      <h3>4. Hydratez-vous, même sans soif</h3>
      <p>
        On boit souvent moins en hiver, alors que le chauffage assèche l'air. Tisanes (thym, gingembre, romarin), eau tiède citronnée ou bouillons maison sont autant de façons agréables de s'hydrater tout en se réchauffant.
      </p>
      <h3>5. Bougez en douceur</h3>
      <p>
        Pas besoin de performance&nbsp;: marche, yoga, étirements ou quelques minutes de mouvement le matin suffisent à stimuler la circulation et l'énergie. L'essentiel est la régularité plus que l'intensité.
      </p>
      <h3>6. Prenez soin de votre moral</h3>
      <p>
        Le stress fatigue autant que le froid. Accordez-vous chaque jour un vrai moment de pause&nbsp;: 5 minutes de cohérence cardiaque, une méditation guidée ou quelques points de réflexologie des mains dans l'app Noûs. Ces petits rituels aident votre système nerveux à retrouver son calme.
      </p>

      <h2>Consulter un naturopathe&nbsp;: comment ça se passe&nbsp;?</h2>
      <p>
        Une première consultation dure généralement entre une heure et une heure trente. Le naturopathe prend le temps de faire le point avec vous&nbsp;: sommeil, alimentation, niveau d'énergie, stress, rythme de vie. Il vous propose ensuite un programme personnalisé et progressif, avec des conseils réalistes à intégrer à votre quotidien.
      </p>
      <p>
        Sur Noûs, vous pouvez par exemple consulter <Link to="/praticiens/camille-chopinot">Camille Chopinot</Link>, naturopathe certifié FENA, qui accompagne notamment la fatigue, les émotions et la recherche d'équilibre. Les séances ont lieu en cabinet, en visio ou par téléphone&nbsp;: pratique quand il fait froid ou que l'agenda déborde.
      </p>
      <h3>Un accompagnement plus accessible grâce au crédit d'impôt</h3>
      <p>
        Noûs est agréé Services à la Personne&nbsp;: vos consultations ouvrent droit à un crédit d'impôt de 50&nbsp;%. Par exemple, une séance facturée 70&nbsp;€ ne vous revient finalement qu'à 35&nbsp;€. Tous les détails sont dans notre article <Link to="/blog/credit-impot-consultations-bien-etre">Crédit d'impôt de 50&nbsp;% sur vos consultations bien-être&nbsp;: comment ça marche vraiment&nbsp;?</Link>
      </p>
      <p>
        <em>Important&nbsp;: la naturopathie est une approche complémentaire. Elle ne remplace pas un avis ou un traitement médical. Si vous ressentez une fatigue intense ou des symptômes qui persistent, consultez votre médecin. Demandez également conseil à un professionnel de santé avant de prendre des compléments alimentaires, surtout si vous suivez un traitement, êtes enceinte ou allaitez.</em>
      </p>

      <h2>En conclusion&nbsp;: l'hiver, une saison pour prendre soin de soi</h2>
      <p>
        L'hiver n'a pas à être une période à «&nbsp;tenir&nbsp;». Avec quelques gestes simples, une assiette colorée, un peu de lumière, du repos et des pauses pour respirer, il peut devenir un vrai moment de ressourcement. Choisissez un seul geste cette semaine, et ajoutez-en un autre quand il est devenu naturel.
      </p>
      <p>
        Pour vous accompagner au quotidien, retrouvez dans l'app Noûs les méditations guidées, la cohérence cardiaque et les sons binauraux. Faites le point avec notre <Link to="/?open=test-stress">test d'évaluation du stress</Link>, et si vous souhaitez un accompagnement personnalisé, prenez rendez-vous avec un <Link to="/praticiens">praticien certifié</Link>, avec 50&nbsp;% de crédit d'impôt.
      </p>
      <p className="signature"><em>Noûs, le zen pour vous.</em></p>
    </>
  ),
  "changement-heure-hiver-sommeil": (
    <>
      <h2>Une heure de plus… vraiment ?</h2>
      <p className="lead">
        Dans la nuit du samedi 24 au dimanche 25 octobre 2026, nous passerons à l'heure d'hiver : à 3 h du matin, il sera 2 h. Sur le papier, c'est une heure de sommeil « gagnée ». Dans la réalité, beaucoup d'entre nous ressentent pendant quelques jours un petit décalage : réveil trop matinal, coup de fatigue en fin d'après-midi, endormissement plus difficile, humeur un peu en berne.
      </p>
      <p>
        Rien d'alarmant : notre organisme a simplement besoin de quelques jours pour se réaccorder. Et avec un peu d'anticipation, cette transition peut se faire tout en douceur. Voici pourquoi le changement d'heure nous bouscule, et sept conseils simples pour l'apprivoiser.
      </p>

      <h2>Pourquoi le changement d'heure dérègle-t-il notre sommeil ?</h2>
      <h3>Une horloge interne qui n'aime pas les à-coups</h3>
      <p>
        Notre corps fonctionne selon un rythme d'environ 24 heures, appelé rythme circadien. Il règle l'alternance veille-sommeil, la température corporelle, l'appétit ou encore la sécrétion de mélatonine, l'hormone qui favorise l'endormissement. Le principal chef d'orchestre de cette horloge, c'est la lumière.
      </p>
      <p>
        Quand l'heure affichée change brusquement, notre horloge interne, elle, garde son tempo. Pendant quelques jours, les deux ne sont plus tout à fait synchronisées : c'est une sorte de mini décalage horaire, sans le voyage.
      </p>
      <h3>Des journées plus courtes et plus sombres</h3>
      <p>
        À l'heure d'hiver, la nuit tombe dès la fin d'après-midi. Moins de lumière naturelle en soirée, c'est aussi moins de stimulation pour rester en forme et, chez certaines personnes, une baisse d'énergie et de moral. Ce phénomène vient s'ajouter à la <Link to="/blog/fatigue-automne-changement-saison">fatigue d'automne</Link> que beaucoup ressentent déjà à cette période.
      </p>
      <h3>Qui est le plus sensible ?</h3>
      <p>
        Les jeunes enfants, les personnes âgées, les personnes qui dorment déjà mal ou qui traversent une période de stress ressentent souvent davantage ce décalage. Bonne nouvelle : pour la grande majorité d'entre nous, l'adaptation se fait naturellement en quelques jours à une semaine.
      </p>

      <h2>7 conseils doux pour vous adapter à l'heure d'hiver</h2>
      <h3>1. Décalez vos horaires progressivement</h3>
      <p>
        Dès le mercredi ou le jeudi précédent, couchez-vous et levez-vous 15 à 20 minutes plus tard chaque jour. Vos repas peuvent suivre le même mouvement. Le dimanche venu, votre horloge interne aura déjà fait une partie du chemin.
      </p>
      <h3>2. Faites le plein de lumière le matin</h3>
      <p>
        La lumière naturelle est le meilleur allié de votre rythme. Ouvrez grand les rideaux au réveil, prenez votre petit-déjeuner près d'une fenêtre et, si possible, offrez-vous 20 à 30 minutes de marche en extérieur dans la matinée ou à l'heure du déjeuner. Même par temps gris, la lumière du jour reste bien plus intense que celle d'une pièce éclairée.
      </p>
      <h3>3. Gardez une heure de lever régulière</h3>
      <p>
        Même si vous vous réveillez trop tôt les premiers jours, évitez de compenser par de longues grasses matinées ou des siestes tardives. Une heure de lever stable, y compris le week-end, aide votre organisme à retrouver ses repères. Si une sieste vous est nécessaire, limitez-la à 20 minutes, avant 15 h.
      </p>
      <h3>4. Apaisez vos soirées</h3>
      <p>
        Une heure avant le coucher, tamisez les lumières et mettez les écrans de côté : leur lumière bleue retarde la sécrétion de mélatonine. Préférez un rituel calme et répétitif : une tisane, quelques pages de lecture, une douche tiède. Vous trouverez d'autres pistes dans notre article <Link to="/blog/sommeil-bien-etre">Sommeil et bien-être : pourquoi bien dormir change tout</Link>.
      </p>
      <h3>5. Respirez pour ralentir</h3>
      <p>
        La respiration est un levier simple pour passer du mode « action » au mode « repos ». Dans l'app Noûs, essayez la respiration <strong>4-7-8</strong> au moment du coucher : inspirez 4 secondes, retenez 7 secondes, expirez lentement sur 8 secondes. En journée, quelques minutes de <Link to="/blog/coherence-cardiaque">cohérence cardiaque</Link> en 5-5 aident à relâcher la tension accumulée.
      </p>
      <h3>6. Laissez-vous porter par le son</h3>
      <p>
        Si votre mental tourne en boucle au moment de vous endormir, une méditation guidée ou une séance de sons binauraux peut vous aider à lâcher prise. Les fréquences Theta et Delta, disponibles dans l'app, accompagnent la détente profonde. Pour comprendre comment ils fonctionnent, lisez <Link to="/blog/sons-binauraux-cerveau-routine-bien-etre">notre article sur les sons binauraux</Link>.
      </p>
      <h3>7. Allez-y doucement avec le café et les dîners copieux</h3>
      <p>
        Pendant la semaine d'adaptation, évitez la caféine après 14 h et privilégiez un dîner léger, pris au moins deux heures avant le coucher. Une activité physique douce en journée (marche, yoga, étirements) favorise aussi un sommeil plus profond. Et pour un moment de détente express, l'auto-massage de <Link to="/blog/reflexologie-des-mains-apaisement">réflexologie des mains</Link> proposé dans l'app se pratique en quelques minutes, au lit ou dans le canapé.
      </p>

      <h2>Et pour les enfants ?</h2>
      <p>
        Les plus petits sont souvent les plus déboussolés, et leurs parents avec eux ! Tombant en pleines vacances de la Toussaint, ce changement d'heure est l'occasion d'ajuster le rythme en douceur : décalez le coucher de 10 à 15 minutes par jour, maintenez les rituels habituels (histoire, câlin, veilleuse) et sortez jouer dehors le matin. Pour vous, parents, une courte pause respiration dans la journée aide aussi à garder votre calme face aux réveils trop matinaux.
      </p>

      <h2>Quand demander de l'aide ?</h2>
      <p>
        Si, au bout d'une à deux semaines, vos difficultés de sommeil persistent, si la fatigue s'installe ou si votre moral reste durablement bas, parlez-en à votre médecin : il pourra faire le point avec vous.
      </p>
      <p>
        En complément, un accompagnement bien-être peut vous aider à retrouver des nuits plus sereines. Sophrologues, naturopathes, praticiens en méditation ou psychothérapeutes du réseau Noûs vous reçoivent en cabinet, en visio ou par téléphone. Grâce à l'agrément Services à la Personne de Noûs, vos consultations ouvrent droit à un <Link to="/blog/credit-impot-consultations-bien-etre">crédit d'impôt de 50 %</Link>. Découvrez les profils sur <Link to="/praticiens">la page praticiens</Link>, par exemple <Link to="/praticiens/nathalie-garnier">Nathalie Garnier</Link>, accompagnante bien-être et méditation, qui accompagne notamment les questions de sommeil, de stress et d'anxiété.
      </p>

      <h2>Une transition à accueillir en douceur</h2>
      <p>
        Le passage à l'heure d'hiver n'a rien d'une épreuve, à condition de l'accompagner avec bienveillance : un peu d'anticipation, beaucoup de lumière le matin, des soirées apaisées et quelques minutes de respiration suffisent souvent à retrouver votre rythme en quelques jours.
      </p>
      <p>
        Cette semaine, offrez-vous un moment pour faire le point : répondez à notre <Link to="/?open=test-stress">test d'évaluation du stress</Link>, essayez la respiration 4-7-8 ou une méditation guidée dans l'app Noûs avant de dormir, et si vous en ressentez le besoin, prenez rendez-vous avec <Link to="/praticiens">l'un de nos praticiens certifiés</Link>.
      </p>
      <p>
        <em>Ces conseils ne remplacent pas un avis médical. En cas de troubles du sommeil persistants, consultez votre médecin.</em>
      </p>
      <p className="signature"><em>Noûs, le zen pour vous.</em></p>
    </>
  ),
  "sophrologie-en-ligne-seance-credit-impot": (
    <>
      <p className="lead">
        Stress, fatigue, sommeil agité&nbsp;: beaucoup de personnes aimeraient essayer la sophrologie, mais hésitent. Est-ce que ça marche par écran interposé&nbsp;? Comment savoir si la praticienne est sérieuse&nbsp;? Et surtout, combien cela coûte-t-il&nbsp;? Voici des réponses simples.
      </p>

      <h2>Une séance en ligne, concrètement</h2>
      <p>
        Une séance dure 1 heure. Elle se fait en visio, depuis chez vous, assis ou allongé, au calme. La praticienne commence par échanger avec vous sur ce que vous traversez, puis vous guide&nbsp;: respiration, détente du corps, visualisations. Il n'y a rien à préparer, à part une connexion correcte et un endroit où vous ne serez pas dérangé(e). Beaucoup de personnes apprécient de pratiquer chez elles, car elles retrouvent ensuite plus facilement les exercices seules.
      </p>

      <h2>À qui s'adresse-t-elle&nbsp;?</h2>
      <p>
        La sophrologie est une méthode de détente et d'accompagnement. Elle peut aider à mieux gérer le stress, à préparer un moment important ou à retrouver un sommeil plus apaisé. Elle ne remplace pas un avis médical&nbsp;: en cas de symptômes persistants, parlez-en d'abord à votre médecin.
      </p>

      <h2>«&nbsp;Est-ce sérieux&nbsp;?&nbsp;»&nbsp;: comment choisir sa praticienne</h2>
      <p>
        Le titre de sophrologue n'est pas protégé par la loi en France&nbsp;: n'importe qui peut l'utiliser. Il vaut donc la peine de vérifier trois choses&nbsp;:
      </p>
      <ul>
        <li>une formation et une certification reconnues, avec une mention RNCP (Répertoire national des certifications professionnelles)&nbsp;;</li>
        <li>une présentation claire de son parcours et de ses méthodes&nbsp;;</li>
        <li>des avis de clientes réelles.</li>
      </ul>
      <p>
        Sur Noûs, les praticiennes sont certifiées et présentées avec leur parcours&nbsp;: vous pouvez les découvrir sur la page <Link to="/praticiens">Praticiens</Link>.
      </p>

      <h2>Combien coûte une séance, et que reste-t-il à payer&nbsp;?</h2>
      <p>
        Les séances de sophrologie ne sont pas remboursées par l'Assurance maladie. Sur Noûs, une séance d'1 heure est à 75 €. Notre service est agréé services à la personne, ce qui ouvre droit à un crédit d'impôt de 50&nbsp;%&nbsp;: il vous reste donc 37,50 € à votre charge, que ce soit en visio, par téléphone ou au cabinet. Le détail du fonctionnement est dans notre article <Link to="/blog/credit-impot-consultations-bien-etre">Crédit d'impôt de 50&nbsp;% sur vos consultations bien-être&nbsp;: comment ça marche vraiment&nbsp;?</Link>
      </p>

      <h2>Comment commencer</h2>
      <p>
        Choisissez une praticienne selon ce que vous cherchez, réservez une séance en visio, et installez-vous au calme. Pour patienter, vous pouvez essayer gratuitement nos <Link to="/exercices">exercices de respiration et de relaxation</Link>.
      </p>

      <p className="cta">
        <Link
          to="/praticiens"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          Découvrir nos praticiennes
        </Link>
      </p>

      <p className="signature"><em>Noûs, le zen pour vous.</em></p>
    </>
  ),
  "burn-out-signes-alerte": (
    <>
      <p className="lead">
        La rentrée est déjà loin, les journées raccourcissent, et pourtant la fatigue, elle, ne passe pas. Vous vous levez aussi épuisé·e que vous vous êtes couché·e, vous avez l'impression de courir après le temps et le moindre imprévu vous semble insurmontable&nbsp;? Vous n'êtes pas seul·e.
      </p>
      <p>
        La Journée mondiale de la santé mentale, célébrée chaque 10 octobre, nous rappelle qu'il est essentiel d'écouter ces signaux. Le burn-out ne survient pas du jour au lendemain&nbsp;: il s'installe progressivement, souvent en silence. Apprendre à reconnaître ses premiers signes, c'est se donner la possibilité de ralentir avant l'épuisement. Voici 8 signaux à ne pas négliger, et des pistes douces pour prendre soin de vous.
      </p>

      <h2>Le burn-out, c'est quoi exactement&nbsp;?</h2>
      <p>
        Le burn-out, ou syndrome d'épuisement professionnel, est un état d'épuisement physique, émotionnel et mental lié à un stress chronique, le plus souvent au travail. L'Organisation mondiale de la santé le décrit autour de trois dimensions&nbsp;: une fatigue profonde, une prise de distance (voire du cynisme) vis-à-vis de son activité, et un sentiment de moindre efficacité.
      </p>
      <p>
        Il ne concerne pas que les salariés. Indépendants, soignants, enseignants, aidants familiaux ou parents qui jonglent entre mille responsabilités peuvent aussi s'y retrouver.
      </p>

      <h3>Stress, fatigue ou burn-out&nbsp;: comment faire la différence&nbsp;?</h3>
      <p>
        Un stress ponctuel peut être stimulant&nbsp;: il mobilise notre énergie face à un défi, puis retombe. Le burn-out, lui, survient quand cette tension devient permanente et que les temps de récupération ne suffisent plus. Le repos d'un week-end ne recharge plus les batteries. Pour mieux comprendre ces mécanismes, vous pouvez lire notre article <Link to="/blog/stress-anxiete-difference">Stress et anxiété&nbsp;: comprendre la différence pour mieux agir</Link>.
      </p>

      <h2>Les 8 signes qui doivent vous alerter</h2>
      <p>
        Chacun de ces signes, pris isolément, peut avoir bien d'autres causes. C'est leur accumulation et leur durée, sur plusieurs semaines, qui méritent votre attention.
      </p>
      <h3>1. Une fatigue que rien ne répare</h3>
      <p>
        Vous dormez, vous prenez des jours de repos, et pourtant l'énergie ne revient pas. Cette fatigue est physique, mais aussi mentale&nbsp;: tout demande un effort.
      </p>
      <h3>2. Un sommeil perturbé</h3>
      <p>
        Difficultés à vous endormir, réveils nocturnes avec la tête qui tourne, réveil très matinal… Le sommeil est souvent l'un des premiers à se dérégler. Nous y avons consacré un article&nbsp;: <Link to="/blog/sommeil-bien-etre">Sommeil et bien-être&nbsp;: pourquoi bien dormir change tout</Link>.
      </p>
      <h3>3. Une irritabilité inhabituelle</h3>
      <p>
        Vous vous surprenez à vous agacer pour un rien, avec vos collègues comme avec vos proches. Votre patience semble s'être évaporée.
      </p>
      <h3>4. Des difficultés de concentration</h3>
      <p>
        Vous relisez trois fois le même e-mail, vous oubliez des rendez-vous, les décisions simples deviennent compliquées. Le cerveau, saturé, peine à trier l'information.
      </p>
      <h3>5. Une perte de sens et de motivation</h3>
      <p>
        Ce qui vous passionnait vous laisse indifférent·e. Vous accomplissez vos tâches de façon mécanique, avec le sentiment que « à quoi bon ».
      </p>
      <h3>6. Un sentiment d'inefficacité</h3>
      <p>
        Malgré vos efforts, vous avez l'impression de ne jamais en faire assez, ou de mal faire. La confiance en vous s'érode peu à peu.
      </p>
      <h3>7. Des signaux dans le corps</h3>
      <p>
        Tensions dans la nuque et les épaules, maux de tête, troubles digestifs, rhumes à répétition… Le corps exprime souvent ce que l'esprit n'ose pas encore formuler.
      </p>
      <h3>8. Le repli sur soi</h3>
      <p>
        Vous annulez les sorties, vous n'avez plus envie de voir vos amis, vous vous isolez. Ce retrait est souvent une façon de préserver le peu d'énergie qui reste.
      </p>

      <h2>Vous vous reconnaissez&nbsp;? 5 gestes doux pour commencer dès aujourd'hui</h2>
      <h3>Faire le point sur votre niveau de stress</h3>
      <p>
        Avant tout, prenez quelques minutes pour évaluer où vous en êtes. Le <Link to="/?open=test-stress">test d'évaluation du stress de Noûs</Link> vous aide à mettre des mots sur ce que vous ressentez. Ce n'est pas un diagnostic, mais un premier repère pour savoir s'il est temps de vous faire accompagner.
      </p>
      <h3>Respirer pour calmer le système nerveux</h3>
      <p>
        Quelques minutes de respiration consciente suffisent à envoyer un signal d'apaisement à votre corps. Dans l'app Noûs, essayez la cohérence cardiaque 5-5 (inspirez 5 secondes, expirez 5 secondes, pendant 5 minutes), trois fois par jour. Le soir, la respiration 4-7-8 peut vous aider à lâcher prise avant de dormir. Pour en savoir plus&nbsp;: <Link to="/blog/coherence-cardiaque">La cohérence cardiaque&nbsp;: respirez, votre cœur vous remerciera</Link>.
      </p>
      <h3>Créer de vraies pauses dans la journée</h3>
      <p>
        Une pause, ce n'est pas faire défiler son téléphone entre deux réunions. Offrez-vous 5 minutes de méditation guidée, un mini-jeu zen pour détourner votre attention, ou quelques pressions de réflexologie des mains, discrètes et faciles à pratiquer au bureau.
      </p>
      <h3>Protéger vos soirées et votre sommeil</h3>
      <p>
        Fixez une heure après laquelle vous ne consultez plus vos e-mails professionnels. Au coucher, les sons binauraux Delta ou Theta de l'app peuvent accompagner l'endormissement dans une atmosphère apaisante.
      </p>
      <h3>Oser dire non et en parler</h3>
      <p>
        Apprendre à poser des limites est un vrai acte de soin. Parlez de ce que vous vivez à une personne de confiance&nbsp;: un proche, un collègue, votre manager. Mettre des mots sur sa fatigue, c'est déjà commencer à s'en libérer.
      </p>

      <h2>Se faire accompagner&nbsp;: vous n'avez pas à traverser cela seul·e</h2>
      <h3>Commencez par consulter votre médecin</h3>
      <p>
        Si plusieurs de ces signes persistent depuis des semaines, ou si vous vous sentez dépassé·e, prenez rendez-vous avec votre médecin traitant. Lui seul peut poser un diagnostic, écarter d'autres causes et, si besoin, vous proposer un arrêt de travail ou un suivi adapté. Les approches bien-être viennent en complément, jamais en remplacement d'un avis médical.
      </p>
      <h3>Les praticiens Noûs, en complément</h3>
      <p>
        Pour retrouver de l'énergie et des repères, un accompagnement bien-être peut faire une vraie différence&nbsp;:
      </p>
      <ul>
        <li><strong>La sophrologie</strong> aide à relâcher les tensions et à retrouver un sommeil plus serein grâce à la respiration et à la détente.</li>
        <li><strong>La psychothérapie</strong> offre un espace pour comprendre ce qui vous a mené·e à l'épuisement et reconstruire un rapport plus juste au travail.</li>
        <li><strong>La naturopathie</strong> accompagne l'hygiène de vie&nbsp;: alimentation, rythme, récupération.</li>
        <li><strong>Le coaching santé</strong> vous aide à poser des limites et à construire un plan concret, pas à pas.</li>
      </ul>
      <p>
        Sur <Link to="/praticiens">app-nous.fr/praticiens</Link>, vous trouverez des praticiens certifiés, disponibles en cabinet, en visio ou par téléphone. Certains accompagnent spécifiquement le burn-out, comme <Link to="/praticiens/sophie-clouet">Sophie Clouet</Link>, coach santé certifiée RNCP.
      </p>
      <h3>50&nbsp;% de crédit d'impôt sur vos séances</h3>
      <p>
        Grâce à l'agrément Services à la Personne de Noûs, vos consultations ouvrent droit à un crédit d'impôt de 50&nbsp;%. Une séance à 60 € ne vous revient ainsi qu'à 30 €. Tous les détails sont dans notre article <Link to="/blog/credit-impot-consultations-bien-etre">Crédit d'impôt de 50&nbsp;% sur vos consultations bien-être&nbsp;: comment ça marche vraiment&nbsp;?</Link>
      </p>

      <h2>Ralentir n'est pas un échec, c'est un premier pas</h2>
      <p>
        Le burn-out n'est ni une faiblesse ni un manque de volonté. C'est le signal qu'un équilibre s'est rompu et qu'il est temps de prendre soin de vous. Plus ces signes sont repérés tôt, plus il est facile de retrouver de l'élan.
      </p>
      <p>
        Pour commencer dès aujourd'hui, <Link to="/?open=test-stress">faites le test d'évaluation du stress</Link>, lancez une séance de cohérence cardiaque dans l'app, et si vous sentez que le moment est venu, <Link to="/praticiens">trouvez le praticien qui vous correspond</Link>.
      </p>
      <p className="signature"><em>Noûs, le zen pour vous.</em></p>
      <hr />
      <p><em>Cet article est proposé à titre informatif et ne remplace pas un avis médical. En cas de symptômes persistants, consultez votre médecin.</em></p>
    </>
  ),
  "psychotherapie-en-ligne-comment-ca-se-passe": (
    <>
      <p className="lead">
        Vous envisagez de consulter un psychothérapeute, mais l'idée de le faire
        par écran vous laisse perplexe&nbsp;? Se faire accompagner en visio est
        aujourd'hui une pratique courante. Voici comment se déroule concrètement
        une séance de psychothérapie en ligne, ses avantages, ses limites et
        comment bien choisir votre praticien.
      </p>

      <h2>Qu'est-ce que la psychothérapie en ligne&nbsp;?</h2>
      <p>
        C'est un accompagnement psychologique mené avec un psychothérapeute, non
        pas dans un cabinet, mais en visio ou par téléphone. Le principe est le
        même qu'en face à face&nbsp;: un espace de parole confidentiel, pour
        mieux comprendre ce que vous traversez et avancer à votre rythme.
      </p>
      <p>
        Une précision importante&nbsp;: la psychothérapie en ligne n'est pas
        adaptée aux situations d'urgence. En cas de détresse ou de danger
        immédiat, appelez le 15 ou le 3114, le numéro national de prévention du
        suicide, gratuit et ouvert 24&nbsp;heures sur 24.
      </p>

      <h2>Comment se déroule une séance&nbsp;?</h2>
      <ul>
        <li>
          <strong>Le premier rendez-vous</strong>&nbsp;: vous faites connaissance
          avec le praticien, vous expliquez ce qui vous amène et ce que vous
          attendez de l'accompagnement. C'est aussi le moment de poser vos
          questions sur sa façon de travailler.
        </li>
        <li>
          <strong>Les séances suivantes</strong>&nbsp;: elles durent en général
          de 45 minutes à 1&nbsp;heure. Le rythme est défini avec le praticien,
          selon vos besoins.
        </li>
        <li>
          <strong>Le cadre</strong>&nbsp;: la séance a lieu à heure fixe, par
          visio ou par téléphone, depuis l'endroit de votre choix.
        </li>
      </ul>

      <h2>Bien préparer sa séance en visio</h2>
      <ul>
        <li>
          Choisissez un endroit au calme, où vous ne serez pas dérangé(e).
        </li>
        <li>
          Vérifiez votre connexion et testez votre caméra et votre micro avant
          l'heure du rendez-vous.
        </li>
        <li>
          Utilisez un casque ou des écouteurs pour préserver la confidentialité.
        </li>
        <li>Prévoyez un moment de calme avant et après la séance.</li>
      </ul>

      <h2>Avantages et limites</h2>
      <p>
        <strong>Les avantages</strong>&nbsp;: pas de déplacement, des horaires
        plus souples, et un accès au praticien même loin de chez vous. Beaucoup
        de personnes se sentent aussi plus à l'aise pour se confier depuis chez
        elles.
      </p>
      <p>
        <strong>Les limites</strong>&nbsp;: il faut une connexion stable et un
        endroit où l'on peut parler librement. Certaines personnes préfèrent le
        contact en face à face&nbsp;; sur Noûs, des praticiens proposent aussi
        des séances en cabinet.
      </p>

      <h2>Comment choisir son psychothérapeute</h2>
      <ul>
        <li>
          <strong>Le titre</strong>&nbsp;: en France, le titre de psychothérapeute
          est réglementé. Le praticien doit être inscrit au registre national des
          psychothérapeutes, tenu par l'Agence régionale de santé (ARS). N'hésitez
          pas à lui demander son inscription.
        </li>
        <li>
          <strong>Son approche</strong>&nbsp;: demandez-lui comment il travaille
          et pour quels types de difficultés.
        </li>
        <li>
          <strong>Le premier échange</strong>&nbsp;: la confiance se construit
          dès le début. Si vous vous sentez écouté(e) et à l'aise, c'est bon
          signe.
        </li>
        <li>
          <strong>Le tarif</strong>&nbsp;: réservée via Noûs, une consultation
          ouvre droit au crédit d'impôt de 50&nbsp;%. Par exemple, une séance à
          90&nbsp;€ revient à 45&nbsp;€ une fois le crédit d'impôt reçu.{" "}
          <Link to="/blog/credit-impot-consultations-bien-etre">
            Tous les détails sur le crédit d'impôt
          </Link>
          .
        </li>
      </ul>

      <h2>En résumé</h2>
      <p>
        La psychothérapie en ligne offre le même cadre de confiance qu'en
        cabinet, avec plus de souplesse. L'essentiel est de choisir un praticien
        inscrit et avec qui vous vous sentez à l'aise. Pour mieux comprendre ce
        que vous ressentez avant de vous lancer, lisez aussi notre article{" "}
        <Link to="/blog/stress-anxiete-difference">
          Stress et anxiété&nbsp;: comprendre la différence pour mieux agir
        </Link>
        .
      </p>

      <p className="cta">
        <Link
          to="/praticiens"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Découvrir nos praticiens certifiés
        </Link>
      </p>
      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
  "fatigue-automne-changement-saison": (
    <>
      <h2>Quand l'automne s'installe en nous</h2>
      <p className="lead">
        Les journées raccourcissent, le réveil sonne dans la pénombre, et l'envie de rester sous la couette se fait plus pressante. Si vous vous sentez plus las, plus irritable ou moins motivé depuis quelques semaines, vous n'êtes pas seul : le passage à l'automne est l'un des moments de l'année où le corps et l'esprit doivent le plus s'adapter.
      </p>
      <p>
        Cette fatigue n'est ni un caprice ni un manque de volonté. C'est le signe que votre organisme se règle sur un nouveau rythme. La bonne nouvelle : quelques gestes simples suffisent souvent à l'accompagner en douceur.
      </p>

      <h2>Ce qui se passe dans le corps</h2>
      <p>
        Notre horloge interne, le rythme circadien, se cale en grande partie sur la lumière du jour. Quand elle diminue, le cerveau produit de la mélatonine (l'hormone du sommeil) plus tôt le soir et plus tard le matin. Résultat : on se sent somnolent à des heures inhabituelles et le réveil devient plus laborieux.
      </p>
      <p>
        La baisse de luminosité peut aussi jouer sur la sérotonine, impliquée dans l'humeur et la motivation. Ajoutez à cela la reprise d'un rythme soutenu après l'été et le passage à l'heure d'hiver fin octobre : le terrain est idéal pour une petite baisse de régime.
      </p>
      <p>
        À savoir : si la fatigue est intense, dure plusieurs semaines ou s'accompagne d'une tristesse persistante, parlez-en à votre médecin. Ces signes méritent un avis médical.
      </p>

      <h2>7 rituels doux pour traverser la saison</h2>
      <h3>1. Faire le plein de lumière le matin</h3>
      <p>
        Sortez 20 à 30 minutes en début de journée, même par temps gris : la lumière extérieure reste bien plus intense que celle d'un intérieur. Une marche jusqu'à la boulangerie ou un café près d'une fenêtre suffit à envoyer à votre horloge interne le signal « c'est le matin ».
      </p>

      <h3>2. Garder des horaires de sommeil réguliers</h3>
      <p>
        Se coucher et se lever à heures fixes, y compris le week-end, aide le corps à s'ajuster. Pour préparer le passage à l'heure d'hiver, décalez progressivement votre coucher de 10 minutes par jour la semaine précédente. Pour aller plus loin, lisez notre article <Link to="/blog/sommeil-bien-etre">Sommeil et bien-être : pourquoi bien dormir change tout</Link>.
      </p>

      <h3>3. Respirer pour relancer l'énergie</h3>
      <p>
        Trois fois par jour, prenez 5 minutes pour la cohérence cardiaque : inspirez 5 secondes, expirez 5 secondes. Cet exercice simple aide à réguler le stress et à retrouver un état plus stable. Dans l'app Noûs, les exercices guidés (rythme 5-5, respiration carrée, 4-7-8) vous accompagnent pas à pas. Tout savoir dans <Link to="/blog/coherence-cardiaque">La cohérence cardiaque : respirez, votre cœur vous remerciera</Link>.
      </p>

      <h3>4. Bouger, même un peu</h3>
      <p>
        Pas besoin d'un programme intensif : 20 minutes de marche, quelques étirements au réveil ou une séance de yoga doux réveillent la circulation et l'énergie. L'idéal est de bouger dehors, pour cumuler mouvement et lumière.
      </p>

      <h3>5. Remettre de la couleur dans l'assiette</h3>
      <p>
        L'automne offre des produits riches et réconfortants : courges, champignons, pommes, noix, légumes verts. Privilégiez des repas chauds et variés, et limitez les sucres rapides qui donnent un coup de fouet suivi d'un coup de barre.
      </p>

      <h3>6. S'offrir des pauses de calme</h3>
      <p>
        Quand la fatigue s'installe, l'esprit s'agite plus facilement. Une méditation guidée de 10 minutes ou une séance d'écoute de sons binauraux (ondes Alpha pour la détente, Delta pour le sommeil) peut aider à relâcher la pression. Ces contenus sont disponibles dans l'app Noûs. En savoir plus : <Link to="/blog/sons-binauraux-cerveau-routine-bien-etre">Sons binauraux : comment ils agissent sur le cerveau</Link>.
      </p>

      <h3>7. Créer un cocon le soir</h3>
      <p>
        Lumière tamisée, écrans rangés une heure avant le coucher, tisane, lecture : ces petits rituels annoncent au cerveau que la journée se termine. L'automne invite au ralentissement, autant l'accueillir plutôt que de lutter contre.
      </p>

      <h2>Et si vous vous faisiez accompagner ?</h2>
      <p>
        Parfois, les bonnes résolutions ne suffisent pas, ou l'on a besoin d'un regard extérieur pour retrouver son équilibre. Un naturopathe peut vous aider à adapter votre hygiène de vie à la saison, un sophrologue à apaiser le stress et à mieux récupérer.
      </p>
      <p>
        Sur Noûs, vous trouvez des <Link to="/praticiens">praticiens bien-être certifiés</Link>, en cabinet, en visio ou par téléphone. Grâce à l'agrément Services à la Personne, vos consultations ouvrent droit à un crédit d'impôt de 50 %. Tous les détails dans <Link to="/blog/credit-impot-consultations-bien-etre">Crédit d'impôt de 50 % sur vos consultations bien-être</Link>.
      </p>

      <h2>En résumé</h2>
      <p>
        La fatigue d'automne est une adaptation naturelle, pas une fatalité. Lumière le matin, sommeil régulier, respiration, mouvement, assiette colorée, pauses de calme et soirées cocooning : choisissez un ou deux rituels cette semaine et ajoutez-en d'autres au fil des jours.
      </p>
      <p>
        Et pour savoir où vous en êtes, faites notre <Link to="/?open=test-stress">test d'évaluation du stress</Link>. Retrouvez méditations, exercices de respiration et sons binauraux dans l'app Noûs, disponible sur l'App Store et Google Play.
      </p>
      <p className="signature"><em>Noûs, le zen pour vous.</em></p>
    </>
  ),
  "reflexologie-des-mains-apaisement": (
    <>
      <p className="lead">
        On pense souvent que la réflexologie se pratique uniquement sur les
        pieds, allongé sur une table de massage. C'est oublier qu'elle existe
        aussi pour les mains, et qu'elle a un avantage de taille&nbsp;: on peut
        la faire n'importe où, en quelques minutes, sans même retirer ses
        chaussures.
      </p>

      <h2>Un principe issu de la médecine traditionnelle chinoise</h2>
      <p>
        Selon cette approche, l'énergie vitale, le Qi, circule dans le corps le
        long de méridiens précis. Les mains, tout comme les pieds, concentrent
        un grand nombre de terminaisons nerveuses reliées à ces méridiens. En
        stimulant certains points par pression ou massage, on agirait sur les
        organes et fonctions qui leur sont associés&nbsp;: digestion, tension
        du dos, gestion du stress, ou encore l'activité mentale liée aux
        ruminations.
      </p>

      <h2>Est-ce que ça marche vraiment&nbsp;?</h2>
      <p>
        Au sens médical strict, la science occidentale reste prudente, faute
        d'études assez solides pour valider tous les mécanismes avancés. Mais
        l'effet sur la détente, lui, est largement documenté&nbsp;: masser ses
        mains quelques minutes active la circulation sanguine, relâche les
        tensions musculaires accumulées dans la paume et les doigts, et
        surtout, offre une vraie pause. Le simple fait de s'arrêter, de poser
        son attention sur ses mains et sa respiration, a un effet apaisant qui
        n'a pas besoin d'explication énergétique pour être réel.
      </p>

      <h2>Une pratique accessible à tous</h2>
      <p>
        Pas besoin d'être souple, ni de s'isoler dans une pièce silencieuse.
        Deux minutes suffisent, entre deux réunions, avant de dormir, ou en
        attendant que le café passe. On presse le point situé entre le pouce et
        l'index, on masse la base de chaque doigt, on étire doucement la paume.
        Rien de compliqué, mais un rituel qui, répété, devient un vrai outil de
        régulation du stress au quotidien.
      </p>
      <p>
        La médecine chinoise parle d'équilibre entre le corps et l'esprit&nbsp;:
        prendre deux minutes pour soi, masser ses mains en conscience, c'est
        une façon de se reconnecter à son corps et de faire retomber la
        pression, même dans une journée bien remplie.
      </p>

      <p className="cta">
        <Link
          to="/exercices?categorie=reflexologie"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Essayer les exercices de réflexologie des mains
        </Link>
      </p>

      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
  "credit-impot-consultations-bien-etre": (
    <>
      <p className="lead">
        Vous avez peut-être déjà vu passer cette information&nbsp;: les
        consultations réservées via Noûs peuvent ouvrir droit à un crédit
        d'impôt de 50&nbsp;%. Mais comment est-ce possible, alors qu'un
        thérapeute en libéral classique n'offre généralement pas cet
        avantage&nbsp;? Explication simple.
      </p>

      <h2>Le principe : ce n'est pas le praticien qui est agréé, c'est Noûs</h2>
      <p>
        C'est le point clé à comprendre. Un thérapeute (sophrologue,
        psychothérapeute...) qui exerce seul en libéral n'est généralement pas
        éligible au dispositif Services à la Personne (SAP), à quelques
        exceptions près (coachs sportifs ou professeurs de yoga qui peuvent
        parfois obtenir leur propre agrément).
      </p>
      <p>
        Noûs fonctionne différemment&nbsp;: NEOVIE, la structure qui édite
        l'application, est elle-même agréée Services à la Personne. Noûs joue
        le rôle de prestataire qui met en relation les clients avec des
        praticiens, entièrement en ligne. C'est cette mise en relation via une
        structure agréée qui rend toutes les consultations réservées sur Noûs
        éligibles au crédit d'impôt, quel que soit le praticien consulté dans
        l'annuaire.
      </p>

      <h2>Comment ça se passe concrètement</h2>
      <p>
        Ce dispositif est encadré par l'article 199 sexdecies du Code Général
        des Impôts (CGI). Contrairement à une simple déduction qui viendrait
        réduire le montant de votre impôt sur le calcul, ce crédit d'impôt
        fonctionne comme un remboursement réel&nbsp;: vous réglez le montant
        plein de votre consultation, puis vous déclarez la dépense lors de
        votre déclaration de revenus l'année suivante. Le crédit d'impôt de
        50&nbsp;% vous est ensuite versé directement par virement ou chèque,
        généralement entre fin juillet et début août de l'année suivante, que
        vous soyez imposable ou non.
      </p>
      <p>
        <strong>Exemple concret&nbsp;:</strong> une consultation à 60&nbsp;€
        vous revient, une fois le crédit d'impôt reçu l'été suivant, à un coût
        réel de 30&nbsp;€.
      </p>

      <h2>Sophrologie, naturopathie, psychothérapie : sont-elles éligibles&nbsp;?</h2>
      <p>
        Une séance de sophrologie, de naturopathie ou de psychothérapie réglée
        directement à un praticien en libéral n'ouvre en général pas droit au
        crédit d'impôt. Réservée via Noûs, elle y ouvre droit&nbsp;: la facture
        est émise par NEOVIE, structure agréée Services à la Personne, et non
        par le praticien. Il en va de même que la séance ait lieu en cabinet,
        en visio ou par téléphone.
      </p>

      <h2>Un plafond à connaître</h2>
      <p>
        Ce crédit d'impôt s'inscrit dans le cadre plus large des services à la
        personne, qui inclut aussi la garde d'enfants, le jardinage, ou l'aide
        à domicile. Le plafond global est fixé à 12&nbsp;000&nbsp;€ de dépenses
        par an, toutes ces catégories confondues&nbsp;: ce n'est donc pas un
        plafond spécifique à vos consultations Noûs, mais un plafond partagé
        avec l'ensemble de vos dépenses de services à la personne dans l'année.
      </p>

      <h2>En résumé</h2>
      <ul>
        <li>
          Toutes les consultations réservées via Noûs sont éligibles, peu
          importe le praticien choisi.
        </li>
        <li>
          Le crédit d'impôt (article 199 sexdecies du CGI) se déclare l'année
          suivante, et vous est versé par virement ou chèque, généralement
          entre fin juillet et début août.
        </li>
        <li>Vous récupérez 50&nbsp;% du montant dépensé.</li>
        <li>
          Le plafond global (12&nbsp;000&nbsp;€/an) est partagé avec les autres
          services à la personne éventuels.
        </li>
      </ul>
      <p>
        Cet article présente le fonctionnement général du dispositif tel
        qu'applicable à Noûs. Pour toute question sur votre situation fiscale
        personnelle, nous vous invitons à consulter le site officiel{" "}
        <a
          href="https://www.impots.gouv.fr"
          target="_blank"
          rel="noopener noreferrer"
        >
          impots.gouv.fr
        </a>{" "}
        ou votre comptable.
      </p>

      <p className="cta">
        <Link
          to="/#praticiens"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Découvrir nos praticiens certifiés
        </Link>
      </p>

      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être Agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
  "perte-concentration-clarte-mentale": (
    <>
      <p className="lead">
        Vous relisez trois fois la même phrase sans qu'elle ne rentre. Vous
        entrez dans une pièce et oubliez pourquoi. Vous jonglez entre dix
        onglets ouverts sans jamais vraiment vous poser sur un seul. Si cette
        sensation vous est familière, vous n'êtes pas seul&nbsp;: de plus en
        plus de personnes recherchent sur internet pourquoi elles n'arrivent
        plus à se concentrer, ou pourquoi leur mémoire semble leur jouer des
        tours au quotidien.
      </p>
      <p>
        Bonne nouvelle&nbsp;: dans la grande majorité des cas, ce n'est ni un
        trouble grave, ni une fatalité. C'est souvent le signe d'un cerveau
        surchargé, pas d'un cerveau défaillant.
      </p>

      <h2>Le vrai coupable : la surcharge, pas le stress</h2>
      <p>
        Contrairement à l'anxiété, qui s'accompagne souvent d'une sensation
        d'urgence ou d'inquiétude, cette fatigue mentale-là est plus sournoise.
        Elle vient du multitâche permanent&nbsp;: notifications qui
        s'accumulent, allers-retours incessants entre les écrans, décisions à
        prendre en continu. Le cerveau n'est tout simplement pas conçu pour
        maintenir son attention sur autant de fronts à la fois.
        Résultat&nbsp;: il «&nbsp;sature&nbsp;», et cette saturation se traduit
        par des oublis, une concentration en pointillé, une sensation de
        brouillard.
      </p>

      <h2>5 habitudes simples pour retrouver de la clarté</h2>
      <p>
        <strong>1. Faire une seule chose à la fois</strong>
        <br />
        Le cerveau ne fait pas vraiment du multitâche, il bascule très vite
        d'une tâche à l'autre, ce qui coûte de l'énergie à chaque bascule. Se
        concentrer sur une seule tâche, même 20&nbsp;minutes, repose déjà
        énormément l'esprit.
      </p>
      <p>
        <strong>
          2. Une pause de cohérence cardiaque avant une tâche importante
        </strong>
        <br />
        Quelques minutes de respiration guidée avant un moment qui demande de
        la concentration (une réunion, un rendez-vous important) aident à
        recentrer l'attention et à calmer le système nerveux, qui joue un rôle
        direct dans notre capacité de concentration.
      </p>
      <p>
        <strong>3. Des micro-pauses entre deux tâches mentales</strong>
        <br />
        Une courte méditation guidée de 5&nbsp;minutes entre deux réunions
        permet au cerveau de «&nbsp;vider le cache&nbsp;» avant de repartir sur
        autre chose, un peu comme fermer des onglets inutiles avant d'en ouvrir
        un nouveau.
      </p>
      <p>
        <strong>
          4. Limiter les notifications pendant les temps de concentration
        </strong>
        <br />
        Chaque notification, même ignorée, sollicite l'attention pendant
        plusieurs secondes. Couper les notifications pendant un créneau de
        travail concentré change réellement la donne.
      </p>
      <p>
        <strong>5. Un vrai temps de sommeil réparateur</strong>
        <br />
        La mémoire se consolide pendant le sommeil. Un cerveau qui ne récupère
        pas correctement la nuit aura beaucoup plus de mal à rester concentré
        et à retenir les informations le lendemain.
      </p>

      <h2>Des outils simples pour vous accompagner au quotidien</h2>
      <p>
        Sur Noûs, vous trouverez des exercices courts de cohérence cardiaque et
        des méditations guidées, enregistrées avec une vraie voix (pas de
        synthèse), pensés pour s'intégrer facilement entre deux tâches, sans
        avoir besoin d'y consacrer des heures.
      </p>
      <p>
        Si malgré ces habitudes la sensation de fatigue mentale ou de perte de
        concentration persiste ou s'aggrave, il est toujours recommandé d'en
        parler à un professionnel. Vous pouvez retrouver dans notre service des
        praticiens certifiés (sophrologues, naturopathes, thérapeutes) pour un
        accompagnement personnalisé, les consultations étant éligibles à un
        crédit d'impôt de 50&nbsp;%.
      </p>

      <p className="cta">
        <Link
          to="/exercices"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Découvrir les exercices Noûs
        </Link>
      </p>

      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être Agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
  "sons-binauraux-cerveau-routine-bien-etre": (
    <>
      <p className="lead">
        Vous avez peut-être déjà croisé le terme «&nbsp;sons binauraux&nbsp;»
        dans une application de méditation ou une playlist «&nbsp;focus&nbsp;»
        sur une plateforme de streaming. Derrière cette technologie sonore se
        cache un principe scientifique simple, utilisé depuis plusieurs
        décennies pour favoriser la relaxation, le sommeil ou la concentration.
        Voici comment ça fonctionne, et ce que la recherche en dit vraiment.
      </p>

      <h2>Qu'est-ce qu'un son binaural&nbsp;?</h2>
      <p>
        Un son binaural repose sur un phénomène auditif découvert dès 1839 par
        le physicien Heinrich Wilhelm Dove. Le principe&nbsp;: on envoie deux
        fréquences sonores légèrement différentes, une dans chaque oreille (par
        exemple 200&nbsp;Hz à gauche et 208&nbsp;Hz à droite). Le cerveau, dans
        le tronc cérébral, ne perçoit pas ces deux sons séparément — il génère
        une troisième fréquence, correspondant à la différence entre les deux
        (ici, 8&nbsp;Hz), appelée «&nbsp;battement binaural&nbsp;».
      </p>
      <p>
        Ce battement n'existe nulle part dans l'air&nbsp;: il est une pure
        construction neurologique, ce qui explique pourquoi le port d'un casque
        est indispensable. Sans casque, les deux fréquences se mélangent avant
        d'atteindre les oreilles, et l'effet binaural disparaît complètement.
      </p>

      <h2>Les différentes fréquences et leurs effets recherchés</h2>
      <p>
        La fréquence du battement obtenu détermine l'état mental que la
        technique cherche à favoriser. Ce classement s'appuie sur les
        catégories d'ondes cérébrales identifiées en électroencéphalographie&nbsp;:
      </p>
      <ul>
        <li>
          <strong>Ondes Delta (0,5 à 4&nbsp;Hz)</strong>, associées au sommeil
          profond et à la récupération physique.
        </li>
        <li>
          <strong>Ondes Thêta (4 à 8&nbsp;Hz)</strong>, associées à la
          relaxation profonde, la méditation et les états de somnolence légère.
        </li>
        <li>
          <strong>Ondes Alpha (8 à 12&nbsp;Hz)</strong>, associées à un état de
          concentration calme, d'éveil détendu.
        </li>
        <li>
          <strong>Ondes Bêta (12 à 30&nbsp;Hz)</strong>, associées à la
          vigilance et à l'activité mentale normale.
        </li>
        <li>
          <strong>Ondes Gamma (30&nbsp;Hz et plus)</strong>, associées à des
          états de très haute concentration.
        </li>
      </ul>
      <p>
        Certaines fréquences porteuses spécifiques, comme le 963&nbsp;Hz, sont
        également utilisées en sonothérapie pour leurs effets apaisants
        rapportés sur le mental et le stress, en complément du principe
        binaural.
      </p>

      <h2>Que dit la recherche scientifique&nbsp;?</h2>
      <p>
        Il est important d'être honnête sur l'état des connaissances&nbsp;: les
        études sur les sons binauraux existent, mais restent d'ampleur limitée
        et parfois contradictoires. Plusieurs recherches suggèrent des effets
        positifs sur l'anxiété avant une intervention médicale, sur la qualité
        du sommeil ou sur certains aspects de l'attention. D'autres études ne
        retrouvent pas d'effet significatif au-delà de celui d'un simple bruit
        de fond relaxant.
      </p>
      <p>
        En pratique, cela signifie que les sons binauraux ne doivent pas être
        présentés comme un traitement médical, mais plutôt comme un outil
        complémentaire de détente, au même titre qu'une musique douce ou un
        exercice de respiration, dont l'efficacité perçue varie beaucoup d'une
        personne à l'autre.
      </p>

      <h2>Comment bien les utiliser</h2>
      <p>Quelques recommandations simples pour en tirer le meilleur parti&nbsp;:</p>
      <ul>
        <li>
          Toujours utiliser un casque ou des écouteurs&nbsp;: sans cela, l'effet
          binaural n'existe pas.
        </li>
        <li>
          S'installer dans un environnement calme, assis ou allongé, pour
          laisser l'attention se poser.
        </li>
        <li>
          Compter sur une session de 15 à 30&nbsp;minutes pour laisser le temps
          au cerveau de s'ajuster à la fréquence proposée.
        </li>
        <li>
          Choisir la fréquence selon le moment de la journée&nbsp;: Delta le
          soir pour le sommeil, Alpha en journée pour un moment de concentration
          détendue, Thêta pour une pause méditative.
        </li>
      </ul>
      <p>
        Une précaution à connaître&nbsp;: les personnes épileptiques ou
        porteuses d'un stimulateur cardiaque sont invitées à demander l'avis
        d'un professionnel de santé avant d'utiliser des sons binauraux, par
        mesure de prudence.
      </p>

      <h2>Intégrer les sons binauraux à un moment de pause</h2>
      <p>
        Sur Noûs, les sons binauraux prennent place aux côtés des exercices de
        cohérence cardiaque et des méditations guidées, dans une logique
        simple&nbsp;: proposer plusieurs façons d'accéder à un moment de calme,
        sans pression de performance. Chaque fréquence répond à un besoin
        différent&nbsp;: s'endormir, relâcher la tension nerveuse, ou simplement
        retrouver un peu de clarté mentale au milieu d'une journée chargée.
      </p>
      <p>
        Comme pour tout outil de bien-être, l'essentiel reste l'écoute de
        soi&nbsp;: tester, observer ce qui fonctionne, et ajuster la fréquence
        ou la durée selon ce que vous ressentez.
      </p>

      <p className="cta">
        <Link
          to="/exercices"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Découvrir les sons binauraux sur Noûs
        </Link>
      </p>

      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être Agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
  "stress-anxiete-difference": (
    <>
      <p className="lead">
        Nous utilisons souvent les mots «&nbsp;stress&nbsp;» et
        «&nbsp;anxiété&nbsp;» de manière interchangeable. Pourtant, ces deux
        états sont bien distincts et les comprendre, c'est déjà la première
        étape pour mieux les gérer.
      </p>

      <h2>Stress et anxiété : quelle différence&nbsp;?</h2>
      <p>
        Le <strong>stress</strong> est une réaction naturelle et temporaire à
        une situation identifiable&nbsp;: un délai serré au travail, un conflit,
        un examen. Une fois la situation passée, le stress disparaît. C'est un
        mécanisme de survie utile, il nous pousse à agir.
      </p>
      <p>
        L'<strong>anxiété</strong>, elle, persiste au-delà de la situation
        déclenchante. Elle s'installe, anticipe, imagine le pire même quand tout
        va bien en apparence. L'anxiété chronique épuise le système nerveux et
        peut finir par affecter la santé physique&nbsp;: tensions musculaires,
        troubles digestifs, fatigue persistante, palpitations.
      </p>
      <p>
        Dans les deux cas, le corps réagit de la même façon&nbsp;: il libère du
        cortisol et de l'adrénaline, met les muscles en tension et accélère le
        rythme cardiaque. La différence, c'est la durée et l'intensité.
      </p>

      <h2>Les signaux à ne pas ignorer</h2>
      <p>
        Le stress devient problématique quand il s'installe dans la durée.
        Quelques signaux d'alerte&nbsp;:
      </p>
      <ul>
        <li>Difficulté à déconnecter, même le week-end</li>
        <li>Irritabilité inhabituelle ou sautes d'humeur</li>
        <li>Troubles du sommeil récurrents</li>
        <li>Sensation d'être «&nbsp;à bout&nbsp;» sans raison apparente</li>
        <li>Douleurs physiques inexpliquées (nuque, dos, maux de tête)</li>
      </ul>
      <p>
        Si vous vous reconnaissez dans plusieurs de ces signes, il est temps de
        prendre soin de vous&nbsp;: pas demain, maintenant.
      </p>

      <h2>Ce que la science recommande</h2>
      <p>
        Les recherches en neurosciences et en psychologie convergent vers les
        mêmes conclusions&nbsp;: les techniques corps-esprit sont parmi les plus
        efficaces pour réguler le stress et l'anxiété.
      </p>
      <ul>
        <li>
          <strong>La respiration consciente</strong> agit directement sur le
          système nerveux autonome en quelques minutes.
        </li>
        <li>
          <strong>La méditation de pleine conscience</strong> réduit
          significativement les niveaux de cortisol après 8 semaines de pratique
          régulière.
        </li>
        <li>
          <strong>Les activités créatives douces</strong> — coloriage,
          jardinage, musique — activent un état de flow qui coupe le circuit de
          l'anxiété.
        </li>
        <li>
          <strong>L'accompagnement par un professionnel</strong> reste la
          solution la plus adaptée pour les formes chroniques.
        </li>
      </ul>

      <h2>Agir dès aujourd'hui</h2>
      <p>
        Pas besoin d'attendre que ça aille mieux tout seul. De petits gestes
        quotidiens, pratiqués régulièrement, font une vraie différence.
      </p>
      <p>
        Chez Noûs, nous avons pensé chaque fonctionnalité pour vous accompagner
        dans ces moments&nbsp;: une séance de cohérence cardiaque pour calmer
        une montée de stress en 5 minutes, des méditations guidées pour relâcher
        les tensions, ou encore nos exercices de détente pour déposer le mental
        et revenir au moment présent.
      </p>
      <p>
        Prendre soin de son équilibre émotionnel, c'est un acte de bienveillance
        envers soi-même. Commencez par une minute.
      </p>

      <p className="cta">
        <Link
          to="/exercices"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Essayer la cohérence cardiaque sur Noûs
        </Link>
      </p>

      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être Agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
  "sommeil-bien-etre": (
    <>
      <p className="lead">
        On le sait tous intuitivement&nbsp;: une mauvaise nuit et tout devient
        plus difficile. L'humeur, la concentration, la patience... Le sommeil
        n'est pas un luxe. C'est le pilier silencieux de notre équilibre.
      </p>

      <h2>Ce qui se passe vraiment pendant que vous dormez</h2>
      <p>
        Le sommeil est loin d'être un simple temps de pause. C'est une période
        d'activité intense pour l'organisme&nbsp;:
      </p>
      <ul>
        <li>
          <strong>Le cerveau consolide</strong> les apprentissages et trie les
          informations de la journée.
        </li>
        <li>
          <strong>Le système immunitaire se renforce</strong>&nbsp;: les
          personnes dormant moins de 6 heures par nuit sont significativement
          plus vulnérables aux infections.
        </li>
        <li>
          <strong>Les hormones se régulent</strong>, dont le cortisol (stress),
          la leptine (satiété) et la mélatonine (cycle veille/sommeil).
        </li>
        <li>
          <strong>Les cellules se réparent</strong>&nbsp;: la récupération
          physique et musculaire se fait principalement la nuit.
        </li>
      </ul>
      <p>En résumé&nbsp;: dormir, c'est se soigner.</p>

      <h2>Pourquoi nous dormons si mal&nbsp;?</h2>
      <p>
        Les troubles du sommeil touchent près d'un Français sur trois. Les
        causes sont multiples, mais le stress est le premier coupable. Quand le
        système nerveux reste en état d'alerte le soir, l'endormissement
        devient difficile et le sommeil reste superficiel.
      </p>
      <p>
        Les écrans, les horaires irréguliers, la sédentarité et une
        alimentation déséquilibrée viennent aggraver le tableau. Le
        résultat&nbsp;: une dette de sommeil qui s'accumule et finit par
        affecter tous les aspects de la vie.
      </p>

      <h2>Les clés d'un sommeil réparateur</h2>
      <p>
        Quelques habitudes simples peuvent transformer la qualité de vos
        nuits&nbsp;:
      </p>
      <ul>
        <li>
          <strong>Respecter des horaires réguliers</strong>&nbsp;: se coucher
          et se lever à la même heure, même le week-end.
        </li>
        <li>
          <strong>Créer un rituel du soir</strong> pour signaler au cerveau que
          la journée se termine (lecture, bain chaud, étirements doux).
        </li>
        <li>
          <strong>Limiter les écrans après 21h</strong>&nbsp;: la lumière bleue
          bloque la production de mélatonine.
        </li>
        <li>
          <strong>Pratiquer la relaxation</strong>&nbsp;: cohérence cardiaque,
          méditation guidée ou exercices de respiration pour apaiser le système
          nerveux avant de dormir.
        </li>
      </ul>

      <h2>Et si vous commenciez ce soir&nbsp;?</h2>
      <p>
        Chez Noûs, nous avons conçu des outils pensés pour accompagner ce
        moment précieux de transition entre le jour et la nuit.
      </p>
      <p>
        Nos méditations guidées vous accompagnent vers un état de détente
        profonde, idéal pour préparer un endormissement serein. Nos exercices
        de détente — cohérence cardiaque, jardin zen, mandala — sont parfaits
        pour déposer les tensions de la journée en quelques minutes.
      </p>
      <p>
        Pas besoin d'une heure. Cinq minutes suffisent pour changer la qualité
        de votre nuit.
      </p>

      <p className="cta">
        <Link
          to="/exercices"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Explorer les exercices de détente
        </Link>
      </p>

      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être Agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
  "sophrologie-methode-douce": (
    <>
      <p className="lead">
        Stress chronique, troubles du sommeil, manque de confiance en soi...
        Face aux tensions du quotidien, de plus en plus de personnes se tournent
        vers la sophrologie. Et pour cause&nbsp;: cette discipline alliant corps
        et esprit offre des résultats concrets, validés par des décennies de
        pratique.
      </p>

      <h2>Qu'est-ce que la sophrologie&nbsp;?</h2>
      <p>
        Créée dans les années 1960 par le neuropsychiatre Alfonso Caycedo, la
        sophrologie est une méthode psychocorporelle qui combine des techniques
        de relaxation, de respiration, de visualisation positive et de
        mouvements doux.
      </p>
      <p>
        Son objectif&nbsp;: atteindre un état de conscience apaisé, ni endormi,
        ni en plein éveil, dans lequel le corps se détend et l'esprit retrouve
        clarté et sérénité. Cet état, appelé «&nbsp;niveau sophro-liminal&nbsp;»,
        est particulièrement propice au travail sur soi.
      </p>

      <h2>À quoi ça sert concrètement&nbsp;?</h2>
      <p>La sophrologie est utilisée dans de nombreux contextes&nbsp;:</p>
      <ul>
        <li>
          <strong>Gestion du stress et de l'anxiété</strong>&nbsp;: apprendre à
          désamorcer les tensions avant qu'elles ne s'installent.
        </li>
        <li>
          <strong>Amélioration du sommeil</strong>&nbsp;: retrouver un
          endormissement naturel grâce à des exercices de relaxation profonde.
        </li>
        <li>
          <strong>Préparation mentale</strong>&nbsp;: examens, accouchement,
          compétition sportive, entretien professionnel.
        </li>
        <li>
          <strong>Confiance en soi</strong>&nbsp;: travailler sur les croyances
          limitantes par la visualisation positive.
        </li>
        <li>
          <strong>Accompagnement de la maladie</strong>&nbsp;: réduire l'impact
          émotionnel des traitements médicaux.
        </li>
      </ul>

      <h2>Comment se déroule une séance&nbsp;?</h2>
      <p>
        Une séance de sophrologie dure généralement entre 45 minutes et 1 heure.
        Le sophrologue guide verbalement le patient à travers des exercices de
        respiration, des relaxations dynamiques (mouvements lents et conscients)
        et des visualisations.
      </p>
      <p>
        Pas besoin de croire en quoi que ce soit ni d'avoir une quelconque
        souplesse physique. La sophrologie s'adapte à chaque personne, à tout
        âge et dans tout état de santé.
      </p>
      <p>
        Les effets se font souvent sentir dès la première séance&nbsp;: une
        sensation de légèreté, de tête plus claire, et s'approfondissent au fil
        des séances.
      </p>

      <h2>Une pratique reconnue et accessible</h2>
      <p>
        En France, la sophrologie est de plus en plus intégrée dans les milieux
        hospitaliers, scolaires et sportifs. Elle peut également être prise en
        charge dans le cadre des Services à la Personne, ce qui la rend
        accessible à un plus grand nombre.
      </p>
      <p>
        Découvrez nos praticiens et réservez une première séance en quelques
        clics.
      </p>

      <p className="cta">
        <Link
          to="/#praticiens"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Trouver un praticien sur Noûs
        </Link>
      </p>

      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être Agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
  "coherence-cardiaque": (
    <>
      <p className="lead">
        Vous avez déjà remarqué comme une simple respiration profonde peut suffire
        à calmer une montée de stress&nbsp;? Ce n'est pas le fruit du hasard.
        C'est la cohérence cardiaque — et la science l'explique très bien.
      </p>

      <h2>Qu'est-ce que la cohérence cardiaque&nbsp;?</h2>
      <p>
        Le cœur et le cerveau communiquent en permanence via le système nerveux
        autonome. Quand nous sommes stressés, ce dialogue se dérègle&nbsp;: le
        rythme cardiaque devient irrégulier, le cortisol (l'hormone du stress)
        augmente, et notre capacité à penser clairement diminue.
      </p>
      <p>
        La cohérence cardiaque, c'est l'art de rétablir ce dialogue. En régulant
        consciemment notre respiration, on synchronise le rythme cardiaque avec
        le souffle — créant un état de cohérence physiologique qui apaise le
        système nerveux en quelques minutes seulement.
      </p>

      <h2>Comment ça fonctionne concrètement&nbsp;?</h2>
      <p>La méthode la plus utilisée est le <strong>3/6/5</strong>&nbsp;:</p>
      <ul>
        <li>3 fois par jour</li>
        <li>6 respirations par minute (5 secondes inspiration, 5 secondes expiration)</li>
        <li>5 minutes par session</li>
      </ul>
      <p>
        En pratiquant régulièrement, les effets s'accumulent&nbsp;: réduction du
        cortisol, amélioration de la concentration, meilleure qualité de
        sommeil, et une sensation durable de calme intérieur.
      </p>
      <p>
        Des études en neurosciences ont démontré qu'après seulement 3 semaines
        de pratique quotidienne, les bénéfices se maintiennent même en dehors
        des séances.
      </p>

      <h2>Pourquoi l'intégrer dans votre quotidien&nbsp;?</h2>
      <p>
        La cohérence cardiaque ne demande ni équipement, ni lieu particulier.
        Elle peut se pratiquer le matin au réveil, avant une réunion stressante,
        ou le soir pour faciliter l'endormissement.
      </p>
      <p>
        C'est une des rares techniques de bien-être validées scientifiquement,
        accessible à tous, dès la première séance.
      </p>

      <h2>Essayez maintenant avec Noûs</h2>
      <p>
        Sur l'application Noûs, nous avons conçu un exercice de cohérence
        cardiaque guidé visuellement avec notre nuage animé qui respire à votre
        rythme, pour vous accompagner pas à pas vers cet état de calme retrouvé.
      </p>
      <p>
        Pas besoin de connaissances préalables. Juste votre souffle, et quelques
        minutes pour vous.
      </p>

      <p className="cta">
        <Link
          to="/exercices"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Essayer l'exercice de cohérence cardiaque sur Noûs
        </Link>
      </p>

      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
  "bien-etre-global-approches-complementaires": (
    <>
      <p className="lead">
        Le stress, les troubles du sommeil, la fatigue mentale ne se logent
        jamais dans une seule case. Le corps, la respiration, les pensées et le
        sommeil sont profondément liés, et agir sur un seul de ces leviers donne
        souvent des résultats limités. C'est ce qu'on appelle parfois une approche
        holistique : considérer la personne dans sa globalité plutôt que de
        traiter un symptôme isolé. Chez Noûs, on préfère parler simplement de
        bien-être global, et surtout de complémentarité entre les pratiques.
      </p>

      <h2>Pourquoi combiner plusieurs approches</h2>
      <p>
        Prenons un exemple concret : une personne confrontée à un stress chronique
        au travail. Travailler uniquement sur la respiration peut soulager sur le
        moment, mais si le sommeil reste perturbé et que les pensées anxieuses
        persistent la nuit, l'effet ne dure pas. À l'inverse, combiner un exercice
        de régulation du système nerveux (comme la cohérence cardiaque) avec un
        travail plus profond sur les mécanismes de la pensée (comme la sophrologie
        ou d'autres accompagnements) permet d'agir à la fois sur le symptôme
        immédiat et sur la cause plus durable.
      </p>
      <p>
        Ce n'est pas une question de faire « plus », mais de faire les choses dans
        le bon ordre et avec la bonne combinaison, adaptée à chaque situation.
      </p>

      <h2>Trois approches qui se complètent</h2>
      <p>
        <strong>La régulation du système nerveux.</strong> Des exercices courts et
        réguliers, comme la cohérence cardiaque, permettent de calmer rapidement
        les réactions de stress du corps. C'est souvent le point de départ : apaiser
        le système nerveux avant de pouvoir travailler plus en profondeur sur autre
        chose.
      </p>
      <p>
        <strong>Le travail sur les pensées et les représentations.</strong> Une
        fois le corps apaisé, des techniques comme la sophrologie ou d'autres
        accompagnements thérapeutiques aident à modifier durablement la façon dont
        on perçoit une situation stressante, à mieux dormir, et à préparer
        mentalement des moments difficiles (une prise de parole, un examen, une
        période de changement).
      </p>
      <p>
        <strong>L'accompagnement du sommeil.</strong> Le sommeil est à la fois une
        conséquence du stress et un amplificateur s'il est perturbé. Des rituels
        adaptés et une bonne hygiène de sommeil viennent consolider les effets des
        deux approches précédentes.
      </p>
      <p>
        Ces trois dimensions ne s'excluent pas, elles se renforcent. C'est en les
        combinant, dans un ordre pensé pour chaque personne, qu'on obtient des
        résultats qui tiennent dans la durée.
      </p>

      <h2>Comment construire son propre parcours</h2>
      <p>
        Il n'existe pas de combinaison universelle : ce qui fonctionne pour une
        personne stressée par son travail ne sera pas forcément adapté à quelqu'un
        qui traverse une période de deuil ou de grand changement de vie. Chaque
        situation mérite d'être comprise avant d'être orientée vers la ou les
        approches les plus pertinentes.
      </p>
      <p>
        C'est pour cela que chez Noûs, nous préférons prendre le temps d'échanger
        avec vous plutôt que de vous laisser choisir seul dans une liste.
        Contactez-nous pour nous parler de votre situation : nous vous aiderons à
        identifier l'approche, ou la combinaison d'approches, la plus adaptée à
        votre besoin.
      </p>

      <h2>En résumé</h2>
      <p>
        Le bien-être ne se résume pas à une seule pratique isolée. C'est la
        complémentarité entre régulation du corps, travail sur les pensées et
        qualité du sommeil qui fait la différence sur la durée. Chez Noûs, nous
        vous accompagnons pour construire le parcours qui vous correspond, pas un
        parcours standard, mais le vôtre.
      </p>

      <p className="cta">
        <Link
          to="/?open=plan-perso"
          className="inline-block px-6 py-3 rounded-lg bg-sage-300 hover:bg-sage-400 text-sage-900 font-medium transition-colors no-underline"
        >
          👉 Construire mon plan bien-être personnalisé
        </Link>
      </p>

      <p className="signature">
        <em>
          Article rédigé par l'équipe Noûs — service de bien-être Agréé Services
          à la Personne.
        </em>
      </p>
    </>
  ),
};

const BlogArticle = () => {
  const { slug } = useParams<{ slug: string }>();
  const article = articles.find((a) => a.slug === slug);
  const content = slug ? articleContents[slug] : null;

  useEffect(() => {
    if (slug && articleContents[slug]) trackEventOnce("lecture_article_blog");
  }, [slug]);

  if (!article || !content) {
    return <Navigate to="/blog" replace />;
  }

  return (
    <div className="min-h-screen bg-[#F5F0E6] py-12 px-4">
      <Helmet>
        <title>{article.metaTitle ?? `${article.title} | Blog Noûs`}</title>
        <meta name="description" content={article.metaDescription ?? article.excerpt} />
        {article.keywords && <meta name="keywords" content={article.keywords} />}
        <link rel="canonical" href={`https://app-nous.fr/blog/${article.slug}`} />
        <meta property="og:title" content={article.metaTitle ?? article.title} />
        <meta property="og:description" content={article.metaDescription ?? article.excerpt} />
        <meta property="og:url" content={`https://app-nous.fr/blog/${article.slug}`} />
        <meta property="og:type" content="article" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Article",
            headline: article.title,
            description: article.excerpt,
            datePublished: article.isoDate ?? article.date,
            author: { "@type": "Organization", name: article.author },
            publisher: {
              "@type": "Organization",
              name: "Noûs",
              logo: { "@type": "ImageObject", url: "https://app-nous.fr/icon-512.png" },
            },
            mainEntityOfPage: `https://app-nous.fr/blog/${article.slug}`,
          })}
        </script>
      </Helmet>
      <article className="container max-w-3xl mx-auto">
        <Link
          to="/blog"
          className="inline-flex items-center gap-2 text-sage-700 hover:text-sage-900 text-sm mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Retour au blog
        </Link>

        <header className="mb-10">
          <p className="text-sm text-sage-700 mb-3">
            {article.date} · {article.author}{article.readingTime && ` · ${article.readingTime} de lecture`}
          </p>
          <h1 className="text-3xl md:text-4xl font-alice text-[#8B4513] leading-tight">
            {article.title}
          </h1>
        </header>

        <div className="blog-content text-warm-800 leading-relaxed space-y-5">
          {content}
        </div>
        {slug && RELATED_EXERCISE[slug] && (
          <p className="mt-8 text-center">
            <Link
              to={RELATED_EXERCISE[slug].to}
              className="text-sage-700 underline underline-offset-4 hover:text-sage-900 font-medium"
            >
              Découvrir la page exercice : {RELATED_EXERCISE[slug].label}
            </Link>
          </p>
        )}
      </article>
    </div>
  );
};

export default BlogArticle;
