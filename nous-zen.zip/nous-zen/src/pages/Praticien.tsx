import { useEffect, useState, type FormEvent } from "react";
import { useParams, Navigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";
import {
  PhoneCall,
  PhoneCallIcon,
  Video,
  Euro,
  CreditCard,
  Percent,
  Building2,
  ArrowLeft,
} from "lucide-react";
import { StripeEmbeddedCheckout } from "@/components/stripe-embedded-checkout";
import { ImageWithFallback } from "@/components/image-with-fallback";
import { supabase } from "@/integrations/supabase/client";
import { trackEventOnce } from "@/lib/track-event";
import { practitioners } from "@/data/practitioners";

const MOMENTS = [
  { id: "morning", label: "Matin" },
  { id: "afternoon", label: "Après-midi" },
  { id: "evening", label: "Soir" },
] as const;

const DAYS = [
  { id: "mon", label: "Lundi" },
  { id: "tue", label: "Mardi" },
  { id: "wed", label: "Mercredi" },
  { id: "thu", label: "Jeudi" },
  { id: "fri", label: "Vendredi" },
  { id: "sat", label: "Samedi" },
  { id: "sun", label: "Dimanche" },
] as const;

const Praticien = () => {
  const { slug } = useParams<{ slug: string }>();
  const practitioner = practitioners.find((p) => p.slug === slug);

  const [callbackOpen, setCallbackOpen] = useState(false);
  const [checkoutPriceId, setCheckoutPriceId] = useState<string | null>(null);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [moments, setMoments] = useState<string[]>([]);
  const [days, setDays] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
  }, [slug]);

  if (!practitioner) {
    return <Navigate to="/#praticiens" replace />;
  }

  const { name, specialties, tags, availableFor, bio, bioTitle, pricing } = practitioner;
  const googleAvisUrl =
    "googleAvisUrl" in practitioner ? practitioner.googleAvisUrl : undefined;
  const googleNote =
    "googleNote" in practitioner ? practitioner.googleNote : undefined;
  const googleNombreAvis =
    "googleNombreAvis" in practitioner ? practitioner.googleNombreAvis : undefined;

  const metaDescription = `${name} — ${specialties.join(", ")}. Consultations en visio, par téléphone ou en cabinet, éligibles au crédit d'impôt de 50%.`;

  const openGoogleReviews = () => {
    if (!googleAvisUrl) return;
    trackEventOnce("clic_avis_google");
    const capBrowser = (window as any)?.Capacitor?.Plugins?.Browser;
    if (capBrowser?.open) {
      capBrowser.open({ url: googleAvisUrl });
      return;
    }
    window.open(googleAvisUrl, "_blank", "noopener,noreferrer");
  };

  const toggle = (
    value: string,
    list: string[],
    setList: (v: string[]) => void,
  ) => {
    setList(list.includes(value) ? list.filter((v) => v !== value) : [...list, value]);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const { error } = await supabase.functions.invoke("request-callback", {
        body: {
          praticienName: name,
          firstName,
          lastName,
          phone,
          email,
          moments,
          days,
        },
      });
      if (error) throw error;
      toast({
        title: "Demande envoyée",
        description: `Merci ${firstName}, nous vous recontacterons rapidement.`,
      });
      setCallbackOpen(false);
      setFirstName("");
      setLastName("");
      setPhone("");
      setEmail("");
      setMoments([]);
      setDays([]);
    } catch (err) {
      console.error(err);
      toast({
        title: "Erreur",
        description: "Impossible d'envoyer la demande. Réessayez plus tard.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F0E6]">
      <Helmet>
        <title>{`${name} — ${specialties[0]} | Noûs`}</title>
        <meta name="description" content={metaDescription} />
        <link rel="canonical" href={`https://app-nous.fr/praticiens/${practitioner.slug}`} />
        <meta property="og:title" content={`${name} — ${specialties[0]} | Noûs`} />
        <meta property="og:description" content={metaDescription} />
        <meta property="og:type" content="profile" />
        <meta property="og:url" content={`https://app-nous.fr/praticiens/${practitioner.slug}`} />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Person",
            name,
            jobTitle: specialties.join(", "),
            description: metaDescription,
            url: `https://app-nous.fr/praticiens/${practitioner.slug}`,
          })}
        </script>
      </Helmet>

      <div className="container px-4 mx-auto sm:px-6 lg:px-8 py-8 max-w-3xl">
        <a
          href="/praticiens"
          className="inline-flex items-center gap-2 text-sage-700 hover:text-sage-800 mb-6 font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          Retour aux praticiens
        </a>

        <div
          className="relative w-full aspect-[4/3] overflow-hidden rounded-lg"
          style={{ boxShadow: "0 8px 24px rgba(60, 40, 25, 0.18)" }}
        >
          <ImageWithFallback
            alt={name}
            className="absolute inset-0 object-cover w-full h-full object-top"
            src={practitioner.image}
            loading="eager"
          />
          <div className="absolute top-2 left-2 bg-[#5C4033]/80 text-[#F5F0E6] text-xs font-medium px-2.5 py-1 rounded-full flex items-center gap-1.5 backdrop-blur-sm shadow-sm">
            <Percent className="w-3.5 h-3.5" />
            Crédit d'impôt 50%
          </div>
          {googleAvisUrl && typeof googleNombreAvis === "number" && (
            <button
              type="button"
              onClick={openGoogleReviews}
              className="absolute bottom-2 left-2 flex items-center gap-1.5 rounded-full bg-[#3D2C21]/75 px-2.5 py-1 text-xs font-semibold text-[#F5F0E6] shadow-sm hover:underline"
              aria-label={
                typeof googleNote === "number"
                  ? `Voir les ${googleNombreAvis} avis Google, note ${googleNote.toFixed(1).replace(".", ",")}`
                  : `Voir les ${googleNombreAvis} avis Google`
              }
            >
              {typeof googleNote === "number" ? (
                <>
                  <span className="text-[#F59E0B]">★</span>
                  <span>{googleNote.toFixed(1).replace(".", ",")}</span>
                  <span>· {googleNombreAvis} avis Google</span>
                </>
              ) : (
                <span>{googleNombreAvis} avis Google</span>
              )}
            </button>
          )}
        </div>

        <h1 className="mt-6 text-3xl font-bold text-[#8B4513]">{name}</h1>

        <div className="flex flex-wrap gap-2 mt-4">
          {specialties.map((specialty) => (
            <Badge
              key={specialty}
              variant="outline"
              className="bg-sage-200 text-sage-700 border-sage-300 hover:bg-sage-300"
            >
              {specialty}
            </Badge>
          ))}
        </div>

        {tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {tags.map((tag) => (
              <Badge
                key={tag}
                variant="outline"
                className="bg-sage-200 text-sage-700 border-sage-300 hover:bg-sage-300"
              >
                {tag}
              </Badge>
            ))}
          </div>
        )}

        <div className="flex flex-wrap gap-2 mt-4">
          {availableFor.includes("video") && (
            <Badge variant="outline" className="bg-sage-50 text-sage-700 border-sage-200">
              <Video className="w-3 h-3 mr-1" />
              Visio
            </Badge>
          )}
          {availableFor.includes("phone") && (
            <Badge variant="outline" className="bg-sage-50 text-sage-700 border-sage-200">
              <PhoneCall className="w-3 h-3 mr-1" />
              Téléphone
            </Badge>
          )}
          <Badge variant="outline" className="bg-sage-50 text-sage-700 border-sage-200">
            <Building2 className="w-3 h-3 mr-1" />
            Cabinet
          </Badge>
        </div>

        <Button
          type="button"
          onClick={() => setCallbackOpen(true)}
          className="w-full mt-6 bg-sage-600 hover:bg-sage-700 text-white"
        >
          <PhoneCallIcon className="w-4 h-4 mr-2" />
          Être rappelé
        </Button>

        {bio && (
          <section className="mt-10">
            <h2 className="text-2xl font-bold text-[#8B4513] mb-4">{bioTitle ?? name}</h2>
            <div className="text-sm text-[#5C4033] space-y-3 leading-relaxed">{bio}</div>
          </section>
        )}

        {pricing && pricing.length > 0 && (
          <section className="mt-10">
            <h2 className="text-2xl font-bold text-[#8B4513] mb-1">Réserver une séance</h2>
            <p className="text-sm text-[#A0522D] mb-4">
              Séances d'accompagnements en visio, par téléphone ou en présentiel.
            </p>
            <div className="space-y-3">
              {pricing.map((item) => (
                <button
                  key={item.title}
                  type="button"
                  onClick={() => {
                    if (item.priceId) {
                      setCheckoutPriceId(item.priceId);
                    } else {
                      toast({
                        title: "Paiement bientôt disponible",
                        description: "Le paiement Stripe sera activé prochainement.",
                      });
                    }
                  }}
                  className="w-full flex items-center justify-between rounded-lg border border-sage-200 bg-sage-50/50 p-4 text-left hover:bg-sage-50 transition-colors"
                >
                  <div className="min-w-0 pr-3">
                    <p className="font-medium text-[#5C4033]">{item.title}</p>
                    <p className="text-xs text-[#A0522D]">{item.subtitle}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-lg font-semibold text-sage-700 whitespace-nowrap">
                      {item.price}
                    </span>
                    <CreditCard className="w-4 h-4 text-sage-600 shrink-0" />
                  </div>
                </button>
              ))}
            </div>
            <p className="text-xs text-muted-foreground pt-3">
              Paiement sécurisé par Stripe. 50% de crédit d'impôt selon l'article 199 sexdecies du CGI. Vérifiez votre éligibilité.
            </p>
          </section>
        )}

        <div className="mt-10">
          <a
            href="/praticiens"
            className="inline-flex items-center gap-2 text-sage-700 hover:text-sage-800 font-medium"
          >
            <ArrowLeft className="w-4 h-4" />
            Retour aux praticiens
          </a>
        </div>
      </div>

      <Dialog open={callbackOpen} onOpenChange={setCallbackOpen}>
        <DialogContent className="mobile-scroll-dialog sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Être rappelé par {name}</DialogTitle>
            <DialogDescription>
              Indiquez vos coordonnées et vos préférences de créneaux.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor={`firstName-${name}`}>Prénom</Label>
                <Input
                  id={`firstName-${name}`}
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  maxLength={60}
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor={`lastName-${name}`}>Nom</Label>
                <Input
                  id={`lastName-${name}`}
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  maxLength={60}
                  required
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor={`phone-${name}`}>Numéro de téléphone</Label>
              <Input
                id={`phone-${name}`}
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                pattern="[0-9 +().-]{6,20}"
                maxLength={20}
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor={`email-${name}`}>Adresse email</Label>
              <Input
                id={`email-${name}`}
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                maxLength={255}
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Moments préférés</Label>
              <div className="flex flex-wrap gap-3">
                {MOMENTS.map((m) => (
                  <label key={m.id} className="flex items-center gap-2 text-sm">
                    <Checkbox
                      checked={moments.includes(m.id)}
                      onCheckedChange={() => toggle(m.id, moments, setMoments)}
                    />
                    {m.label}
                  </label>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <Label>Jours préférés</Label>
              <div className="flex flex-wrap gap-3">
                {DAYS.map((d) => (
                  <label key={d.id} className="flex items-center gap-2 text-sm">
                    <Checkbox
                      checked={days.includes(d.id)}
                      onCheckedChange={() => toggle(d.id, days, setDays)}
                    />
                    {d.label}
                  </label>
                ))}
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Nous vous recontacterons dans les meilleurs délais pour convenir
              d'un rendez-vous avec ce praticien.
            </p>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2">
              <Button
                type="submit"
                disabled={submitting}
                className="bg-sage-600 hover:bg-sage-700 text-white"
              >
                {submitting ? "Envoi…" : "Envoyer ma demande"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog
        open={!!checkoutPriceId}
        onOpenChange={(nextOpen) => {
          if (!nextOpen) setCheckoutPriceId(null);
        }}
      >
        <DialogContent className="mobile-scroll-dialog sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Paiement sécurisé</DialogTitle>
            <DialogDescription>
              Paiement traité par Stripe. Aucune donnée bancaire ne transite par notre site.
            </DialogDescription>
          </DialogHeader>
          {checkoutPriceId && <StripeEmbeddedCheckout priceId={checkoutPriceId} />}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Praticien;
