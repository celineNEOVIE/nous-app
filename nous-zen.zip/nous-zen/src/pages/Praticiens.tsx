import { Helmet } from "react-helmet-async";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { PractitionerCard } from "@/components/practitioner-card";
import { practitioners } from "@/data/practitioners";

const faqItems = [
  {
    question:
      "Comment bénéficier de 50 % de crédit d'impôt sur une séance de bien-être ?",
    answer:
      "Noûs est agréé Services à la Personne. Chaque séance réservée via Noûs vous donne droit à un crédit d'impôt de 50 %, avec une attestation fiscale annuelle.",
  },
  {
    question:
      "Les séances en visio sont-elles éligibles au crédit d'impôt ?",
    answer:
      "Oui, les séances en visio et par téléphone sont éligibles, comme les séances en cabinet.",
  },
  {
    question: "Les praticiens Noûs sont-ils certifiés ?",
    answer:
      "Oui. Chaque praticien dispose d'une certification reconnue dans sa discipline : RNCP, FENA, numéro RPPS selon la spécialité.",
  },
];

const Praticiens = () => {
  return (
    <div className="min-h-screen bg-[#F5F0E6]">
      <Helmet>
        <title>Praticiens bien-être certifiés, crédit d'impôt -50 % | Noûs</title>
        <meta name="description" content="Sophrologue, naturopathe, psychothérapeute, coach santé : consultez un praticien certifié en visio ou en cabinet, avec 50 % de crédit d'impôt." />
        <link rel="canonical" href="https://app-nous.fr/praticiens" />
        <meta property="og:title" content="Praticiens bien-être certifiés, crédit d'impôt -50 % | Noûs" />
        <meta property="og:description" content="Sophrologue, naturopathe, psychothérapeute, coach santé : consultez un praticien certifié en visio ou en cabinet, avec 50 % de crédit d'impôt." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://app-nous.fr/praticiens" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            mainEntity: faqItems.map((item) => ({
              "@type": "Question",
              name: item.question,
              acceptedAnswer: { "@type": "Answer", text: item.answer },
            })),
          })}
        </script>
      </Helmet>

      <div className="max-w-3xl mx-auto pt-12 pb-8 px-4 text-center">
        <h1 className="mb-4 text-3xl font-bold text-[#8B4513]">
          Praticiens bien-être certifiés avec 50 % de crédit d'impôt
        </h1>
        <p className="text-lg text-[#A0522D]">
          Sophrologues RNCP, naturopathe FENA, psychothérapeute n°RPPS, coach santé et thérapeutes psycho-corporels : nos praticiens certifiés vous accompagnent face au stress, au burn-out, à l'anxiété, aux troubles du sommeil ou aux passages de vie. Séances en visio, par téléphone ou en cabinet. Toutes les séances ouvrent droit à 50 % de crédit d'impôt selon l'article 199 sexdecies du CGI.
        </p>
      </div>

      <section className="py-12">
        <div className="container px-4 mx-auto sm:px-6 lg:px-8">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {practitioners.map((practitioner) => (
              <PractitionerCard key={practitioner.name} {...practitioner} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container px-4 mx-auto sm:px-6 lg:px-8">
          <h2 className="mb-8 text-2xl font-bold text-[#8B4513] text-center">
            Questions fréquentes
          </h2>
          <Accordion type="single" collapsible className="max-w-3xl mx-auto">
            {faqItems.map((item, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left text-[#8B4513]">
                  {item.question}
                </AccordionTrigger>
                <AccordionContent className="text-[#A0522D]">
                  {item.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>
    </div>
  );
};

export default Praticiens;
