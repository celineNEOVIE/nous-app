import { useEffect, useState } from "react";
import { Link, Navigate, useParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { ArrowLeft, BookOpen, Clock, Play, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { StressAssessment } from "@/components/stress-assessment";
import { exercisePages } from "@/data/exercise-pages";

const ExercicePage = () => {
  const { slug } = useParams();
  const page = exercisePages.find((p) => p.slug === slug);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  }, [slug]);

  if (!page) return <Navigate to="/exercices" replace />;

  const url = `https://app-nous.fr/exercices/${page.slug}`;
  const howTo = {
    "@context": "https://schema.org",
    "@type": "HowTo",
    name: page.h1,
    description: page.metaDescription,
    totalTime: page.isoDuration,
    step: page.steps.map((s, i) => ({ "@type": "HowToStep", position: i + 1, text: s })),
  };

  return (
    <div className="min-h-screen bg-[#F5F0E6]">
      <Helmet>
        <title>{page.metaTitle}</title>
        <meta name="description" content={page.metaDescription} />
        <link rel="canonical" href={url} />
        <meta property="og:title" content={page.metaTitle} />
        <meta property="og:description" content={page.metaDescription} />
        <meta property="og:url" content={url} />
        <meta property="og:type" content="article" />
        <script type="application/ld+json">{JSON.stringify(howTo)}</script>
      </Helmet>

      <article className="max-w-3xl mx-auto px-4 pt-8 pb-12">
        <Link to="/exercices" className="inline-flex items-center gap-1 text-sm text-[#A0522D] hover:text-sage-700 mb-6">
          <ArrowLeft className="w-4 h-4" /> Tous les exercices
        </Link>

        <h1 className="text-3xl sm:text-4xl font-alice text-[#8B4513] mb-4">{page.h1}</h1>
        <p className="text-lg text-[#5C3A1E] leading-relaxed mb-8">{page.intro}</p>

        <div className="flex justify-center mb-10">
          <Button
            size="lg"
            onClick={() => setOpen(true)}
            className="h-14 px-8 text-lg bg-sage-300 hover:bg-sage-400 text-sage-900 rounded-xl"
          >
            <Play className="w-5 h-5 mr-2" /> Commencer l'exercice
          </Button>
        </div>

        <section className="bg-white/70 rounded-2xl border border-sage-200 p-6 mb-6">
          <h2 className="text-2xl font-alice text-[#8B4513] mb-2">Comment pratiquer</h2>
          <p className="flex items-center gap-2 text-sm text-[#A0522D] mb-4">
            <Clock className="w-4 h-4" /> {page.duration}
          </p>
          <ol className="list-decimal pl-5 space-y-2 text-[#5C3A1E] leading-relaxed">
            {page.steps.map((s) => <li key={s}>{s}</li>)}
          </ol>
        </section>

        <section className="bg-white/70 rounded-2xl border border-sage-200 p-6 mb-6">
          <h2 className="text-2xl font-alice text-[#8B4513] mb-4">Les variantes disponibles dans Noûs</h2>
          <ul className="space-y-3">
            {page.variants.map((v) => (
              <li key={v.name} className="text-[#5C3A1E]">
                <span className="font-semibold text-[#8B4513]">{v.name}</span> — {v.detail}
              </li>
            ))}
          </ul>
        </section>

        <p className="text-[#5C3A1E] leading-relaxed mb-8">{page.outro}</p>

        <div className="flex justify-center mb-10">
          <Button
            size="lg"
            onClick={() => setOpen(true)}
            className="h-14 px-8 text-lg bg-sage-300 hover:bg-sage-400 text-sage-900 rounded-xl"
          >
            <Play className="w-5 h-5 mr-2" /> Commencer l'exercice
          </Button>
        </div>

        <div className="space-y-3">
          {page.blog && (
            <Link to={`/blog/${page.blog.slug}`} className="flex items-center gap-2 text-sage-700 hover:text-sage-900 underline underline-offset-4">
              <BookOpen className="w-4 h-4 shrink-0" /> À lire : {page.blog.title}
            </Link>
          )}
          <Link to="/praticiens" className="flex items-center gap-2 text-sage-700 hover:text-sage-900 underline underline-offset-4">
            <Users className="w-4 h-4 shrink-0" /> Être accompagné par un praticien certifié — 50 % de crédit d'impôt
          </Link>
        </div>
      </article>

      {open && <StressAssessment open={open} onOpenChange={setOpen} targetView={page.targetView} />}
    </div>
  );
};

export default ExercicePage;
