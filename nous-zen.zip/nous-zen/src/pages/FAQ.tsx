import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ChatWidget } from "@/components/chat-widget";

type FAQItem = {
  question: string;
  answer: string;
};

type FAQSection = {
  title: string;
  items: FAQItem[];
};

const sections: FAQSection[] = [
  {
    title: "Le service",
    items: [
      {
        question: "Comment se déroule une consultation avec un praticien ?",
        answer:
          "Après votre demande, un membre de notre équipe vous recontacte pour convenir d'un rendez-vous par téléphone ou en visio, selon vos disponibilités et celles du praticien choisi.",
      },
      {
        question: "Combien de temps pour être recontacté après une demande de RDV ?",
        answer:
          "Nous nous efforçons de vous recontacter dans les meilleurs délais, généralement sous quelques jours ouvrés.",
      },
      {
        question:
          "Les consultations sont-elles remboursées par la sécurité sociale ou les mutuelles ?",
        answer:
          "Cela dépend de votre mutuelle et du type de praticien consulté. Nous vous conseillons de vérifier directement auprès de votre organisme.",
      },
      {
        question:
          "Cet outil remplace-t-il un avis médical ou psychologique ?",
        answer:
          "Non. Cet outil ne constitue ni un diagnostic ni un suivi médical. Il vise à vous accompagner et à vous orienter vers des ressources ou des professionnels adaptés. En cas de besoin, consultez un médecin ou un professionnel de santé.",
      },
      {
        question: 'Qu\'est-ce que "Mon Plan Perso" ?',
        answer:
          'C\'est un moment d\'écoute personnalisé, pas un outil automatique. Vous nous confiez ce que vous vivez (stress, sommeil, anxiété...), par écrit ou à la voix, et c\'est une personne de notre équipe qui prend le temps de lire votre message et de vous recontacter directement (gratuitement), avec des pistes vraiment adaptées à votre situation. Votre texte n\'est pas enregistré et reste sur votre appareil, seule votre demande nous parvient, accompagnée de votre email. Cet outil ne remplace pas un avis médical.',
      },
    ],
  },
  {
    title: "Crédit d'impôt",
    items: [
      {
        question: "Puis-je bénéficier d'un crédit d'impôt pour les consultations ?",
        answer:
          'Notre service est agréé « services à la personne » (SAP 904239720), ce qui donne droit à un crédit d\'impôt selon l\'article 199 sexdecies du CGI. Vérifiez votre éligibilité et renseignements au 07.75.76.76.37.',
      },
    ],
  },
  {
    title: "Données et confidentialité",
    items: [
      {
        question: "Mes réponses au questionnaire sont-elles enregistrées ?",
        answer:
          "Non, vos réponses aux questionnaires restent uniquement sur votre appareil et ne sont pas transmises à un serveur.",
      },
      {
        question:
          "Mes données personnelles (nom, téléphone) sont-elles partagées avec des tiers ?",
        answer:
          "Non. Les informations transmises via le formulaire « Être rappelé » sont utilisées uniquement pour vous mettre en relation avec le praticien concerné.",
      },
      {
        question: "Puis-je demander la suppression de mes données ?",
        answer:
          "Oui, vous pouvez nous contacter à tout moment pour demander la suppression de vos données personnelles, conformément à la réglementation en vigueur (RGPD).",
      },
    ],
  },
  {
    title: "Nos praticiens",
    items: [
      {
        question: "Comment les praticiens sont-ils sélectionnés ?",
        answer:
          "Notre service est agréé « services à la personne », et nos praticiens sont sélectionnés pour leur expérience et leurs qualifications dans leur domaine.",
      },
      {
        question: "Puis-je choisir mon praticien ?",
        answer:
          "Oui, vous pouvez choisir librement le praticien qui vous correspond parmi notre équipe.",
      },
    ],
  },
  {
    title: "Sons binauraux",
    items: [
      {
        question: "Qu'est-ce qu'un son binaural ?",
        answer:
          "Deux fréquences légèrement différentes, envoyées une par oreille, créent une troisième onde perçue uniquement par le cerveau. Cet effet favorise différents états mentaux selon la fréquence.",
      },
      {
        question: "Pourquoi faut-il un casque pour les écouter ?",
        answer:
          "Sans casque, les deux fréquences se mélangent dans l'air avant d'atteindre les oreilles, ce qui annule l'effet binaural. Un casque garantit qu'une fréquence précise atteint chaque oreille séparément.",
      },
      {
        question: "Quelle est la différence entre les fréquences Delta, Thêta et Alpha ?",
        answer:
          "Delta (0,5–4 Hz) favorise le sommeil profond, Thêta (4–8 Hz) la relaxation et la méditation, Alpha (8–12 Hz) une concentration calme et détendue.",
      },
      {
        question: "Les sons binauraux sont-ils sans danger ?",
        answer:
          "Oui pour la grande majorité des personnes. Par précaution, les personnes épileptiques ou porteuses d'un stimulateur cardiaque devraient demander l'avis d'un médecin avant utilisation.",
      },
      {
        question: "Combien de temps faut-il écouter un son binaural pour ressentir un effet ?",
        answer:
          "Les effets varient selon les personnes ; une session de 15 à 30 minutes est généralement recommandée pour laisser au cerveau le temps de se synchroniser à la fréquence.",
      },
      {
        question: "Qu'est-ce que la fréquence 963 Hz ?",
        answer:
          'Une fréquence sonore associée dans les approches de sonothérapie à un apaisement du mental et une réduction du stress, parfois qualifiée de fréquence de "guérison".',
      },
    ],
  },
];

export default function FAQ() {
  const location = useLocation();
  const [openItem, setOpenItem] = useState<string | undefined>(undefined);

  useEffect(() => {
    if (location.hash === "#credit-impot") {
      const value = "Crédit d'impôt-0";
      setOpenItem(value);
      const tryScroll = (attempt = 0) => {
        const el = document.getElementById("credit-impot");
        if (el) {
          el.scrollIntoView({ behavior: "smooth", block: "start" });
        } else if (attempt < 10) {
          setTimeout(() => tryScroll(attempt + 1), 100);
        }
      };
      requestAnimationFrame(() => tryScroll());
    }
  }, [location.hash]);

  return (
    <div className="min-h-screen bg-[#F5F0E6]">
      <Helmet>
        <title>FAQ — Vos questions sur l'application Noûs</title>
        <meta name="description" content="Toutes les réponses sur Noûs : fonctionnement de l'app, crédit d'impôt, praticiens certifiés, confidentialité de vos données." />
        <link rel="canonical" href="https://app-nous.fr/faq" />
        <meta property="og:title" content="FAQ — Vos questions sur l'application Noûs" />
        <meta property="og:description" content="Toutes les réponses sur Noûs : fonctionnement de l'app, crédit d'impôt, praticiens certifiés, confidentialité de vos données." />
        <meta property="og:url" content="https://app-nous.fr/faq" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            mainEntity: sections.flatMap((s) =>
              s.items.map((i) => ({
                "@type": "Question",
                name: i.question,
                acceptedAnswer: { "@type": "Answer", text: i.answer },
              }))
            ),
          })}
        </script>
      </Helmet>
      <main className="container px-4 py-12 mx-auto sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <h1 className="mb-4 text-3xl font-bold text-center text-[#8B4513] font-alice">
            Foire aux questions
          </h1>

          <div className="mb-8 p-4 border border-[#D4C4B0] rounded-lg bg-[#EDE8DE] text-center">
            <p className="text-[#6b4f3a] leading-relaxed">
              Une question ? Contactez-nous directement à{" "}
              <a
                href="mailto:contactneovie@gmail.com"
                className="font-semibold text-[#8B4513] underline underline-offset-2 hover:text-[#A0522D]"
              >
                contactneovie@gmail.com
              </a>{" "}
              — nous répondons sous 48h.
            </p>
          </div>

          <div className="space-y-8">
            {sections.map((section) => (
              <section
                key={section.title}
                id={section.title === "Crédit d'impôt" ? "credit-impot" : undefined}
                className="scroll-mt-20"
              >
                <h2 className="mb-4 text-xl font-semibold text-[#8B4513]">
                  {section.title}
                </h2>
                {section.items.length > 0 ? (
                  <Accordion
                    type="single"
                    collapsible
                    className="w-full"
                    value={
                      section.title === "Crédit d'impôt" ? openItem : undefined
                    }
                    onValueChange={
                      section.title === "Crédit d'impôt"
                        ? (v) => setOpenItem(v || undefined)
                        : undefined
                    }
                  >
                    {section.items.map((item, idx) => (
                      <AccordionItem
                        key={idx}
                        value={`${section.title}-${idx}`}
                        className="border border-[#E3E9E3] rounded-lg mb-3 bg-white/60 px-4"
                      >
                        <AccordionTrigger className="text-left text-[#A0522D] font-medium hover:no-underline py-4">
                          {item.question}
                        </AccordionTrigger>
                        <AccordionContent className="text-[#6b4f3a] leading-relaxed pb-4">
                          {item.answer}
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                ) : (
                  <p className="text-[#A0522D]/70 italic">
                    Contenu à venir.
                  </p>
                )}
              </section>
            ))}
          </div>
          <div className="mt-10 p-4 border border-[#D4C4B0] rounded-lg bg-[#EDE8DE] text-center">
            <p className="text-[#6b4f3a] leading-relaxed">
              Vous ne trouvez pas votre réponse ? Écrivez-nous à{" "}
              <a
                href="mailto:contactneovie@gmail.com"
                className="font-semibold text-[#8B4513] underline underline-offset-2 hover:text-[#A0522D]"
              >
                contactneovie@gmail.com
              </a>{" "}
              — nous répondons sous 48h.
            </p>
          </div>
        </div>
      </main>
      <ChatWidget />
    </div>
  );
}
