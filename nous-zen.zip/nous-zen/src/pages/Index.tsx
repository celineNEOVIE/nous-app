
import { useState } from "react";
import { useLocation } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { HeroSection } from "@/components/hero-section";
import { PractitionerCard } from "@/components/practitioner-card";
import { ChatWidget } from "@/components/chat-widget";
import { SplashScreen } from "@/components/splash-screen";
import { PlaneBanner } from "@/components/plane-banner";
import { DownloadAppPopup } from "@/components/download-app-popup";
import { PersonalPlanForm } from "@/components/personal-plan-form";
import { HomeActions } from "@/components/home-actions";
import { PressSection } from "@/components/press-section";
import { practitioners } from "@/data/practitioners";



const Index = () => {
  const location = useLocation();
  const [showSplash, setShowSplash] = useState(() => {
    if (typeof window === "undefined") return true;
    return sessionStorage.getItem("nous_splash_seen") !== "1";
  });
  return (
    <div className="min-h-screen bg-[#F5F0E6]">
      <Helmet>
        <title>Noûs — Méditation, cohérence cardiaque et praticiens bien-être certifiés</title>
        <meta name="description" content="Application de bien-être avec méditations guidées en voix réelle, cohérence cardiaque, et annuaire de praticiens certifiés. Consultations éligibles au crédit d'impôt de 50%." />
        <link rel="canonical" href="https://app-nous.fr/" />
        <meta property="og:title" content="Noûs — Méditation, cohérence cardiaque et praticiens bien-être certifiés" />
        <meta property="og:description" content="Méditations guidées en voix réelle, cohérence cardiaque et praticiens certifiés. Consultations éligibles au crédit d'impôt de 50%." />
        <meta property="og:url" content="https://app-nous.fr/" />
      </Helmet>
      {showSplash && (
        <SplashScreen
          onFinish={() => {
            try {
              sessionStorage.setItem("nous_splash_seen", "1");
            } catch {
              /* ignore */
            }
            setShowSplash(false);
          }}
        />
      )}
      <HeroSection greetingEnabled={!showSplash} />
      <PersonalPlanForm />
      <HomeActions />
      <PlaneBanner key={location.key ?? "default"} />
      <DownloadAppPopup />
      
      <div id="praticiens" className="max-w-3xl mx-auto mb-12 text-center scroll-mt-20 px-4 sm:px-6">
        <h2 className="mb-4 text-3xl font-bold text-[#8B4513]">
          Nos Praticiens Bien-être
        </h2>
        <p className="text-lg text-[#A0522D]">
          Noûs est un réseau de praticiens du bien-être certifiés (sophrologues, naturopathes, psychothérapeutes), en visio partout en France ou en cabinet selon les praticiens. Vos séances ouvrent droit à 50 % de crédit d'impôt.
        </p>
      </div>
      
      <section className="py-12">
        <div className="container px-4 mx-auto sm:px-6 lg:px-8">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {practitioners.map((practitioner) => (
              <PractitionerCard key={practitioner.name} {...practitioner} />
            ))}
          </div>
          <p className="mt-8 text-center italic" style={{ fontSize: "14px", color: "#C97A44" }}>
            D'autres praticiens arrivent bientôt…
          </p>
        </div>
      </section>
      
      <PressSection />

      <ChatWidget />
    </div>
  );
};

export default Index;
