import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Card } from "@/components/ui/card";

type Article = {
  slug: string;
  title: string;
  excerpt: string;
  date: string;
  isoDate?: string;
  readingTime?: string;
  author: string;
  metaTitle?: string;
  metaDescription?: string;
  keywords?: string;
};

export const articles: Article[] = [
  {
    slug: "stress-des-fetes-fin-annee-noel",
    title: "Stress des fêtes de fin d'année : traverser décembre avec sérénité",
    excerpt: "Repas de famille, cadeaux, fatigue… Un guide doux en trois temps pour vivre les fêtes de fin d'année plus sereinement.",
    date: "24 novembre 2026",
    isoDate: "2026-11-24",
    readingTime: "5 min",
    author: "L'équipe Noûs",
    metaTitle: "Stress des fêtes : comment vivre décembre sereinement",
    metaDescription: "Repas de famille, cadeaux, fatigue… Le stress des fêtes vous guette ? Un guide doux pour avant, pendant et après Noël, avec l'app Noûs.",
    keywords: "stress des fêtes, stress de Noël, angoisse des fêtes de fin d'année, repas de famille stress, fatigue de décembre, charge mentale Noël, fêtes seul, gérer les tensions familiales",
  },
  {
    slug: "reveil-nocturne-3h-du-matin-se-rendormir",
    title: "Réveil à 3 h du matin : pourquoi on se réveille la nuit et comment se rendormir",
    excerpt: "Réveillé·e en pleine nuit, l'esprit qui tourne ? Pourquoi ces réveils arrivent et des gestes doux pour se rendormir sereinement.",
    date: "16 novembre 2026",
    isoDate: "2026-11-16",
    readingTime: "5 min",
    author: "L'équipe Noûs",
    metaTitle: "Réveil à 3 h du matin : pourquoi et comment se rendormir",
    metaDescription: "Vous vous réveillez la nuit sans pouvoir vous rendormir ? Causes fréquentes et gestes doux pour retrouver le sommeil, avec l'app Noûs.",
    keywords: "réveil nocturne, se réveiller à 3h du matin, réveil la nuit, impossible de se rendormir, comment se rendormir, insomnie milieu de nuit, ruminations la nuit, respiration 4-7-8",
  },
  {
    slug: "meditation-debutant-comment-commencer",
    title: "Méditation pour débutants : comment commencer quand on n'arrive pas à « faire le vide »",
    excerpt: "Pas le temps, l'esprit qui s'agite ? Un guide pas à pas pour débuter la méditation en douceur, 5 minutes par jour, sans « faire le vide ».",
    date: "2 novembre 2026",
    isoDate: "2026-11-02",
    readingTime: "5 min",
    author: "L'équipe Noûs",
    metaTitle: "Méditation pour débutants : comment commencer facilement",
    metaDescription: "Pas le temps, l'esprit qui s'agite ? Un guide doux pour débuter la méditation en 5 minutes par jour cet automne, avec les méditations guidées de Noûs.",
    keywords: "méditation débutant, comment méditer, commencer la méditation, méditation guidée, méditer 5 minutes par jour, je n'arrive pas à méditer, méditation novembre, méditation le soir",
  },
  {
    slug: "naturopathie-hiver-conseils",
    title: "Naturopathie en hiver : 6 gestes doux pour garder votre énergie",
    excerpt: "Fatigue, moral en baisse, petits coups de froid… 6 conseils de naturopathie pour traverser l'hiver en douceur et soutenir votre vitalité.",
    date: "26 octobre 2026",
    isoDate: "2026-10-26",
    readingTime: "5 min",
    author: "L'équipe Noûs",
    metaTitle: "Naturopathie en hiver : 6 gestes pour garder la forme",
    metaDescription: "Fatigue, moral en baisse, petits coups de froid… 6 conseils de naturopathie pour traverser l'hiver en douceur et soutenir votre vitalité.",
    keywords: "naturopathie, naturopathie hiver, conseils naturopathe, booster son énergie en hiver, fatigue hiver, immunité naturelle, naturopathe en ligne, crédit d'impôt naturopathie",
  },
  {
    slug: "changement-heure-hiver-sommeil",
    title: "Changement d'heure : 7 conseils doux pour protéger votre sommeil",
    excerpt: "Passage à l'heure d'hiver le 25 octobre : pourquoi il nous bouscule et 7 conseils simples pour préserver votre sommeil et votre énergie.",
    date: "20 octobre 2026",
    isoDate: "2026-10-20",
    readingTime: "5 min",
    author: "L'équipe Noûs",
    metaTitle: "Changement d'heure et sommeil : 7 conseils pour s'adapter",
    metaDescription: "Passage à l'heure d'hiver le 25 octobre : 7 conseils doux pour protéger votre sommeil, votre humeur et votre énergie, avec l'app Noûs.",
    keywords: "changement d'heure, heure d'hiver 2026, changement d'heure sommeil, fatigue changement d'heure, s'adapter au changement d'heure, changement d'heure enfants, sommeil automne",
  },
  {
    slug: "sophrologie-en-ligne-seance-credit-impot",
    title: "Sophrologie en ligne : comment ça se passe, est-ce sérieux, et combien ça coûte vraiment ?",
    excerpt: "Séance de sophrologie en visio : déroulement, choix d'une praticienne certifiée et coût réel avec 50 % de crédit d'impôt. Tout ce qu'il faut savoir avant de commencer.",
    date: "15 octobre 2026",
    isoDate: "2026-10-15",
    readingTime: "5 min",
    author: "L'équipe Noûs",
    metaTitle: "Sophrologie en ligne : comment ça se passe et combien ça coûte ? | Noûs",
    metaDescription: "Séance de sophrologie en visio : déroulement, choix d'une praticienne certifiée et coût réel avec 50 % de crédit d'impôt. Tout ce qu'il faut savoir avant de commencer.",
  },
  {
    slug: "burn-out-signes-alerte",
    title: "Burn-out : 8 signes qui doivent vous alerter (et comment réagir en douceur)",
    excerpt: "Fatigue, irritabilité, sommeil perturbé… Découvrez les 8 signes du burn-out qui doivent vous alerter et des conseils doux pour réagir à temps.",
    date: "13 octobre 2026",
    isoDate: "2026-10-13",
    readingTime: "5 min",
    author: "L'équipe Noûs",
    metaTitle: "Burn-out : 8 signes d'alerte et comment réagir",
    metaDescription: "Fatigue, irritabilité, sommeil perturbé… Découvrez les 8 signes du burn-out qui doivent vous alerter et des conseils doux pour réagir à temps.",
    keywords: "burn-out, signes burn-out, épuisement professionnel, symptômes burn-out, fatigue au travail, stress chronique, comment éviter le burn-out, sophrologie burn-out, coach burn-out",
  },
  {
    slug: "psychotherapie-en-ligne-comment-ca-se-passe",
    title: "Psychothérapie en ligne : comment ça se passe ?",
    excerpt:
      "Déroulé d'une séance en visio, avantages, limites et titre réglementé : tout savoir avant de commencer une psychothérapie en ligne.",
    date: "10 octobre 2026",
    isoDate: "2026-10-10",
    readingTime: "5 min",
    author: "L'équipe Noûs",
    metaTitle: "Psychothérapie en ligne : comment ça se passe ? | Noûs",
    metaDescription:
      "Déroulé d'une séance en visio, avantages, limites et conseils pour choisir un psychothérapeute en ligne, avec crédit d'impôt de 50 % via Noûs.",
  },
  {
    slug: "fatigue-automne-changement-saison",
    title: "Fatigue d'automne : 7 rituels doux pour traverser le changement de saison",
    excerpt: "Lumière, sommeil, respiration et pauses de calme : 7 rituels doux pour traverser la fatigue d'automne et retrouver son énergie.",
    date: "4 octobre 2026",
    isoDate: "2026-10-04",
    readingTime: "5 min",
    author: "L'équipe Noûs",
    metaTitle: "Fatigue d'automne : 7 rituels doux pour retrouver de l'énergie",
    metaDescription: "Moins de lumière, plus de fatigue ? Découvrez 7 rituels simples pour traverser le changement de saison en douceur, avec les outils de l'app Noûs.",
  },
  {
    slug: "reflexologie-des-mains-apaisement",
    title: "La réflexologie des mains, un raccourci vers l'apaisement",
    excerpt:
      "Deux minutes, n'importe où : comment le massage des points réflexes des mains aide à relâcher la pression au quotidien.",
    date: "19 août 2026",
    isoDate: "2026-08-19",
    author: "L'équipe Noûs",
    metaTitle:
      "La réflexologie des mains, un raccourci vers l'apaisement | Noûs",
    metaDescription:
      "Digestion, dos, stress, ruminations : découvrez la réflexologie des mains, une pratique simple de 2 minutes pour relâcher les tensions, et essayez les exercices guidés Noûs.",
  },
  {
    slug: "credit-impot-consultations-bien-etre",
    title:
      "Crédit d'impôt de 50% sur vos consultations bien-être : comment ça marche vraiment ?",
    excerpt:
      "Pourquoi les consultations réservées via Noûs ouvrent droit à un crédit d'impôt de 50%, et comment en bénéficier concrètement.",
    date: "5 août 2026",
    isoDate: "2026-08-05",
    author: "L'équipe Noûs",
    metaTitle:
      "Crédit d'impôt de 50% sur vos consultations bien-être : comment ça marche ? | Noûs",
    metaDescription:
      "Sophrologie, naturopathie, psychothérapie : comment bénéficier du crédit d'impôt de 50 % sur vos consultations réservées via Noûs, structure agréée SAP.",
  },
  {
    slug: "perte-concentration-clarte-mentale",
    title:
      "Pourquoi j'oublie tout et n'arrive plus à me concentrer ? 5 habitudes simples pour retrouver sa clarté mentale",
    excerpt:
      "Oublis, brouillard mental, concentration en pointillé : 5 habitudes simples pour retrouver de la clarté au quotidien.",
    date: "5 août 2026",
    isoDate: "2026-08-05",
    author: "L'équipe Noûs",
    metaTitle:
      "Perte de concentration et oublis fréquents : 5 habitudes pour retrouver sa clarté mentale | Noûs",
    metaDescription:
      "Difficultés de concentration, oublis, brouillard mental ? Découvrez 5 habitudes simples pour retrouver votre clarté mentale au quotidien, avec les outils Noûs.",
  },
  {
    slug: "sons-binauraux-cerveau-routine-bien-etre",
    title:
      "Sons binauraux : comment ils agissent sur le cerveau et pourquoi les intégrer à votre routine bien-être",
    excerpt:
      "Comment fonctionnent les sons binauraux, ce que dit la recherche et comment les intégrer simplement à un moment de pause.",
    date: "12 juillet 2026",
    isoDate: "2026-07-12",
    author: "L'équipe Noûs",
    metaTitle: "Sons binauraux : effets sur le cerveau et bienfaits | Noûs",
    metaDescription:
      "Comment fonctionnent les sons binauraux, quelles fréquences choisir (Delta, Thêta, Alpha) et ce que dit la recherche. Essayez-les gratuitement sur Noûs.",
  },
  {
    slug: "stress-anxiete-difference",
    title: "Stress et anxiété : comprendre la différence pour mieux agir",
    excerpt:
      "Stress et anxiété sont souvent confondus. Comprendre leurs différences, c'est la première étape pour mieux les apaiser.",
    date: "27 juin 2026",
    isoDate: "2026-06-27",
    author: "L'équipe Noûs",
    metaTitle: "Stress ou anxiété : comment faire la différence ? | Noûs",
    metaDescription:
      "Stress et anxiété ne sont pas la même chose. Signes à repérer, techniques validées pour s'apaiser, et exercices de respiration guidés sur Noûs.",
  },
  {
    slug: "sommeil-bien-etre",
    title: "Sommeil et bien-être : pourquoi bien dormir change tout",
    excerpt:
      "Le sommeil est le pilier silencieux de notre équilibre. Découvrez ce qui se passe la nuit et comment retrouver des nuits réparatrices.",
    date: "27 juin 2026",
    isoDate: "2026-06-27",
    author: "L'équipe Noûs",
    metaTitle: "Bien dormir : les clés d'un sommeil réparateur | Noûs",
    metaDescription:
      "Pourquoi le sommeil est essentiel à l'équilibre, ce qui le perturbe et 4 habitudes simples pour mieux dormir, avec les exercices de détente Noûs.",
  },
  {
    slug: "sophrologie-methode-douce",
    title: "La sophrologie : une méthode douce pour retrouver l'équilibre",
    excerpt:
      "Stress, sommeil, confiance en soi... Découvrez comment la sophrologie agit en douceur sur le corps et l'esprit.",
    date: "27 juin 2026",
    isoDate: "2026-06-27",
    author: "L'équipe Noûs",
    metaTitle:
      "Sophrologie : définition, bienfaits et déroulé d'une séance | Noûs",
    metaDescription:
      "Stress, sommeil, confiance en soi : découvrez ce qu'est la sophrologie, comment se passe une séance, et trouvez un sophrologue certifié sur Noûs.",
  },
  {
    slug: "coherence-cardiaque",
    title: "La cohérence cardiaque : respirez, votre cœur vous remerciera",
    excerpt:
      "Découvrez comment quelques minutes de respiration consciente par jour peuvent transformer votre équilibre intérieur.",
    date: "27 juin 2026",
    isoDate: "2026-06-27",
    author: "L'équipe Noûs",
    metaTitle: "Cohérence cardiaque 3/6/5 : la méthode expliquée | Noûs",
    metaDescription:
      "3 fois par jour, 6 respirations par minute, 5 minutes : comment la cohérence cardiaque apaise le stress. Exercice guidé gratuit sur Noûs.",
  },
  {
    slug: "bien-etre-global-approches-complementaires",
    title: "Bien-être global : quand plusieurs approches se complètent",
    excerpt:
      "Stress, sommeil, fatigue mentale : découvrez pourquoi une approche combinée donne des résultats plus durables.",
    date: "3 juillet 2026",
    isoDate: "2026-07-03",
    author: "L'équipe Noûs",
    metaTitle: "Bien-être global : quand les approches se complètent | Noûs",
    metaDescription:
      "Respiration, sophrologie, sommeil : pourquoi combiner plusieurs approches donne des résultats plus durables, et comment construire votre parcours.",
  },
];

const Blog = () => {
  return (
    <div className="min-h-screen bg-[#F5F0E6] py-12 px-4">
      <Helmet>
        <title>Blog Noûs — Conseils bien-être et actualités</title>
        <meta name="description" content="Articles et conseils sur la méditation, la gestion du stress, le crédit d'impôt SAP et le bien-être au quotidien." />
        <link rel="canonical" href="https://app-nous.fr/blog" />
        <meta property="og:title" content="Blog Noûs — Conseils bien-être et actualités" />
        <meta property="og:description" content="Articles et conseils sur la méditation, la gestion du stress, le crédit d'impôt SAP et le bien-être au quotidien." />
        <meta property="og:url" content="https://app-nous.fr/blog" />
        <meta property="og:type" content="website" />
      </Helmet>
      <div className="container max-w-4xl mx-auto">
        <header className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-alice text-[#8B4513] mb-4">
            Blog Noûs
          </h1>
          <p className="text-[#A0522D] text-lg">
            Articles, conseils et inspirations pour cultiver votre bien-être.
          </p>
        </header>

        <div className="grid gap-6 md:grid-cols-2">
          {articles.map((article) => (
            <Link key={article.slug} to={`/blog/${article.slug}`} className="group">
              <Card
                className="h-full p-6 bg-white/60 border-sage-200 hover:border-sage-400 transition-all"
                style={{ boxShadow: "0 8px 24px rgba(60, 40, 25, 0.18)" }}
              >
                <p className="text-xs text-sage-700 mb-2">{article.date}{article.readingTime && ` · ${article.readingTime} de lecture`}</p>
                <h2 className="text-xl font-alice text-[#8B4513] mb-3 group-hover:text-[#A0522D] transition-colors">
                  {article.title}
                </h2>
                <p className="text-warm-700 text-sm leading-relaxed mb-4">
                  {article.excerpt}
                </p>
                <span className="text-sage-700 text-sm font-medium">
                  Lire l'article →
                </span>
              </Card>
            </Link>
          ))}
        </div>

        <p className="text-center text-sm mt-12 italic" style={{ color: "#C97A44" }}>
          D'autres articles arrivent bientôt…
        </p>
      </div>
    </div>
  );
};

export default Blog;
