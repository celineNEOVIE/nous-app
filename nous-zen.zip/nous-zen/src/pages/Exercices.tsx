import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { StressAssessment } from "@/components/stress-assessment";

const Exercices = () => {
  const navigate = useNavigate();
  const [open, setOpen] = useState(true);
  const [searchParams] = useSearchParams();
  const targetView =
    searchParams.get("categorie") === "reflexologie" ? "reflexologie" : "tools";

  useEffect(() => {
    if (!open) navigate("/");
  }, [open, navigate]);

  return (
    <div className="min-h-[60vh] touch-pan-y bg-[#F5F0E6]" style={{ touchAction: "pan-y" }}>
      <Helmet>
        <title>Exercices bien-être — Méditation, sons binauraux et relaxation | Noûs</title>
        <meta name="description" content="Découvrez les exercices Noûs : méditations guidées, sons binauraux, cohérence cardiaque et mini-jeux de relaxation pour votre bien-être quotidien." />
        <link rel="canonical" href="https://app-nous.fr/exercices" />
        <meta property="og:title" content="Exercices bien-être — Méditation, sons binauraux et relaxation | Noûs" />
        <meta property="og:description" content="Méditations guidées, sons binauraux, cohérence cardiaque et mini-jeux de relaxation pour votre bien-être quotidien." />
        <meta property="og:url" content="https://app-nous.fr/exercices" />
        <meta property="og:type" content="website" />
      </Helmet>
      <h1 className="sr-only">Exercices de relaxation Noûs</h1>
      <StressAssessment open={open} onOpenChange={setOpen} targetView={targetView} />
    </div>
  );
};

export default Exercices;