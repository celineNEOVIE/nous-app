import { type StripeEnv, createStripeClient } from "../_shared/stripe.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const ALLOWED_RETURN_HOSTS = [
  "app-nous.fr",
  "www.app-nous.fr",
  "nous-zen.lovable.app",
  "localhost",
];

const LIVE_RETURN_HOSTS = [
  "app-nous.fr",
  "www.app-nous.fr",
  "nous-zen.lovable.app",
];

const ALLOWED_PRICE_IDS = new Set([
  "emilie_seance_80",
  "emilie_chemin_vers_moi_550",
  "charlotte_cours_en_ligne_50",
  "charlotte_cours_exterieur_66",
  "charlotte_cours_domicile_88",
  "camille_mieux_etre_90",
  "camille_therapie_breve_850",
  "camille_soin_energetique_60",
  "camille_soins_energetiques_140",
  "sophie_seance_unite_99",
  "sophie_seance_decouverte_115",
  "sophie_forfait_mensuel_250",
  "margaux_stop_anxiete_175",
  "margaux_ma_serenite_1150",
  "margaux_seance_adulte_105",
  "margaux_seance_enfant_75",
  "valerie_seance_1h_75",
  "valerie_boussole_110",
  "valerie_parcours_350",
  "valerie_eveil_vie_890",
  "nathalie_forfait_5_250",
  "laurence_seance_adulte_77",
  "laurence_seance_couple_94",
  "laurence_seance_qi_121",
  "clara_boost_relaxation_45",
  "clara_reharmonisation_110",
  "clara_suivi_90",
  "oceane_psycho_corporel_77",
  "jacqui_seance_individuelle_150",
]);

function isAllowedOrigin(origin: string | null): boolean {
  if (!origin) return false;
  try {
    const u = new URL(origin);
    const host = u.hostname.toLowerCase();
    if (u.protocol === "capacitor:" && host === "localhost") return true;
    if (u.protocol !== "https:" && !(u.protocol === "http:" && host === "localhost")) return false;
    return ALLOWED_RETURN_HOSTS.includes(host) || host.endsWith(".lovable.app") || host.endsWith(".lovableproject.com");
  } catch {
    return false;
  }
}

function isAllowedReturnUrl(value: unknown): value is string {
  if (typeof value !== "string" || value.length > 2048) return false;
  try {
    const u = new URL(value);
    const host = u.hostname.toLowerCase();
    if (u.protocol === "capacitor:" && host === "localhost") return true;
    if (u.protocol !== "https:" && !(u.protocol === "http:" && host === "localhost")) return false;
    return ALLOWED_RETURN_HOSTS.includes(host) || host.endsWith(".lovable.app") || host.endsWith(".lovableproject.com");
  } catch {
    return false;
  }
}

function isLiveReturnUrl(value: string): boolean {
  try {
    const u = new URL(value);
    const host = u.hostname.toLowerCase();
    if (u.protocol === "capacitor:" && host === "localhost") return true;
    return u.protocol === "https:" && LIVE_RETURN_HOSTS.includes(host);
  } catch {
    return false;
  }
}

async function createCheckoutSession(options: {
  priceId: string;
  customerEmail?: string;
  returnUrl: string;
  environment: StripeEnv;
}) {
  if (!ALLOWED_PRICE_IDS.has(options.priceId)) throw new Error("Invalid priceId");
  const stripe = createStripeClient(options.environment);

  const prices = await stripe.prices.list({ lookup_keys: [options.priceId] });
  if (!prices.data.length) throw new Error("Price not found");
  const stripePrice = prices.data[0];
  const isRecurring = stripePrice.type === "recurring";

  const productId = typeof stripePrice.product === "string"
    ? stripePrice.product
    : stripePrice.product.id;
  const product = await stripe.products.retrieve(productId);
  const productDescription = product.name;

  const session = await stripe.checkout.sessions.create({
    line_items: [{ price: stripePrice.id, quantity: 1 }],
    mode: isRecurring ? "subscription" : "payment",
    ui_mode: "embedded_page",
    return_url: options.returnUrl,
    ...(!isRecurring && { payment_intent_data: { description: productDescription } }),
    ...(options.customerEmail && { customer_email: options.customerEmail }),
  } as any);

  return session.client_secret;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405, headers: corsHeaders });
  }
  const origin = req.headers.get("origin");
  if (!isAllowedOrigin(origin)) {
    return new Response(JSON.stringify({ error: "Forbidden origin" }), {
      status: 403,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  try {
    const body = await req.json();
    const { priceId, customerEmail, returnUrl, environment } = body ?? {};
    if (!priceId || !returnUrl || !environment) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (typeof priceId !== "string" || !ALLOWED_PRICE_IDS.has(priceId)) {
      return new Response(JSON.stringify({ error: "Invalid priceId" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!isAllowedReturnUrl(returnUrl)) {
      return new Response(JSON.stringify({ error: "Invalid returnUrl" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (environment !== "sandbox" && environment !== "live") {
      return new Response(JSON.stringify({ error: "Invalid environment" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (environment === "live" && !isLiveReturnUrl(returnUrl)) {
      return new Response(JSON.stringify({ error: "Live environment not allowed for this returnUrl" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const validatedEmail = typeof customerEmail === "string" ? customerEmail.trim() : undefined;
    if (validatedEmail && (validatedEmail.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(validatedEmail))) {
      return new Response(JSON.stringify({ error: "Invalid customerEmail" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const clientSecret = await createCheckoutSession({
      priceId,
      customerEmail: validatedEmail,
      returnUrl,
      environment,
    });
    return new Response(JSON.stringify({ clientSecret }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("create-checkout error:", e);
    return new Response(JSON.stringify({ error: "Unable to create checkout session. Please try again." }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});